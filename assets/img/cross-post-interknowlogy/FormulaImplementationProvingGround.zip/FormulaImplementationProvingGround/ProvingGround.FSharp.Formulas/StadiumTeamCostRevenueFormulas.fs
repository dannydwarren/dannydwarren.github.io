﻿namespace ProvingGround.FSharp.Formulas

module internal StadiumTeamCostRevenueFormulas =
    open ProvingGround.FSharp.Formulas.FormulaInputModels
    open ProvingGround.FSharp.Formulas.FormulaOutputModels
    
    let private CurrentWinRatio(isIncluded : bool,
                                totalGames : decimal,
                                wins : decimal) = 
        if isIncluded && totalGames > 0M
        then wins / totalGames
        else 0M

    let private DesiredWinRatio(isIncluded : bool,
                                currentWinRatio : decimal,
                                changeInWinRatio : decimal) =
        if isIncluded
        then currentWinRatio * changeInWinRatio
        else 0M

    let private TicketsSold(winRatio : decimal,
                            seats : decimal) =
        winRatio * seats

    let private RevenueFromTickets(isHome : bool,
                                   ticketsSold : decimal,
                                   ticketPrice : decimal,
                                   revenueSplitWithVisitingTeamRatio : decimal) =
        if isHome
        then ticketsSold * ticketPrice * revenueSplitWithVisitingTeamRatio
        else ticketsSold * ticketPrice * (1M - revenueSplitWithVisitingTeamRatio)

    let private ConsessionsSold(ticketsSold : decimal,
                                consessionPurchaseRatio : decimal) =
        ticketsSold * consessionPurchaseRatio

    let private ConsessionReveue(isHome : bool,
                                 concessionsSold : decimal,
                                 averageConcessionPricePerItem : decimal,
                                 concessionProfitRatio : decimal,
                                 revenueSplitWithVisitingTeamRatio : decimal) =
        if isHome
        then concessionsSold * averageConcessionPricePerItem * concessionProfitRatio * revenueSplitWithVisitingTeamRatio
        else concessionsSold * averageConcessionPricePerItem * concessionProfitRatio * (1M - revenueSplitWithVisitingTeamRatio)

    let private RevenueSubtotal(revenueFromTickets : decimal,
                                consessionRevenue : decimal) =
        revenueFromTickets + consessionRevenue

    let private LockerRoomCosts(isHome : bool,
                                revenueSubtotal : decimal,
                                lockerRoomRentalFeePercent : decimal) =
        if isHome
        then 0M
        else revenueSubtotal * lockerRoomRentalFeePercent

    let private PoorSalesCosts(isHome : bool,
                               revenueSubtotal : decimal,
                               poorSalesFeePercent : decimal) = 
        if isHome
        then 0M
        else revenueSubtotal * poorSalesFeePercent

    let private ReveueTotal(revenueSubtotal : decimal,
                            lockerRoomCosts : decimal,
                            poorSalesCosts : decimal) =
        revenueSubtotal - lockerRoomCosts - poorSalesCosts

    let private CalculateStadiumTeamCostRevenueOutput(stadiumTeamInput : StadiumTeamInput, winRatio : decimal) =
        let stadiumInput = stadiumTeamInput.StadiumInput

        let ticketsSold = TicketsSold(winRatio, stadiumInput.Seats)
        let revenueFromTickets = RevenueFromTickets(stadiumTeamInput.IsHome, ticketsSold, stadiumInput.TicketPrice, stadiumInput.RevenueSplitWithVisitingTeamRatio)
        let consessionsSold = ConsessionsSold(ticketsSold, stadiumInput.ConsessionPurchaseRatio)
        let consessionReveue = ConsessionReveue(stadiumTeamInput.IsHome, consessionsSold, stadiumInput.AverageConsessionPricePerItem, stadiumInput.ConsessionProfitRatio, stadiumInput.RevenueSplitWithVisitingTeamRatio)
        let revenueSubtotal = RevenueSubtotal(revenueFromTickets, consessionReveue)
        let lockerRoomCosts = LockerRoomCosts(stadiumTeamInput.IsHome, revenueSubtotal, stadiumInput.LockerRoomRentalFeePercent)
        let poorSalesCosts = PoorSalesCosts(stadiumTeamInput.IsHome, revenueSubtotal, stadiumInput.PoorSalesFeePercent)
        let reveueTotal = ReveueTotal(revenueSubtotal, lockerRoomCosts, poorSalesCosts)

        new StadiumTeamCostRevenueOutput(winRatio,
                                         ticketsSold,
                                         revenueFromTickets,
                                         consessionsSold,
                                         consessionReveue,
                                         revenueSubtotal,
                                         lockerRoomCosts,
                                         poorSalesCosts,
                                         reveueTotal)
    
    let CalculateCurrentStadiumTeamCostRevenueOutput(stadiumTeamInput : StadiumTeamInput) = 
        CalculateStadiumTeamCostRevenueOutput(stadiumTeamInput,
                                              CurrentWinRatio(stadiumTeamInput.StadiumInput.IsIncluded, stadiumTeamInput.Losses + stadiumTeamInput.Wins, stadiumTeamInput.Wins))

    let CalculateDesiredStadiumTeamCostRevenueOutput(stadiumTeamInput : StadiumTeamInput, teamChangeInWinRatio : decimal) = 
        CalculateStadiumTeamCostRevenueOutput(stadiumTeamInput,
                                              DesiredWinRatio(stadiumTeamInput.StadiumInput.IsIncluded, CurrentWinRatio(stadiumTeamInput.StadiumInput.IsIncluded, stadiumTeamInput.Losses + stadiumTeamInput.Wins, stadiumTeamInput.Wins), teamChangeInWinRatio))
   

