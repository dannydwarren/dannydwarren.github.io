﻿namespace ProvingGround.FSharp.Formulas

module FormulaModelFormulas =
    open ProvingGround.FSharp.Formulas.FormulaInputModels
    open ProvingGround.FSharp.Formulas.FormulaOutputModels
    open FormulaModelYearFormulas


    let CalculateFormulaModel(formulaModelInput : FormulaModelInput, stadiumTeamYearOutputs : StadiumTeamYearOutput array array) = 
        
        let marketingCostYears = 
            Array.Parallel.mapi (fun (yearIndex : int) (stadiumTeamSingleYearOutputs : StadiumTeamYearOutput array) -> CalculateMarketingCostYear(formulaModelInput, stadiumTeamSingleYearOutputs, yearIndex)) stadiumTeamYearOutputs

        let zippedStadiumTeamYearOutputsWithMarketingCostYears = Array.zip stadiumTeamYearOutputs marketingCostYears
        
        let calculatedMarketingCosts = Array.sumBy (fun (marketingCostYear : MarketingCostYear) -> marketingCostYear.TotalMarketingCosts) marketingCostYears
        let calculatedPracticeCosts = Array.sumBy (fun (stadiumTeamSingleYearOutputs : StadiumTeamYearOutput array) -> Array.sumBy (fun (stadiumTeamSingleYearOutput : StadiumTeamYearOutput) -> stadiumTeamSingleYearOutput.PracticeCosts) stadiumTeamSingleYearOutputs) stadiumTeamYearOutputs
        let calculatedParkingLotMaintenanceCosts = Array.sumBy (fun (stadiumTeamSingleYearOutputs : StadiumTeamYearOutput array) -> Array.sumBy (fun (stadiumTeamSingleYearOutput : StadiumTeamYearOutput) -> stadiumTeamSingleYearOutput.ParkingLotMaintenanceCosts) stadiumTeamSingleYearOutputs) stadiumTeamYearOutputs
        let differenceInMarketingCosts = if formulaModelInput.AreMarketingCostsAdjusted then formulaModelInput.MarketingCosts - calculatedMarketingCosts else 0M
        let differenceInPracticeCosts = if formulaModelInput.ArePracticeCostsAdjusted then formulaModelInput.PracticeCosts - calculatedPracticeCosts else 0M
        let differenceInParkingLotMaintenanceCosts = if formulaModelInput.AreParkingLotMaintenanceCostsAdjusted then formulaModelInput.ParkingLotMaintenanceCosts - calculatedParkingLotMaintenanceCosts else 0M

        let formulaModelYearWithoutNpvOutputs : FormulaModelYearWithoutNpvOutput array = 
            Array.Parallel.mapi (fun (yearIndex : int) (stadiumTeamSingleYearOutputs : StadiumTeamYearOutput array, marketingCostYear : MarketingCostYear) -> CalculateFormulaModelYear(formulaModelInput, stadiumTeamSingleYearOutputs, yearIndex, marketingCostYear, differenceInMarketingCosts, differenceInPracticeCosts, differenceInParkingLotMaintenanceCosts)) zippedStadiumTeamYearOutputsWithMarketingCostYears

        let totalWorthYears : decimal array = Array.map (fun (formulaModelYearWithoutNpvOutput : FormulaModelYearWithoutNpvOutput) -> formulaModelYearWithoutNpvOutput.TotalWorth) formulaModelYearWithoutNpvOutputs
        let totalWorthYearsInUse : decimal array = Array.create totalWorthYears.Length 0M

        let formulaModelYearOutputs : FormulaModelYearOutput array = Array.zeroCreate totalWorthYears.Length

        for i in 0..formulaModelInput.YearCount - 1 do
            Array.set totalWorthYearsInUse i (Array.get totalWorthYears i)
            let npv = FinancialMathFormulas.PresentValue(formulaModelInput.NpvRate, totalWorthYearsInUse)
            let formulaModelYearWithoutNpvOutput = Array.get formulaModelYearWithoutNpvOutputs i
            Array.set formulaModelYearOutputs i (new FormulaModelYearOutput(formulaModelYearWithoutNpvOutput, npv))
        
        new FormualModelOutput(calculatedMarketingCosts,
                               calculatedPracticeCosts,
                               calculatedParkingLotMaintenanceCosts,
                               differenceInMarketingCosts,
                               differenceInPracticeCosts,
                               differenceInParkingLotMaintenanceCosts,
                               formulaModelYearOutputs)