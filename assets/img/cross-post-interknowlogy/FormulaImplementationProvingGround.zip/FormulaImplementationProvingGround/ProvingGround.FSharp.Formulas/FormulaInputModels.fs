﻿namespace ProvingGround.FSharp.Formulas

module FormulaInputModels =

    type MaintenanceSchedule =
        | EveryEvenYear
        | EverOddYear

    type StadiumInput(id : int64,
                      ticketPrice : decimal,
                      seats : decimal,
                      consessionProfitRatio : decimal,
                      averageConsessionPricePerItem : decimal,
                      consessionPurchaseRatio : decimal,
                      revenueSplitWithVisitingTeamRatio : decimal,
                      lockerRoomRentalFeePercent : decimal,
                      poorSalesFeePercent : decimal,
                      practiceCost : decimal,
                      marketingCost : decimal,
                      parkingLotMaintenancePerTicket : decimal,
                      maintenanceSchedule : MaintenanceSchedule,
                      isIncluded : bool,
                      rateOfIncrease : decimal) =
        member this.Id = id
        member this.TicketPrice = ticketPrice
        member this.Seats = seats
        member this.ConsessionProfitRatio = consessionProfitRatio
        member this.AverageConsessionPricePerItem = averageConsessionPricePerItem
        member this.ConsessionPurchaseRatio = consessionPurchaseRatio
        member this.RevenueSplitWithVisitingTeamRatio = revenueSplitWithVisitingTeamRatio
        member this.LockerRoomRentalFeePercent = lockerRoomRentalFeePercent
        member this.PoorSalesFeePercent = poorSalesFeePercent
        member this.PracticeCost = practiceCost
        member this.MarketingCost = marketingCost
        member this.ParkingLotMaintenancePerTicket = parkingLotMaintenancePerTicket
        member this.MaintenanceSchedule = maintenanceSchedule
        member this.IsIncluded = isIncluded
        member this.RateOfIncrease = rateOfIncrease

    type StadiumTeamInput(stadiumId : int64,
                          teamId : int64,
                          isHome : bool,
                          wins : decimal,
                          losses : decimal,
                          stadiumInput : StadiumInput) =
        member this.StadiumId = stadiumId
        member this.TeamId = teamId
        member this.IsHome = isHome
        member this.Wins = wins
        member this.Losses = losses
        member this.StadiumInput = stadiumInput

    type TeamInput(id : int64,
                   isDesiredWinRatioAdjusted : bool,
                   desiredWinRatio : decimal,
                   additionalMarketingCosts : decimal,
                   donations : decimal,
                   yearCount : int,
                   stadiumTeamInputs : StadiumTeamInput array) = 
        member this.Id = id
        member this.IsDesiredWinRatioAdjusted = isDesiredWinRatioAdjusted
        member this.DesiredWinRatio = desiredWinRatio
        member this.YearCount = yearCount
        member this.StadiumTeamInputs = stadiumTeamInputs

    type FormulaModelInput(areMarketingCostsAdjusted : bool,
                           marketingCosts : decimal,
                           arePracticeCostsAdjusted : bool,
                           practiceCosts : decimal,
                           areParkingLotMaintenanceCostsAdjusted : bool,
                           parkingLotMaintenanceCosts : decimal,
                           npvRate : decimal,
                           totalAdditionalMarketingCosts : decimal,
                           totalDonations : decimal,
                           theoreticalStadium : StadiumInput,
                           yearCount : int) =
        member this.AreMarketingCostsAdjusted = areMarketingCostsAdjusted
        member this.MarketingCosts = marketingCosts
        member this.ArePracticeCostsAdjusted = arePracticeCostsAdjusted
        member this.PracticeCosts = practiceCosts
        member this.AreParkingLotMaintenanceCostsAdjusted = areParkingLotMaintenanceCostsAdjusted
        member this.ParkingLotMaintenanceCosts = parkingLotMaintenanceCosts
        member this.NpvRate = npvRate
        member this.TotalAdditionalMarketingCosts = totalAdditionalMarketingCosts
        member this.TotalDonations = totalDonations
        member this.TheoreticalStadium = theoreticalStadium
        member this.YearCount = yearCount
