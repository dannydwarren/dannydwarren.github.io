﻿namespace ProvingGround.FSharp.Formulas

module internal StadiumTeamYearFormulas =
    open ProvingGround.FSharp.Formulas.FormulaInputModels
    open ProvingGround.FSharp.Formulas.FormulaOutputModels
    open StadiumYearFormulas
    
    let private CreateStadiumTeamYearOutput((yearIndex : int, differenceInRevenue : decimal),
                                    (practiceCosts : decimal, marketingCosts : decimal, parkingLotMaintenanceCosts : decimal)) =
        new StadiumTeamYearOutput(yearIndex, practiceCosts, marketingCosts, parkingLotMaintenanceCosts, differenceInRevenue)    

    let CalculateStadiumTeamYearOutput(stadiumTeamInput : StadiumTeamInput,
                                       yearCount : int,
                                       (practiceCosts : decimal, marketingCosts : decimal, parkingLotMaintenanceCosts : decimal, differenceInRevenue : decimal) ) = 
        let stadiumInput = stadiumTeamInput.StadiumInput
        
        let years = [|0..yearCount - 1|]
       
        let practiceCostsPerYear = Array.map (fun (yearIndex : int) -> CalculateValueForYear stadiumInput.IsIncluded stadiumInput.MaintenanceSchedule yearCount yearIndex stadiumInput.RateOfIncrease practiceCosts) years
        let marketingCostsPerYear = Array.map (fun (yearIndex : int) -> CalculateValueForYear stadiumInput.IsIncluded stadiumInput.MaintenanceSchedule yearCount yearIndex stadiumInput.RateOfIncrease marketingCosts) years
        let parkingLotMaintenanceCostsPerYear = Array.map (fun (yearIndex : int) -> CalculateValueForYear stadiumInput.IsIncluded stadiumInput.MaintenanceSchedule yearCount yearIndex stadiumInput.RateOfIncrease parkingLotMaintenanceCosts) years
      
        let differenceInRevenuePerYear = Array.map (fun (yearIndex : int) -> CalculateValueForYear stadiumInput.IsIncluded stadiumInput.MaintenanceSchedule yearCount yearIndex stadiumInput.RateOfIncrease differenceInRevenue) years

        let zippedCosts = Array.zip3 practiceCostsPerYear marketingCostsPerYear parkingLotMaintenanceCostsPerYear
        let zippedYearsWithRevenue = Array.zip years differenceInRevenuePerYear
        let zippedYearsWithCostsAndRevenue = Array.zip zippedYearsWithRevenue zippedCosts

        let stadiumTeamYearOutputs = Array.map CreateStadiumTeamYearOutput zippedYearsWithCostsAndRevenue
        stadiumTeamYearOutputs