﻿namespace ProvingGround.FSharp.Formulas

module FormulaOutputModels =
    
    type FormulaModelYearWithoutNpvOutput(yearIndex : int,
                                          marketingCosts : decimal,
                                          additionalMarketingCosts : decimal,
                                          totalMarketingCosts : decimal,
                                          practiceCosts : decimal,
                                          parkingLotMaintenanceCosts : decimal,
                                          totalCosts : decimal,
                                          scheduledDifferenceInMarketingCosts : decimal,
                                          scheduledDifferenceInPracticeCosts : decimal,
                                          scheduledDifferenceInParkingLotMaintenanceCosts : decimal,
                                          totalScheduledDifferenceInCosts : decimal,
                                          differenceInRevenue : decimal,
                                          donations : decimal,
                                          totalReveue : decimal,
                                          totalWorth : decimal) =
        member this.YearIndex = yearIndex
        member this.MarketingCosts = marketingCosts
        member this.AdditionalMarketingCosts = additionalMarketingCosts
        member this.TotalMarketingCosts = totalMarketingCosts
        member this.PracticeCosts = practiceCosts
        member this.ParkingLotMaintenanceCosts = parkingLotMaintenanceCosts
        member this.TotalCosts = totalCosts
        member this.ScheduledDifferenceInMarketingCosts = scheduledDifferenceInMarketingCosts
        member this.ScheduledDifferenceInPracticeCosts = scheduledDifferenceInPracticeCosts
        member this.ScheduledDifferenceInParkingLotMaintenanceCosts = scheduledDifferenceInParkingLotMaintenanceCosts
        member this.TotalScheduledDifferenceInCosts = totalScheduledDifferenceInCosts
        member this.DifferenceInRevenue = differenceInRevenue
        member this.Donations = donations
        member this.TotalReveue = totalReveue
        member this.TotalWorth = totalWorth

    type FormulaModelYearOutput(formulaModelYearWithoutNpvOutput : FormulaModelYearWithoutNpvOutput,
                                npv : decimal) =
        member this.YearIndex = formulaModelYearWithoutNpvOutput.YearIndex
        member this.MarketingCosts = formulaModelYearWithoutNpvOutput.MarketingCosts
        member this.AdditionalMarketingCosts = formulaModelYearWithoutNpvOutput.AdditionalMarketingCosts
        member this.TotalMarketingCosts = formulaModelYearWithoutNpvOutput.TotalMarketingCosts
        member this.PracticeCosts = formulaModelYearWithoutNpvOutput.PracticeCosts
        member this.ParkingLotMaintenanceCosts = formulaModelYearWithoutNpvOutput.ParkingLotMaintenanceCosts
        member this.TotalCosts = formulaModelYearWithoutNpvOutput.TotalCosts
        member this.ScheduledDifferenceInMarketingCosts = formulaModelYearWithoutNpvOutput.ScheduledDifferenceInMarketingCosts
        member this.ScheduledDifferenceInPracticeCosts = formulaModelYearWithoutNpvOutput.ScheduledDifferenceInPracticeCosts
        member this.ScheduledDifferenceInParkingLotMaintenanceCosts = formulaModelYearWithoutNpvOutput.ScheduledDifferenceInParkingLotMaintenanceCosts
        member this.TotalScheduledDifferenceInCosts = formulaModelYearWithoutNpvOutput.TotalScheduledDifferenceInCosts
        member this.DifferenceInRevenue = formulaModelYearWithoutNpvOutput.DifferenceInRevenue
        member this.Donations = formulaModelYearWithoutNpvOutput.Donations
        member this.TotalReveue = formulaModelYearWithoutNpvOutput.TotalReveue
        member this.TotalWorth = formulaModelYearWithoutNpvOutput.TotalWorth
        member this.Npv = npv
    
    type FormualModelOutput(calculatedMarketingCosts : decimal,
                            calculatedPracticeCosts : decimal,
                            calculatedParkingLotMaintenanceCosts : decimal,
                            differenceInMarketingCosts : decimal,
                            differnceInPracticeCosts : decimal,
                            differenceInParkingLotMaintenanceCosts : decimal,
                            formulaModelYearOutputs : FormulaModelYearOutput array) =
        member this.CalculatedMarketingCosts = calculatedMarketingCosts
        member this.CalculatedPracticeCosts = calculatedPracticeCosts
        member this.CalculatedParkingLotMaintenanceCosts = calculatedParkingLotMaintenanceCosts
        member this.DifferenceInMarketingCosts = differenceInMarketingCosts
        member this.DiffernceInPracticeCosts = differnceInPracticeCosts
        member this.DifferenceInParkingLotMaintenanceCosts = differenceInParkingLotMaintenanceCosts
        member this.FormulaModelYearOutputs = formulaModelYearOutputs


    type StadiumTeamYearOutput(yearIndex : int,
                               practiceCosts : decimal,
                               marketingCosts : decimal,
                               parkingLotMaintenanceCosts : decimal,
                               differenceInRevenue : decimal) =
        member this.YearIndex = yearIndex
        member this.PracticeCosts = practiceCosts
        member this.MarketingCosts = marketingCosts
        member this.ParkingLotMaintenanceCosts = parkingLotMaintenanceCosts
        member this.DifferenceInRevenue = differenceInRevenue

    type StadiumTeamCostRevenueOutput(winRatio : decimal,
                                      ticketsSold : decimal,
                                      revenueFromTickets : decimal,
                                      consessionsSold : decimal,
                                      consessionRevenue : decimal,
                                      revenueSubtotal : decimal,
                                      lockerRoomCosts : decimal,
                                      poorSalesCosts : decimal,
                                      revenueTotal : decimal) =
        member this.WinRatio = winRatio
        member this.TicketsSold = ticketsSold
        member this.RevenueFromTickets = revenueFromTickets
        member this.ConsessionsSold = consessionsSold
        member this.ConsessionRevenue = consessionRevenue
        member this.RevenueSubtotal = revenueSubtotal
        member this.LockerRoomCosts = lockerRoomCosts
        member this.PoorSalesCosts = poorSalesCosts
        member this.RevenueTotal = revenueTotal

    type StadiumTeamOutput(stadiumId : int64,
                           teamId : int64,
                           totalGames : decimal,
                           currentStadiumTeamCostRevenueData : StadiumTeamCostRevenueOutput,
                           desiredStadiumTeamCostRevenueData : StadiumTeamCostRevenueOutput,
                           currentTicketsSold : decimal,
                           desiredTicketsSold : decimal,
                           differenceInTicketsSold : decimal,
                           practiceCosts : decimal,
                           marketingCosts : decimal,
                           parkingLotMaintenanceCosts : decimal,
                           differenceInRevenue : decimal,
                           stadiumTeamYearOutputs : StadiumTeamYearOutput array) =
        member this.StadiumId = stadiumId
        member this.TeamId = teamId
        member this.TotalGames = totalGames
        member this.CurrentStadiumTeamCostRevenueData = currentStadiumTeamCostRevenueData
        member this.DesiredStadiumTeamCostRevenueData = desiredStadiumTeamCostRevenueData
        member this.CurrentTicketsSold = currentTicketsSold
        member this.DesiredTicketsSold = desiredTicketsSold
        member this.DifferenceInTicketsSold = differenceInTicketsSold
        member this.PracticeCosts = practiceCosts
        member this.MarketingCosts = marketingCosts
        member this.ParkingLotMaintenanceCosts = parkingLotMaintenanceCosts
        member this.DifferenceInRevenue = differenceInRevenue
        member this.StadiumTeamYearOutputs = stadiumTeamYearOutputs

    type TeamOutput(id : int64,
                    currentWins : decimal,
                    currentWinRatio : decimal,
                    desiredWinRatio : decimal,
                    changeInWinRatio : decimal,
                    currentTotalGames : decimal,
                    stadiumTeamOutputs : StadiumTeamOutput array) =
        member this.Id = id
        member this.CurrentWins = currentWins
        member this.CurrentWinRatio = currentWinRatio
        member this.DesiredWinRatio = desiredWinRatio
        member this.ChangeInWinRatio = changeInWinRatio
        member this.CurrentTotalGames = currentTotalGames
        member this.StadiumTeamOutputs = stadiumTeamOutputs

