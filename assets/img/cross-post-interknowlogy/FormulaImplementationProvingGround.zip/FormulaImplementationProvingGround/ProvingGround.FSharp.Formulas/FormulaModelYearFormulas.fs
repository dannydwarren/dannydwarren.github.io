﻿namespace ProvingGround.FSharp.Formulas

module internal FormulaModelYearFormulas = 
    open ProvingGround.FSharp.Formulas.FormulaInputModels
    open ProvingGround.FSharp.Formulas.FormulaOutputModels

    type MarketingCostYear(yearIndex : int,
                           marketingCosts : decimal,
                           additionalMarketingCosts : decimal,
                           totalMarketingCosts : decimal) =
        member this.YearIndex = yearIndex
        member this.MarketingCosts = marketingCosts
        member this.AdditionalMarketingCosts = additionalMarketingCosts
        member this.TotalMarketingCosts = totalMarketingCosts

    let private CalculateValueForYearForcedInclusion = StadiumYearFormulas.CalculateValueForYear true

    let CalculateMarketingCostYear(formulaModelInput : FormulaModelInput,
                                   stadiumTeamYearOutputs : StadiumTeamYearOutput array,
                                   yearIndex : int) =
        let marketingCosts = Array.sumBy (fun (stadiumTeamYearOutput : StadiumTeamYearOutput) -> stadiumTeamYearOutput.MarketingCosts) stadiumTeamYearOutputs 
        let additionalMarketingCosts = CalculateValueForYearForcedInclusion formulaModelInput.TheoreticalStadium.MaintenanceSchedule
                                                                            formulaModelInput.YearCount
                                                                            yearIndex
                                                                            formulaModelInput.TheoreticalStadium.RateOfIncrease
                                                                            formulaModelInput.TotalAdditionalMarketingCosts
        let totalMarketingCosts = marketingCosts + additionalMarketingCosts

        new MarketingCostYear(yearIndex, marketingCosts, additionalMarketingCosts, totalMarketingCosts)


    let CalculateFormulaModelYear(formulaModelInput : FormulaModelInput,
                                  stadiumTeamYearOutputs : StadiumTeamYearOutput array,
                                  yearIndex : int,
                                  marketingCostYear : MarketingCostYear,
                                  differenceInMarketingCosts : decimal,
                                  differenceInPracticeCosts : decimal,
                                  differenceInParkingLotMaintenanceCosts : decimal) =
        let practiceCosts = Array.sumBy (fun (stadiumTeamYearOutput : StadiumTeamYearOutput) -> stadiumTeamYearOutput.PracticeCosts) stadiumTeamYearOutputs 
        let parkingLotMaintenanceCosts = Array.sumBy (fun (stadiumTeamYearOutput : StadiumTeamYearOutput) -> stadiumTeamYearOutput.ParkingLotMaintenanceCosts) stadiumTeamYearOutputs 
        let totalCosts = marketingCostYear.TotalMarketingCosts + practiceCosts + parkingLotMaintenanceCosts
        let scheduledDifferenceInMarketingCosts = CalculateValueForYearForcedInclusion formulaModelInput.TheoreticalStadium.MaintenanceSchedule
                                                                                       formulaModelInput.YearCount
                                                                                       yearIndex
                                                                                       formulaModelInput.TheoreticalStadium.RateOfIncrease
                                                                                       differenceInMarketingCosts
                                                                                       //(if formulaModelInput.AreMarketingCostsAdjusted then formulaModelInput.MarketingCosts - totalMarketingCosts else 0M)
        let scheduledDifferenceInPracticeCosts = CalculateValueForYearForcedInclusion formulaModelInput.TheoreticalStadium.MaintenanceSchedule
                                                                                      formulaModelInput.YearCount
                                                                                      yearIndex
                                                                                      formulaModelInput.TheoreticalStadium.RateOfIncrease
                                                                                      differenceInPracticeCosts
                                                                                      //(if formulaModelInput.ArePracticeCostsAdjusted then formulaModelInput.PracticeCosts - practiceCosts else 0M)
        let scheduledDifferenceInParkingLotMaintenanceCosts = CalculateValueForYearForcedInclusion formulaModelInput.TheoreticalStadium.MaintenanceSchedule
                                                                                                   formulaModelInput.YearCount
                                                                                                   yearIndex
                                                                                                   formulaModelInput.TheoreticalStadium.RateOfIncrease
                                                                                                   differenceInParkingLotMaintenanceCosts
                                                                                                   //(if formulaModelInput.AreParkingLotMaintenanceCostsAdjusted then formulaModelInput.ParkingLotMaintenanceCosts - parkingLotMaintenanceCosts else 0M)
        let totalScheduledDifferenceInCosts = scheduledDifferenceInMarketingCosts + scheduledDifferenceInPracticeCosts + scheduledDifferenceInParkingLotMaintenanceCosts
        let differenceInRevenue = Array.sumBy (fun (stadiumTeamYearOutput : StadiumTeamYearOutput) -> stadiumTeamYearOutput.DifferenceInRevenue) stadiumTeamYearOutputs 
        let donations = CalculateValueForYearForcedInclusion formulaModelInput.TheoreticalStadium.MaintenanceSchedule
                                                             formulaModelInput.YearCount
                                                             yearIndex
                                                             formulaModelInput.TheoreticalStadium.RateOfIncrease
                                                             formulaModelInput.TotalDonations
        let totalReveue = differenceInRevenue + donations
        let totalWorth = totalReveue - totalScheduledDifferenceInCosts - totalCosts
        
        new FormulaModelYearWithoutNpvOutput(yearIndex,
                                             marketingCostYear.MarketingCosts,
                                             marketingCostYear.AdditionalMarketingCosts,
                                             marketingCostYear.TotalMarketingCosts,
                                             practiceCosts,
                                             parkingLotMaintenanceCosts,
                                             totalCosts,
                                             scheduledDifferenceInMarketingCosts,
                                             scheduledDifferenceInPracticeCosts,
                                             scheduledDifferenceInParkingLotMaintenanceCosts,
                                             totalScheduledDifferenceInCosts,
                                             differenceInRevenue,
                                             donations,
                                             totalReveue,
                                             totalWorth)
