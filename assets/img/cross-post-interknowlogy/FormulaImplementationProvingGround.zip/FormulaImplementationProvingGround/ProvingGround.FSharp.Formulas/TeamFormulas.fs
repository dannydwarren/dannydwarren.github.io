﻿namespace ProvingGround.FSharp.Formulas

module TeamFormulas =
    open ProvingGround.FSharp.Formulas.FormulaInputModels
    open ProvingGround.FSharp.Formulas.FormulaOutputModels
    open ProvingGround.FSharp.Formulas.StadiumTeamFormulas
    
    let private WinRatio(totalGames : decimal, wins : decimal) = 
        if totalGames > 0M
        then wins / totalGames
        else 0M

    let private CurrentWins(stadiumTeamInputs : StadiumTeamInput array) =
        Array.sumBy (fun (sti : StadiumTeamInput) -> sti.Wins) stadiumTeamInputs

    let private CurrentTotalGames(stadiumTeamInputs : StadiumTeamInput array) =
        Array.sumBy (fun (sti : StadiumTeamInput) -> TotalGames(sti.Wins, sti.Losses)) stadiumTeamInputs

    let private ChangeInWinRatio(desiredWinRatio : decimal, currentWinRatio : decimal) = desiredWinRatio / currentWinRatio

    let CalculateTeam (teamInput : TeamInput) =
        let currentWins = CurrentWins(teamInput.StadiumTeamInputs)
        let currentTotalGames = CurrentTotalGames(teamInput.StadiumTeamInputs)
        let currentWinRatio = WinRatio(currentTotalGames, currentWins)
        let desiredWinRatio = if teamInput.IsDesiredWinRatioAdjusted then teamInput.DesiredWinRatio else currentWinRatio
        let changeInWinRatio = ChangeInWinRatio(desiredWinRatio, currentWinRatio)

        let changeInWinRatioZippableArray = Array.create teamInput.StadiumTeamInputs.Length changeInWinRatio
        let yearCountZippableArray = Array.create teamInput.StadiumTeamInputs.Length teamInput.YearCount
        let stadiumTeamInputsZippedWithTeamDesiredWinRatioAndYearCount = Array.zip3 teamInput.StadiumTeamInputs changeInWinRatioZippableArray yearCountZippableArray
        let stadiumTeamOutputs = Array.Parallel.map CalculateStadiumTeamOutput stadiumTeamInputsZippedWithTeamDesiredWinRatioAndYearCount

        new TeamOutput(teamInput.Id,
                       currentWins,
                       currentWinRatio,
                       desiredWinRatio,
                       changeInWinRatio,
                       currentTotalGames,
                       stadiumTeamOutputs)
