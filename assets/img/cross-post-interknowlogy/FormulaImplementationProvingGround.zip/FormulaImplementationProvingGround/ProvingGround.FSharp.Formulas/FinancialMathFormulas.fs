﻿namespace ProvingGround.FSharp.Formulas

module FinancialMathFormulas =
    exception FutureValueError of string

    let FutureValue(rate : decimal, nper : decimal, pmt : decimal, pv : decimal) = 
        if pmt <> 0M
        then raise(FutureValueError("pmt parameter on FV must be zero: annuitized FV calculations are not currently supported."))
        else -1M * pv * decimal ( (1.0 + double (rate)) ** double (nper))

    let PresentValue(rate : decimal, values : decimal array) =
        let poweredValues = 
            Array.mapi (fun (i : int) -> fun (value :decimal) -> value / decimal ((1.0 + double(rate)) ** (float (i) + 1.0))) values
        Array.sum poweredValues