﻿namespace ProvingGround.FSharp.Formulas

module internal StadiumYearFormulas = 
    open ProvingGround.FSharp.Formulas.FormulaInputModels

    let private CalculateStadiumUsageForYear(maintenanceSchedule : MaintenanceSchedule, yearIndex : int) =
        match maintenanceSchedule with
        | MaintenanceSchedule.EveryEvenYear -> (yearIndex % 2).Equals(1)
        | MaintenanceSchedule.EverOddYear -> (yearIndex % 2).Equals(0)
        | _ -> false

    let private TotalYearsStadiumIsInUse(maintenanceSchedule : MaintenanceSchedule, yearCount : int) = 
        let years = [|0..yearCount - 1|]
        let yearsInUse : bool array = Array.map (fun (yearIndex : int) -> CalculateStadiumUsageForYear(maintenanceSchedule, yearIndex)) years            
        Array.sumBy (fun i -> if i then 1 else 0) yearsInUse
     
    let private CalculateIntForStadiumUsageForYearIndex = CalculateStadiumUsageForYear >> (fun b -> if b then 1 else 0)

    let CalculateValueForYear (isIncluded : bool) 
                              (maintenanceSchedule : MaintenanceSchedule)
                              (yearCount : int)
                              (yearIndex : int)
                              (rateOfIncrease : decimal)
                              (valueToSchedule : decimal) =
        if isIncluded
        then 
            let totalYearsStadiumIsInUse = decimal (TotalYearsStadiumIsInUse(maintenanceSchedule, yearCount))
            let decimalForStadiumUsageForYearIndex = decimal (CalculateIntForStadiumUsageForYearIndex(maintenanceSchedule, yearIndex))
            valueToSchedule / totalYearsStadiumIsInUse * decimalForStadiumUsageForYearIndex * -1M * FinancialMathFormulas.FutureValue(rateOfIncrease, decimal (yearIndex), 0M, 1M)
        else 0M
