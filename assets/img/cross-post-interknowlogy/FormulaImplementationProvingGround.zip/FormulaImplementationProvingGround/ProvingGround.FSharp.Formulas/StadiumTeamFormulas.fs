﻿namespace ProvingGround.FSharp.Formulas

module internal StadiumTeamFormulas =
    open ProvingGround.FSharp.Formulas.FormulaInputModels
    open ProvingGround.FSharp.Formulas.FormulaOutputModels
    open StadiumTeamCostRevenueFormulas
    open StadiumTeamYearFormulas
    
    let TotalGames (wins : decimal, losses : decimal) = wins + losses

    let private DifferenceInTicketsSold(desiredTicketsSold : decimal, currentTicketsSold : decimal) = desiredTicketsSold - currentTicketsSold

    let private PracticeCosts(differeneceInTicketsSold : decimal, practiceCosts : decimal) = differeneceInTicketsSold * practiceCosts
    let private MarketingCosts(differeneceInTicketsSold : decimal, marketingCosts : decimal) = differeneceInTicketsSold * marketingCosts
    let private ParkingLotMaintenanceCosts(differeneceInTicketsSold : decimal, parkingLotMaintenancePerTicket : decimal) = differeneceInTicketsSold * parkingLotMaintenancePerTicket

    let private DifferenceInRevenue(desiredRevenueTotal : decimal, currentRevenueTotal : decimal) = desiredRevenueTotal - currentRevenueTotal

    let CalculateStadiumTeamOutput( (stadiumTeamInput : StadiumTeamInput, teamChangeInWinRatio : decimal, yearCount : int) ) = 
        let stadiumInput = stadiumTeamInput.StadiumInput
       
        let totalGames = TotalGames(stadiumTeamInput.Wins, stadiumTeamInput.Losses)
        let currentStadiumTeamCostRevenueOutput = CalculateCurrentStadiumTeamCostRevenueOutput(stadiumTeamInput)
        let desiredStadiumTeamCostRevenueOutput = CalculateDesiredStadiumTeamCostRevenueOutput(stadiumTeamInput, teamChangeInWinRatio)
        
        let currentTicketsSold = currentStadiumTeamCostRevenueOutput.TicketsSold
        let desiredTicketsSold = desiredStadiumTeamCostRevenueOutput.TicketsSold
        let differenceInTicketsSold = DifferenceInTicketsSold(desiredTicketsSold, currentTicketsSold)

        let practiceCosts = PracticeCosts(differenceInTicketsSold, stadiumInput.PracticeCost)
        let marketingCosts = MarketingCosts(differenceInTicketsSold, stadiumInput.MarketingCost)
        let parkingLotMaintenanceCosts = ParkingLotMaintenanceCosts(differenceInTicketsSold, stadiumInput.ParkingLotMaintenancePerTicket)

        let differenceInRevenue = DifferenceInRevenue(desiredStadiumTeamCostRevenueOutput.RevenueTotal, currentStadiumTeamCostRevenueOutput.RevenueTotal)

        let costRevenueOutputTuple = (practiceCosts, marketingCosts, parkingLotMaintenanceCosts, differenceInRevenue)

        let stadiumTeamYearOutputs = CalculateStadiumTeamYearOutput(stadiumTeamInput, yearCount, costRevenueOutputTuple)

        new StadiumTeamOutput(stadiumTeamInput.StadiumId,
                              stadiumTeamInput.TeamId,
                              totalGames,
                              currentStadiumTeamCostRevenueOutput,
                              desiredStadiumTeamCostRevenueOutput,
                              currentTicketsSold,
                              desiredTicketsSold,
                              differenceInTicketsSold,
                              practiceCosts,
                              marketingCosts,
                              parkingLotMaintenanceCosts,
                              differenceInRevenue,
                              stadiumTeamYearOutputs)
    

