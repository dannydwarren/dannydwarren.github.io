﻿using System.Windows;
using ProvingGround.FSharp.Formulas;

namespace ProvingGround.FSharp
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();

			
		}
	}
}
