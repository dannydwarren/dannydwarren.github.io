﻿using System;
using System.Linq;
using ProvingGround.FSharp.Formulas;
using ProvingGround.Model;
using ProvingGround.Model.Input;
using ProvingGround.Model.NoMath;

namespace ProvingGround.FSharp.Models
{
	public static class ModelExtensions
	{
		public static FormulaInputModels.TeamInput GetFormulaInputs(this Team team)
		{
			FormulaInputModels.StadiumTeamInput[] stadiumTeamInputs =
				team.StadiumTeamDatas.Select(std => std.GetFormulaInputs()).ToArray();

			return new FormulaInputModels.TeamInput(team.Id,
			                                        team.Input.DesiredWinRatioSetExternally,
			                                        team.Input.DesiredWinRatio,
			                                        team.Input.AdditionalMarketingCost,
			                                        team.Input.Donations,
			                                        FormulaModelInput.YEARS_IN_MODEL,
			                                        stadiumTeamInputs);

		}

		public static FormulaInputModels.FormulaModelInput GetFormulaInputs(this FormulaModel model)
		{
			Team[] teams = model.Leagues.SelectMany(l => l.Divisions).SelectMany(d => d.Teams).ToArray();

			var formulaModelInput = new FormulaInputModels.FormulaModelInput(model.Input.MarketingCostsSetExternally,
			                                                                 model.Input.MarketingCosts,
			                                                                 model.Input.PracticeCostsSetExternally,
			                                                                 model.Input.PracticeCosts,
			                                                                 model.Input.ParkingLotMaintenanceCostsSetExternally,
			                                                                 model.Input.ParkingLotMaintenanceCosts,
			                                                                 (decimal) model.Input.NpvRate,
			                                                                 teams.Sum(t => t.Input.AdditionalMarketingCost),
			                                                                 teams.Sum(t => t.Input.Donations),
			                                                                 model.TheoreticalStadium.GetFormulaInputs(),
			                                                                 FormulaModelInput.YEARS_IN_MODEL);

			return formulaModelInput;
		}

		private static FormulaInputModels.StadiumTeamInput GetFormulaInputs(this StadiumTeamData stadiumTeamData)
		{
			return new FormulaInputModels.StadiumTeamInput(stadiumTeamData.Stadium.Id,
			                                               stadiumTeamData.Team.Id,
			                                               stadiumTeamData.Input.IsHome,
			                                               stadiumTeamData.Input.Wins,
			                                               stadiumTeamData.Input.Losses,
			                                               GetFormulaInputs(stadiumTeamData.Stadium));
		}

		private static FormulaInputModels.StadiumInput GetFormulaInputs(this Stadium stadium)
		{
			return new FormulaInputModels.StadiumInput(stadium.Id,
			                                           stadium.Input.TicketPrice,
			                                           stadium.Input.Seats,
			                                           stadium.Input.ConsessionProfitRatio,
			                                           stadium.Input.AverageConsessionPricePerItem,
			                                           stadium.Input.ConsessionPurchaseRatio,
			                                           stadium.Input.RevenueSplitWithVisitingTeamRatio,
			                                           stadium.Input.LockerRoomRentalFeePercent,
			                                           stadium.Input.PoorSalesFeePercent,
			                                           stadium.Input.PracticeCost,
			                                           stadium.Input.MarketingCost,
			                                           stadium.Input.ParkingLotMaintenancePerTicket,
			                                           Convert(stadium.Input.MaintenanceSchedule),
			                                           stadium.Input.Include,
			                                           stadium.Input.RateOfIncrease);
		}

		private static FormulaInputModels.MaintenanceSchedule Convert(MaintenanceSchedule cSharpSchedule)
		{
			switch (cSharpSchedule)
			{
				case MaintenanceSchedule.EveryEvenYear:
					return FormulaInputModels.MaintenanceSchedule.EveryEvenYear;
				case MaintenanceSchedule.EveryOddYear:
					return FormulaInputModels.MaintenanceSchedule.EverOddYear;
				default:
					throw new ArgumentOutOfRangeException("cSharpSchedule");
			}
		}

		//**************************************************************************************************//
		//**************************************************************************************************//
		//**************************************************************************************************//

		public static void ApplyFormulaOutputs(this Team team, FormulaOutputModels.TeamOutput output)
		{
			team.ChangeInWinRatio = output.ChangeInWinRatio;
			team.CurrentTotalGames = output.CurrentTotalGames;
			team.CurrentWinRatio = output.CurrentWinRatio;
			team.CurrentWins = output.CurrentWins;
			team.DesiredTotalGames = 0;
			team.DesiredWinRatio = output.DesiredWinRatio;

			foreach (FormulaOutputModels.StadiumTeamOutput stadiumTeamOutput in output.StadiumTeamOutputs)
			{
				team.StadiumTeamDatas.First(std => std.Stadium.Id == stadiumTeamOutput.StadiumId)
				    .ApplyFormulaOutputs(stadiumTeamOutput);
			}

			team.Input.SilentlySetDesiredWinRatio(team.DesiredWinRatio);
		}

		public static void ApplyFormulaOutputs(this FormulaModel model,
		                                       FormulaOutputModels.FormualModelOutput output)
		{
			model.CalculatedMarketingCosts = output.CalculatedMarketingCosts;
			model.CalculatedParkingLotMaintenanceCosts = output.CalculatedParkingLotMaintenanceCosts;
			model.CalculatedPracticeCosts = output.CalculatedPracticeCosts;
			model.CurrentTotalGames = 0;
			model.DesiredTotalGames = 0;
			model.DifferenceInMarketingCosts = output.DifferenceInMarketingCosts;
			model.DifferenceInParkingLotMaintenanceCosts = output.DifferenceInParkingLotMaintenanceCosts;
			model.DifferenceInPracticeCosts = output.DiffernceInPracticeCosts;
			foreach (NpvCostRevenueYear npvCostRevenueYear in model.NpvCostRevenueYears)
			{
				npvCostRevenueYear.ApplyFormulaOutputs(
					output.FormulaModelYearOutputs.First(y => y.YearIndex == npvCostRevenueYear.YearIndex));
			}

			model.Input.SilentlySetMarketingCosts(output.CalculatedMarketingCosts);
			model.Input.SilentlySetParkingLotMaintenanceCosts(output.CalculatedParkingLotMaintenanceCosts);
			model.Input.SilentlySetPracticeCosts(output.CalculatedPracticeCosts);
		}

		private static void ApplyFormulaOutputs(this NpvCostRevenueYear npvCostRevenueYear,
		                                        FormulaOutputModels.FormulaModelYearOutput output)
		{
			npvCostRevenueYear.AdditionalMarketingCost = output.AdditionalMarketingCosts;
			npvCostRevenueYear.DifferenceInRevenue = output.DifferenceInRevenue;
			npvCostRevenueYear.Donations = output.Donations;
			npvCostRevenueYear.MarketingCost = output.MarketingCosts;
			npvCostRevenueYear.Npv = output.Npv;
			npvCostRevenueYear.ParkingLotMaintenanceCost = output.ParkingLotMaintenanceCosts;
			npvCostRevenueYear.PracticeCost = output.PracticeCosts;
			npvCostRevenueYear.ScheduledDifferenceInMarketingCosts = output.ScheduledDifferenceInMarketingCosts;
			npvCostRevenueYear.ScheduledDifferenceInParkingLotMaintenanceCosts =
				output.ScheduledDifferenceInParkingLotMaintenanceCosts;
			npvCostRevenueYear.ScheduledDifferenceInPracticeCosts = output.ScheduledDifferenceInPracticeCosts;
			npvCostRevenueYear.TotalCosts = output.TotalCosts;
			npvCostRevenueYear.TotalMarketingCost = output.TotalMarketingCosts;
			npvCostRevenueYear.TotalRevenue = output.TotalReveue;
			npvCostRevenueYear.TotalScheduledDifferenceInCosts = output.TotalScheduledDifferenceInCosts;
			npvCostRevenueYear.TotalWorth = output.TotalWorth;
		}

		private static void ApplyFormulaOutputs(this StadiumTeamData stadiumTeamData,
		                                        FormulaOutputModels.StadiumTeamOutput output)
		{
			stadiumTeamData.CurrentStadiumTeamCostRevenueData.ApplyFormulaOutputs(output.CurrentStadiumTeamCostRevenueData,
			                                                                      output.TotalGames);
			stadiumTeamData.CurrentTicketsSold = output.CurrentTicketsSold;
			stadiumTeamData.DesiredStadiumTeamCostRevenueData.ApplyFormulaOutputs(output.DesiredStadiumTeamCostRevenueData,
			                                                                      output.TotalGames);
			stadiumTeamData.DesiredTicketsSold = output.DesiredTicketsSold;
			stadiumTeamData.DifferenceInRevenue = output.DifferenceInRevenue;
			stadiumTeamData.DifferenceInTicketsSold = output.DifferenceInTicketsSold;
			stadiumTeamData.MarketingCost = output.MarketingCosts;
			stadiumTeamData.ParkingLotMaintenanceCost = output.ParkingLotMaintenanceCosts;
			stadiumTeamData.PracticeCost = output.PracticeCosts;
			foreach (StadiumTeamCostRevenueYear stadiumTeamCostRevenueYear in stadiumTeamData.StadiumTeamCostRevenueYears)
			{
				stadiumTeamCostRevenueYear.ApplyFormulaOutputs(
					output.StadiumTeamYearOutputs.First(y => y.YearIndex == stadiumTeamCostRevenueYear.YearIndex));
			}
		}

		private static void ApplyFormulaOutputs(this StadiumTeamCostRevenueData stadiumTeamCostRevenueData,
		                                        FormulaOutputModels.StadiumTeamCostRevenueOutput output, decimal totalGames)
		{
			stadiumTeamCostRevenueData.ConsessionRevenue = output.ConsessionRevenue;
			stadiumTeamCostRevenueData.ConsessionsSold = output.ConsessionsSold;
			stadiumTeamCostRevenueData.LockerRoomCost = output.LockerRoomCosts;
			stadiumTeamCostRevenueData.PoorSalesCost = output.PoorSalesCosts;
			stadiumTeamCostRevenueData.RevenueFromTickets = output.RevenueFromTickets;
			stadiumTeamCostRevenueData.RevenueSubtotal = output.RevenueSubtotal;
			stadiumTeamCostRevenueData.RevenueTotal = output.RevenueTotal;
			stadiumTeamCostRevenueData.TicketsSold = output.TicketsSold;
			stadiumTeamCostRevenueData.TotalGames = totalGames;
			stadiumTeamCostRevenueData.WinRatio = output.WinRatio;
		}

		private static void ApplyFormulaOutputs(this StadiumTeamCostRevenueYear stadiumTeamCostRevenueYear,
		                                        FormulaOutputModels.StadiumTeamYearOutput output)
		{
			stadiumTeamCostRevenueYear.DifferenceInRevenue = output.DifferenceInRevenue;
			stadiumTeamCostRevenueYear.MarketingCosts = output.MarketingCosts;
			stadiumTeamCostRevenueYear.ParkingLogMaintenanceCosts = output.ParkingLotMaintenanceCosts;
			stadiumTeamCostRevenueYear.PracticeCosts = output.PracticeCosts;
		}
	}
}