﻿using ProvingGround.Model.NoMath;

namespace ProvingGround.FSharp.DataProviders
{
	public interface IDataProvider
	{
		FormulaModel CreateModel();
	}
}