﻿using PropertyDependencyFramework;
using ProvingGround.Model;
using ProvingGround.Model.Input;
using ProvingGround.Model.NoMath;

namespace ProvingGround.FSharp.DataProviders
{
	public class MatchesModelNoMathDataProvider : IDataProvider
	{
		private static readonly int LEAGUE_COUNT = 1;
		private static readonly int DIVISION_COUNT = 1;
		private static readonly int TEAM_COUNT = 2;
		private static readonly int STADIUM_COUNT = 2;


		public FormulaModel CreateModel()
		{
			var stadiums = new DependencyFrameworkObservableCollection<Stadium>();

			for ( int i = 0; i < STADIUM_COUNT; i++ )
			{
				Stadium stadium = CreateStadium();
				stadiums.Add( stadium );
			}

			var theoreticalStadium = new Stadium( "TheoreticalStadium", new StadiumInput
															   {
																   TicketPrice = 300,
																   Seats = 70000,
																   ConsessionProfitRatio = .8M,
																   AverageConsessionPricePerItem = 15,
																   ConsessionPurchaseRatio = .75M,
																   RevenueSplitWithVisitingTeamRatio = .6M,
																   LockerRoomRentalFeePercent = .09M,
																   PoorSalesFeePercent = .18M,
																   PracticeCost = 3,
																   MarketingCost = 7,
																   ParkingLotMaintenancePerTicket = 2,
																   MaintenanceSchedule = MaintenanceSchedule.EveryOddYear,
															   } );


			var formulaModel = new FormulaModel( theoreticalStadium, new FormulaModelInput
															  {
																  NpvRate = .15,
															  } );

			for ( int i = 0; i < LEAGUE_COUNT; i++ )
			{
				League league = CreateLeague( stadiums, formulaModel );
				formulaModel.Leagues.Add( league );
			}


			return formulaModel;

			
		}

		private readonly string _stadium1CityName = "San Diego";
		private readonly string _stadium2CityName = "Austin";
		private int _stadiumSwitch = 1;
		private Stadium CreateStadium()
		{
			Stadium stadium;
			if ( _stadiumSwitch % 2 == 1 )
			{
				stadium = new Stadium( _stadium1CityName, new StadiumInput
														{
															TicketPrice = 100,
															Seats = 40000,
															ConsessionProfitRatio = .75M,
															AverageConsessionPricePerItem = 10,
															ConsessionPurchaseRatio = .6M,
															RevenueSplitWithVisitingTeamRatio = .5M,
															LockerRoomRentalFeePercent = .05M,
															PoorSalesFeePercent = .25M,
															PracticeCost = 2,
															MarketingCost = 5,
															ParkingLotMaintenancePerTicket = 3,
															MaintenanceSchedule = MaintenanceSchedule.EveryEvenYear,
															Include = true,
															RateOfIncrease = 0,
														} );
			}
			else
			{
				stadium = new Stadium( _stadium2CityName, new StadiumInput
														{
															TicketPrice = 500,
															Seats = 80000,
															ConsessionProfitRatio = .65M,
															AverageConsessionPricePerItem = 25,
															ConsessionPurchaseRatio = .9M,
															RevenueSplitWithVisitingTeamRatio = .25M,
															LockerRoomRentalFeePercent = .15M,
															PoorSalesFeePercent = .15M,
															PracticeCost = 4,
															MarketingCost = 10,
															ParkingLotMaintenancePerTicket = 6,
															MaintenanceSchedule = MaintenanceSchedule.EveryOddYear,
															Include = true,
															RateOfIncrease = 0,
														} );
			}
			_stadiumSwitch++;

			return stadium;
		}

		private League CreateLeague( DependencyFrameworkObservableCollection<Stadium> stadiums, FormulaModel model )
		{
			var divisions = new DependencyFrameworkObservableCollection<Division>();
			for ( int i = 0; i < DIVISION_COUNT; i++ )
			{
				Division division = CreateDivision( stadiums, model );
				divisions.Add( division );
			}

			var league = new League( divisions );

			return league;
		}

		private Division CreateDivision( DependencyFrameworkObservableCollection<Stadium> stadiums, FormulaModel model )
		{
			var teams = new DependencyFrameworkObservableCollection<Team>();
			for ( int i = 0; i < TEAM_COUNT; i++ )
			{
				Team team = CreateTeam( stadiums, model );
				teams.Add( team );
			}

			var division = new Division( teams );

			return division;
		}

		private readonly string _team1Name = "Team1";
		private readonly string _team2Name = "Team2";
		private int _teamSwitch = 1;
		private Team CreateTeam( DependencyFrameworkObservableCollection<Stadium> stadiums, FormulaModel model )
		{
			Team team;
			if ( _teamSwitch % 2 == 1 )
			{
				team = new Team( _team1Name, new TeamInput(Team.NextId) );

			}
			else
			{
				team = new Team( _team2Name, new TeamInput(Team.NextId) );
			}

			foreach ( Stadium stadium in stadiums )
			{
				StadiumTeamData stadiumTeamData = CreateStadiumTeamData( stadium, team, model );
			}

			_teamSwitch++;
			return team;
		}

		private StadiumTeamData CreateStadiumTeamData( Stadium stadium, Team team, FormulaModel model )
		{
			bool isTeam1 = team.Name == _team1Name;
			bool isStadium1 = stadium.CityName == _stadium1CityName;

			bool isHome;
			decimal wins;
			decimal losses;
			if ( isTeam1 )
			{
				if ( isStadium1 )
				{
					isHome = true;
					wins = 12;
					losses = 8;
				}
				else
				{
					isHome = false;
					wins = 7;
					losses = 13;
				}
			}
			else
			{
				if ( isStadium1 )
				{
					isHome = false;
					wins = 8;
					losses = 12;
				}
				else
				{
					isHome = true;
					wins = 13;
					losses = 7;
				}
			}


			var stadiumTeamData = new StadiumTeamData( stadium, team, new StadiumTeamDataInput(stadium.Id, team.Id)
																		 {
																			 IsHome = isHome,
																			 Wins = wins,
																			 Losses = losses,
																		 }, model );

			return stadiumTeamData;
		}

	}
}
