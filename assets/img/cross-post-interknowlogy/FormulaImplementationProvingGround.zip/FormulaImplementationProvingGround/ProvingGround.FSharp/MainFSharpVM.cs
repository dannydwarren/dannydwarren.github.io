﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Microsoft.Practices.Prism.PubSubEvents;
using PropertyDependencyFramework;
using ProvingGround.FSharp.DataProviders;
using ProvingGround.FSharp.Formulas;
using ProvingGround.FSharp.Models;
using ProvingGround.Model;
using ProvingGround.Model.Input;
using ProvingGround.Model.NoMath;

namespace ProvingGround.FSharp
{
	public class MainFSharpVM : Bindable
	{
		public MainFSharpVM()
		{
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();

			//IDataProvider dp = new MatchesModelNoMathDataProvider();
			IDataProvider dp = new PerformanceTestNoMathDataProvider();
			Model = dp.CreateModel();

			Debug.WriteLine( string.Format( "Model Created: {0}", stopwatch.ElapsedMilliseconds ) );

			EventAggregatorProvider.Instance.EventAggregator.GetEvent<PubSubEvent<object>>().Subscribe(CalculateFormulas);
			EventAggregatorProvider.Instance.EventAggregator.GetEvent<PubSubEvent<TeamInputChangedPayload>>().Subscribe(CalculateFormulas);
			EventAggregatorProvider.Instance.EventAggregator.GetEvent<PubSubEvent<StadiumTeamDataInputChangedPayload>>().Subscribe(CalculateFormulas);

			Debug.WriteLine( string.Format( "Callbacks Registered: {0}", stopwatch.ElapsedMilliseconds ) );

			CalculateFormulas();
	
			Debug.WriteLine( string.Format( "Initial Calc: {0}", stopwatch.ElapsedMilliseconds ) );

			stopwatch.Stop();

			Debug.WriteLine(string.Format("DependsCount: {0}", BindableBase.DependsCount));
			Debug.WriteLine(string.Format("DependsCountWork: {0}", BindableBase.DependsCountWork));
			Debug.WriteLine(string.Format("StadiumTeamDataCount: {0}", StadiumTeamData.StadiumTeamDataCount));
			
		}


		private void CalculateFormulas(object obj)
		{
			//FUTURE: Model only calculation required
			CalculateFormulas();
		}
		private void CalculateFormulas(TeamInputChangedPayload teamInputChangedPayload)
		{
			//FUTURE: Single Team and Model calculation required
			CalculateFormulas();
		}
		private void CalculateFormulas(StadiumTeamDataInputChangedPayload stadiumTeamDataInputChangedPayload)
		{
			//FUTURE: Single Team and Model calculation required - Possibly replace with TeamInputChangedPayload event?
			CalculateFormulas();
		}

		private void CalculateFormulas()
		{
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();

			//NOTE: Get Inputs
			FormulaInputModels.TeamInput[] teamInputs =
				Model.Leagues.SelectMany( l => l.Divisions ).SelectMany( d => d.Teams ).Select( t => t.GetFormulaInputs() ).ToArray();

			Debug.WriteLine( string.Format( "Retrieved Inputs: {0}", stopwatch.ElapsedMilliseconds ) );

			//NOTE: Calculate Inputs
			FormulaOutputModels.TeamOutput[] teamOutputs =
				teamInputs.Select( TeamFormulas.CalculateTeam ).AsParallel().ToArray();

			Debug.WriteLine( string.Format( "Performed Team Calcs: {0}", stopwatch.ElapsedMilliseconds ) );

			FormulaOutputModels.StadiumTeamYearOutput[][] stadiumTeamYearOutputsGroupedByYearIndex =
				teamOutputs
					.SelectMany( t => t.StadiumTeamOutputs )
					.SelectMany( stdo => stdo.StadiumTeamYearOutputs )
					.GroupBy( y => y.YearIndex )
					.Select( g => g.ToArray() )
					.ToArray();

			FormulaInputModels.FormulaModelInput fSharpFormulaModelInput = Model.GetFormulaInputs();

			FormulaOutputModels.FormualModelOutput formulaModelOutput =
				FormulaModelFormulas.CalculateFormulaModel( fSharpFormulaModelInput, stadiumTeamYearOutputsGroupedByYearIndex );

			Debug.WriteLine( string.Format( "Performed Model Calcs: {0}", stopwatch.ElapsedMilliseconds ) );

			//NOTE: Apply Outputs

			Team[] teams = Model.Leagues.SelectMany( l => l.Divisions ).SelectMany( d => d.Teams ).ToArray();

			foreach ( Team team in teams )
			{
				team.ApplyFormulaOutputs( teamOutputs.First( to => to.Id == team.Id ) );
			}
			Model.ApplyFormulaOutputs( formulaModelOutput );

			Debug.WriteLine( string.Format( "Outputs Applied: {0}", stopwatch.ElapsedMilliseconds ) );

			stopwatch.Stop();
		}

		private FormulaModel _model;
		public FormulaModel Model
		{
			[DebuggerStepThrough]
			get { return _model; }
			set
			{
				if ( value == _model )
					return;

				_model = value;
				NotifyPropertyChanged( () => Model );
			}
		}

	}
}