﻿namespace PropertyDependencyFramework
{
	internal interface IBindableHiddenBaseAPI
	{
		void OnPropertyChanged(string propertyName);
	}
}