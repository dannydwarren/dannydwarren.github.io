﻿using System.Diagnostics;
using PropertyDependencyFramework;
using ProvingGround.PDFx.DataProviders;
using ProvingGround.PDFx.Model;

namespace ProvingGround.PDFx
{
	public class MainVM : Bindable
	{
		public MainVM()
		{
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();

			//IDataProvider dp = new MatchesModelDataProvider();
			IDataProvider dp = new PerformanceTestDataProvider();
			Model = dp.CreateModel();

			Debug.WriteLine(string.Format("Model Created: {0}", stopwatch.ElapsedMilliseconds));
			
			Model.IntitializeCallbacks();

			Debug.WriteLine(string.Format("Model Callbacks Initialized: {0}", stopwatch.ElapsedMilliseconds));

			//forcing calculations to run which will cause all registrations to occur.
			foreach (NpvCostRevenueYear npvCostRevenueYear in Model.NpvCostRevenueYears)
			{
				decimal value = npvCostRevenueYear.Npv;
			}

			Debug.WriteLine(string.Format("Model Registrations Complete: {0}", stopwatch.ElapsedMilliseconds));
			
			stopwatch.Stop();

			Debug.WriteLine(string.Format("DependsCount: {0}", BindableBase.DependsCount));
			Debug.WriteLine(string.Format("DependsCountWork: {0}", BindableBase.DependsCountWork));
			Debug.WriteLine(string.Format("StadiumTeamDataCount: {0}", StadiumTeamData.StadiumTeamDataCount));
		}

		private FormulaModel _model;
		public FormulaModel Model
		{
			[DebuggerStepThrough]
			get { return _model; }
			set
			{
				if ( value == _model )
					return;

				_model = value;
				NotifyPropertyChanged( () => Model );
			}
		}
	}
}