﻿using ProvingGround.PDFx.Model;

namespace ProvingGround.PDFx.DataProviders
{
	public interface IDataProvider
	{
		FormulaModel CreateModel();
	}
}