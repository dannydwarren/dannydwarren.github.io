﻿using System.Linq;
using PropertyDependencyFramework;

namespace ProvingGround.PDFx.Model
{
	public class League : Bindable
	{
		public League(DependencyFrameworkObservableCollection<Division> divisions )
		{
			Divisions = divisions;
		}

		public DependencyFrameworkObservableCollection<Division> Divisions { get; private set; }

		public decimal TotalCosts
		{
			get
			{
				Property( () => TotalCosts )
					.Depends( p => p.OnCollectionChildProperty( Divisions, d => d.TotalCosts ) );

				return CachedValue( () => TotalCosts, () => Divisions.Sum( d => d.TotalCosts ) );
			}
		}

		public void InitializeCallbacks()
		{
			foreach (Division division in Divisions)
			{
				division.InitializeCallbacks();
			}
		}
	}
}