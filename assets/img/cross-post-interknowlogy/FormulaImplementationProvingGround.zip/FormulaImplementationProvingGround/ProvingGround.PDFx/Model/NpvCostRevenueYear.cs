﻿using System.Linq;
using PropertyDependencyFramework;
using ProvingGround.Model.Input;
using ProvingGround.PDFx.Model.Input;

namespace ProvingGround.PDFx.Model
{
	public class NpvCostRevenueYear : CostRevenueYear
	{
		private readonly Stadium _theoreticalStadium;
		public NpvCostRevenueYear( int yearIndex, int totalYears, Stadium theoreticalStadium, FormulaModel model )
			: base( yearIndex, totalYears )
		{
			Model = model;
			StadiumTeamCostRevenueYears = new DependencyFrameworkObservableCollection<StadiumTeamCostRevenueYear>();
			TeamInputs = new DependencyFrameworkObservableCollection<TeamInput>();

			_theoreticalStadium = theoreticalStadium;
		}

		public sealed override Stadium Stadium { get { return _theoreticalStadium; } }
		public FormulaModel Model { get; private set; }
		public DependencyFrameworkObservableCollection<TeamInput> TeamInputs { get; private set; }
		public DependencyFrameworkObservableCollection<StadiumTeamCostRevenueYear> StadiumTeamCostRevenueYears { get; private set; }

		public decimal MarketingCost
		{
			get
			{
				Property( () => MarketingCost )
					.Depends( p => p.OnCollectionChildProperty( StadiumTeamCostRevenueYears, y => y.MarketingCosts ) );

				return CachedValue( () => MarketingCost, () => StadiumTeamCostRevenueYears.Sum( y => y.MarketingCosts ) );
			}
		}

		public decimal AdditionalMarketingCost
		{
			get
			{
				Property( () => AdditionalMarketingCost )
					.Depends( p => p.OnCollectionChildProperty( TeamInputs, ti => ti.AdditionalMarketingCost )
									.AndOn( Stadium.Input, s => s.MaintenanceSchedule ) );

				return CachedValue( () => AdditionalMarketingCost,
					() => TeamInputs.Sum( ti => ti.AdditionalMarketingCost ) / TotalYearsStadiumIsInUse
						  * CalculatedIntForIsStadiumUsedThisYear
						  * (-1 * FinancialMath.FutureValue( Stadium.Input.RateOfIncrease, YearIndex, 0, 1 )) );
			}
		}

		public decimal TotalMarketingCost
		{
			get
			{
				Property( () => TotalMarketingCost )
					.Depends( p => p.On( () => MarketingCost )
									.AndOn( () => AdditionalMarketingCost ) );

				return CachedValue( () => TotalMarketingCost, () => MarketingCost + AdditionalMarketingCost );
			}
		}

		public decimal PracticeCost
		{
			get
			{
				Property( () => PracticeCost )
					.Depends( p => p.OnCollectionChildProperty( StadiumTeamCostRevenueYears, y => y.PracticeCosts ) );

				return CachedValue( () => PracticeCost, () => StadiumTeamCostRevenueYears.Sum( y => y.PracticeCosts ) );
			}
		}

		public decimal ParkingLotMaintenanceCost
		{
			get
			{
				Property( () => ParkingLotMaintenanceCost )
					.Depends( p => p.OnCollectionChildProperty( StadiumTeamCostRevenueYears, y => y.ParkingLogMaintenanceCosts ) );

				return CachedValue( () => ParkingLotMaintenanceCost, () => StadiumTeamCostRevenueYears.Sum( y => y.ParkingLogMaintenanceCosts ) );
			}
		}

		public decimal TotalCosts
		{
			get
			{
				Property( () => TotalCosts )
					.Depends( p => p.On( () => TotalMarketingCost )
									.AndOn( () => PracticeCost )
									.AndOn( () => ParkingLotMaintenanceCost ) );

				return CachedValue( () => TotalCosts, () => TotalMarketingCost + PracticeCost + ParkingLotMaintenanceCost );
			}
		}

		public decimal ScheduledDifferenceInMarketingCosts
		{
			get
			{
				Property( () => ScheduledDifferenceInMarketingCosts )
					.Depends( p => p.On( Model, m => m.DifferenceInMarketingCosts )
								   .AndOn( Stadium.Input, s => s.MaintenanceSchedule ) );

				return CachedValue( () => ScheduledDifferenceInMarketingCosts,
								   () => Model.DifferenceInMarketingCosts / TotalYearsStadiumIsInUse
										 * CalculatedIntForIsStadiumUsedThisYear
										 * (-1 * FinancialMath.FutureValue( Stadium.Input.RateOfIncrease, YearIndex, 0, 1 )) );

			}
		}

		public decimal ScheduledDifferenceInPracticeCosts
		{
			get
			{
				Property( () => ScheduledDifferenceInPracticeCosts )
					.Depends( p => p.On( Model, m => m.DifferenceInPracticeCosts )
								   .AndOn( Stadium.Input, s => s.MaintenanceSchedule ) );

				return CachedValue( () => ScheduledDifferenceInPracticeCosts,
								   () => Model.DifferenceInPracticeCosts / TotalYearsStadiumIsInUse
										 * CalculatedIntForIsStadiumUsedThisYear
										 * (-1 * FinancialMath.FutureValue( Stadium.Input.RateOfIncrease, YearIndex, 0, 1 )) );
			}
		}

		public decimal ScheduledDifferenceInParkingLotMaintenanceCosts
		{
			get
			{
				Property( () => ScheduledDifferenceInParkingLotMaintenanceCosts )
					.Depends( p => p.On( Model, m => m.DifferenceInParkingLotMaintenanceCosts )
								   .AndOn( Stadium.Input, s => s.MaintenanceSchedule ) );

				return CachedValue( () => ScheduledDifferenceInParkingLotMaintenanceCosts,
								   () => Model.DifferenceInParkingLotMaintenanceCosts / TotalYearsStadiumIsInUse
										 * CalculatedIntForIsStadiumUsedThisYear
										 * (-1 * FinancialMath.FutureValue( Stadium.Input.RateOfIncrease, YearIndex, 0, 1 )) );
			}
		}

		public decimal TotalScheduledDifferenceInCosts
		{
			get
			{
				Property( () => TotalScheduledDifferenceInCosts )
					.Depends( p => p.On( () => ScheduledDifferenceInMarketingCosts )
									.AndOn( () => ScheduledDifferenceInPracticeCosts )
									.AndOn( () => ScheduledDifferenceInParkingLotMaintenanceCosts ) );

				return CachedValue( () => TotalScheduledDifferenceInCosts, () => ScheduledDifferenceInMarketingCosts + ScheduledDifferenceInPracticeCosts + ScheduledDifferenceInParkingLotMaintenanceCosts );
			}
		}

		public decimal DifferenceInRevenue
		{
			get
			{
				Property( () => DifferenceInRevenue )
					.Depends( p => p.OnCollectionChildProperty( StadiumTeamCostRevenueYears, y => y.DifferenceInRevenue ) );

				return CachedValue( () => DifferenceInRevenue, () => StadiumTeamCostRevenueYears.Sum( y => y.DifferenceInRevenue ) );
			}
		}

		public decimal Donations
		{
			get
			{
				Property( () => Donations )
					.Depends( p => p.OnCollectionChildProperty( TeamInputs, ti => ti.Donations )
									.AndOn( Stadium.Input, s => s.MaintenanceSchedule ) );

				return CachedValue( () => Donations,
								   () => TeamInputs.Sum( ti => ti.Donations ) / TotalYearsStadiumIsInUse
										 * CalculatedIntForIsStadiumUsedThisYear
										 * (-1 * FinancialMath.FutureValue( Stadium.Input.RateOfIncrease, YearIndex, 0, 1 )) );

			}
		}

		public decimal TotalRevenue
		{
			get
			{
				Property( () => TotalRevenue )
					.Depends( p => p.On( () => DifferenceInRevenue )
									.AndOn( () => Donations ) );

				return CachedValue( () => TotalRevenue, () => DifferenceInRevenue + Donations );
			}
		}

		public decimal TotalWorth
		{
			get
			{
				Property( () => TotalWorth )
					.Depends( p => p.On( () => TotalRevenue )
									.AndOn( () => TotalScheduledDifferenceInCosts )
									.AndOn( () => TotalCosts ) );

				return CachedValue( () => TotalWorth, () => TotalRevenue - TotalScheduledDifferenceInCosts - TotalCosts );
			}
		}

		public decimal Npv
		{
			get
			{
				Property( () => Npv )
					.Depends( p => p.On( () => TotalWorth )
								   .AndOn( Model.Input, i => i.NpvRate )
								   .AndOnCollectionChildProperty( Model.NpvCostRevenueYears, y => y.TotalWorth ) );

				return CachedValue( () => Npv,
								   () => FinancialMath.PresentValue( Model.Input.NpvRate,
																	Model.NpvCostRevenueYears
																		 .Where( y => y.YearIndex <= YearIndex )
																		 .Select( y => y.TotalWorth )
																		 .ToArray() ) );
			}
		}
	}
}