﻿using System.Linq;
using PropertyDependencyFramework;

namespace ProvingGround.PDFx.Model
{
	public class Division : Bindable
	{
		public Division( DependencyFrameworkObservableCollection<Team> teams )
		{
			Teams = teams;
		}

		public DependencyFrameworkObservableCollection<Team> Teams { get; private set; }

		public decimal TotalCosts
		{
			get
			{
				Property( () => TotalCosts )
					.Depends( p => p.OnCollectionChildProperty( Teams, t => t.TotalCosts ) );

				return CachedValue( () => TotalCosts, () => Teams.Sum( t => t.TotalCosts ) );
			}
		}

		public void InitializeCallbacks()
		{
			foreach ( Team team in Teams )
			{
				team.InitializeCallbacks();
			}
		}
	}
}