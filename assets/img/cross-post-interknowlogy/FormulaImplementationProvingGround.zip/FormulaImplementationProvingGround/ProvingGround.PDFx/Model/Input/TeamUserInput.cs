﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProvingGround.Model.Input;

namespace ProvingGround.PDFx.Model.Input
{
	public class TeamUserInput : TeamInput
	{
		public Team Team { get; set; }

		public void InitializeCallbacks()
		{
			DesiredWinRatioCallback();
			RegisterCallbackDependency( Team, t => t.CurrentWinRatio, DesiredWinRatioCallback );
		}

		private void DesiredWinRatioCallback()
		{
			_desiredWinRatioSettingInternally = true;
			DesiredWinRatio = Team.CurrentWinRatio;
			_desiredWinRatioSettingInternally = false;
		}
	}
}
