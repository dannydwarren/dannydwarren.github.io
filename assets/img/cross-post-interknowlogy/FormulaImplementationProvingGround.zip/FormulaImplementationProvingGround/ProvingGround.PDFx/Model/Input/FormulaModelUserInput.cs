﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProvingGround.Model.Input;

namespace ProvingGround.PDFx.Model.Input
{
	public class FormulaModelUserInput : FormulaModelInput
	{
		public FormulaModel FormulaModel { get; set; }

		public void InitializeCallbacks()
		{
			MarketingCostsCallback();
			RegisterCallbackDependency( FormulaModel, m => m.CalculatedMarketingCosts, MarketingCostsCallback );
			PracticeCostsCallback();
			RegisterCallbackDependency( FormulaModel, m => m.CalculatedPracticeCosts, PracticeCostsCallback );
			ParkingLotMaintenanceCostsCallback();
			RegisterCallbackDependency( FormulaModel, m => m.CalculatedParkingLotMaintenanceCosts, ParkingLotMaintenanceCostsCallback );
		}

		private void MarketingCostsCallback()
		{
			_marketingCostsSettingInternally = true;
			MarketingCosts = FormulaModel.CalculatedMarketingCosts;
			_marketingCostsSettingInternally = false;
		}

		private void PracticeCostsCallback()
		{
			_practiceCostsSettingInternally = true;
			PracticeCosts = FormulaModel.CalculatedPracticeCosts;
			_practiceCostsSettingInternally = false;
		}

		private void ParkingLotMaintenanceCostsCallback()
		{
			_parkingLotMaintenanceCostsSettingInternally = true;
			ParkingLotMaintenanceCosts = FormulaModel.CalculatedParkingLotMaintenanceCosts;
			_parkingLotMaintenanceCostsSettingInternally = false;
		}

	}
}
