﻿
using System;
using System.Collections.Generic;
using System.Linq;

namespace ProvingGround.PDFx.Model
{
	public static class Extensions
	{
		 public static decimal SumIfAny<T>(this IEnumerable<T> collection, Func<T, decimal> selector)
		 {
			 var enumerable = collection as T[] ?? collection.ToArray();
			 if (enumerable.Count() == 0)
			 {
				 return 0;
			 }

			 return enumerable.Sum(selector);
		 }
	}
}