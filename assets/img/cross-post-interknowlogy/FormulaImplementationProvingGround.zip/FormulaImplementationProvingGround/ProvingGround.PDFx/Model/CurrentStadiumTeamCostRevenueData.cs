﻿namespace ProvingGround.PDFx.Model
{
	public class CurrentStadiumTeamCostRevenueData : StadiumTeamCostRevenueData
	{
		public CurrentStadiumTeamCostRevenueData( StadiumTeamData stadiumTeamData )
			: base( stadiumTeamData )
		{
		}

		public sealed override decimal WinRatio
		{
			get
			{
				Property( () => WinRatio )
					.Depends( p => p.On( StadiumTeamData.Stadium.Input, s => s.Include )
									.AndOn( StadiumTeamData.Input, i => i.Wins )
									.AndOn( () => TotalGames ) );

				return CachedValue( () => WinRatio,
								   () =>
								   {
									   if ( StadiumTeamData.Stadium.Input.Include )
									   {
										   return StadiumTeamData.Input.Wins / TotalGames;
									   }
									   return 0;
								   } );
			}
		}
	}
}