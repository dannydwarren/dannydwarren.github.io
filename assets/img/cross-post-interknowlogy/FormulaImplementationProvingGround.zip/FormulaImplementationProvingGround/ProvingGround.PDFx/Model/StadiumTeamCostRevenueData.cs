﻿using PropertyDependencyFramework;

namespace ProvingGround.PDFx.Model
{
	public abstract class StadiumTeamCostRevenueData : Bindable
	{
		protected StadiumTeamCostRevenueData( StadiumTeamData stadiumTeamData )
		{
			StadiumTeamData = stadiumTeamData;
		}

		public StadiumTeamData StadiumTeamData { get; private set; }

		public decimal TotalGames
		{
			get
			{
				Property( () => TotalGames )
					.Depends( p => p.On( StadiumTeamData.Input, i => i.Wins )
								   .AndOn( StadiumTeamData.Input, i => i.Losses ) );

				return CachedValue( () => TotalGames, () => StadiumTeamData.Input.Wins + StadiumTeamData.Input.Losses );
			}
		}

		public abstract decimal WinRatio { get; }

		public decimal TicketsSold
		{
			get
			{
				Property( () => TicketsSold )
					.Depends( p => p.On( () => WinRatio )
								   .AndOn( StadiumTeamData.Stadium.Input, s => s.Seats ) );

				return CachedValue( () => TicketsSold, () => WinRatio * StadiumTeamData.Stadium.Input.Seats );
			}
		}

		public decimal RevenueFromTickets
		{
			get
			{
				Property( () => RevenueFromTickets )
					.Depends( p => p.On( StadiumTeamData.Input, i => i.IsHome )
								   .AndOn( () => TicketsSold )
								   .AndOn( StadiumTeamData.Stadium.Input, s => s.TicketPrice )
								   .AndOn( StadiumTeamData.Stadium.Input, s => s.RevenueSplitWithVisitingTeamRatio ) );

				return CachedValue( () => RevenueFromTickets,
								   () =>
								   {
									   if ( StadiumTeamData.Input.IsHome )
									   {
										   return TicketsSold * StadiumTeamData.Stadium.Input.TicketPrice *
												  StadiumTeamData.Stadium.Input.RevenueSplitWithVisitingTeamRatio;
									   }

									   return TicketsSold * StadiumTeamData.Stadium.Input.TicketPrice *
											  (1 - StadiumTeamData.Stadium.Input.RevenueSplitWithVisitingTeamRatio);
								   } );
			}
		}

		public decimal ConsessionsSold
		{
			get
			{
				Property( () => ConsessionsSold )
					.Depends( p => p.On( () => TicketsSold )
								   .AndOn( StadiumTeamData.Stadium.Input, s => s.ConsessionPurchaseRatio ) );

				return CachedValue( () => ConsessionsSold, () => TicketsSold * StadiumTeamData.Stadium.Input.ConsessionPurchaseRatio );
			}
		}

		public decimal ConsessionRevenue
		{
			get
			{
				Property( () => ConsessionRevenue )
					.Depends( p => p.On( StadiumTeamData.Input, i => i.IsHome )
								   .AndOn( () => ConsessionsSold )
								   .AndOn( StadiumTeamData.Stadium.Input, s => s.AverageConsessionPricePerItem )
								   .AndOn( StadiumTeamData.Stadium.Input, s => s.ConsessionProfitRatio )
								   .AndOn( StadiumTeamData.Stadium.Input, s => s.RevenueSplitWithVisitingTeamRatio ) );

				return CachedValue( () => ConsessionRevenue,
								   () =>
								   {
									   if ( StadiumTeamData.Input.IsHome )
									   {
										   return ConsessionsSold * StadiumTeamData.Stadium.Input.ConsessionProfitRatio
												  * StadiumTeamData.Stadium.Input.AverageConsessionPricePerItem
												  * StadiumTeamData.Stadium.Input.RevenueSplitWithVisitingTeamRatio;
									   }

									   return ConsessionsSold * StadiumTeamData.Stadium.Input.ConsessionProfitRatio
											  * StadiumTeamData.Stadium.Input.AverageConsessionPricePerItem
											  * (1 - StadiumTeamData.Stadium.Input.RevenueSplitWithVisitingTeamRatio);
								   } );
			}
		}

		public decimal RevenueSubtotal
		{
			get
			{
				Property( () => RevenueSubtotal )
					.Depends( p => p.On( () => RevenueFromTickets )
								   .AndOn( () => ConsessionRevenue ) );

				return CachedValue( () => RevenueSubtotal, () => RevenueFromTickets + ConsessionRevenue );
			}
		}

		public decimal LockerRoomCost
		{
			get
			{
				Property( () => LockerRoomCost )
					.Depends( p => p.On( StadiumTeamData.Input, i => i.IsHome )
								   .AndOn( () => RevenueSubtotal )
								   .AndOn( StadiumTeamData.Stadium.Input, s => s.LockerRoomRentalFeePercent ) );

				return CachedValue( () => LockerRoomCost,
								   () =>
								   {
									   if ( StadiumTeamData.Input.IsHome )
									   {
										   return 0;
									   }

									   return RevenueSubtotal * StadiumTeamData.Stadium.Input.LockerRoomRentalFeePercent;
								   } );
			}
		}

		public decimal PoorSalesCost
		{
			get
			{
				Property( () => PoorSalesCost )
					.Depends( p => p.On( StadiumTeamData.Input, i => i.IsHome )
								   .AndOn( () => RevenueSubtotal )
								   .AndOn( StadiumTeamData.Stadium.Input, s => s.PoorSalesFeePercent ) );

				return CachedValue( () => PoorSalesCost,
					() =>
					{
						if ( StadiumTeamData.Input.IsHome )
						{
							return 0;
						}

						return RevenueSubtotal * StadiumTeamData.Stadium.Input.PoorSalesFeePercent;
					} );
			}
		}

		public decimal RevenueTotal
		{
			get
			{
				Property( () => RevenueTotal )
					.Depends( p => p.On( () => RevenueSubtotal )
									.AndOn( () => LockerRoomCost )
									.AndOn( () => PoorSalesCost ) );

				return CachedValue( () => RevenueTotal, () => RevenueSubtotal - LockerRoomCost - PoorSalesCost );
			}
		}
	}
}