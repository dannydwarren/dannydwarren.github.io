﻿using System.Linq;
using PropertyDependencyFramework;
using ProvingGround.PDFx.Model.Input;

namespace ProvingGround.PDFx.Model
{
	public class FormulaModel : Bindable
	{
		public FormulaModel( Stadium theoreticalStadium, FormulaModelUserInput input )
		{
			NpvCostRevenueYears = new DependencyFrameworkObservableCollection<NpvCostRevenueYear>();
			Leagues = new DependencyFrameworkObservableCollection<League>();

			TheoreticalStadium = theoreticalStadium;

			for ( int i = 0; i < FormulaModelUserInput.YEARS_IN_MODEL; i++ )
			{
				var year = new NpvCostRevenueYear( i, FormulaModelUserInput.YEARS_IN_MODEL, TheoreticalStadium, this );
				NpvCostRevenueYears.Add(year);
			}

			input.FormulaModel = this;
			Input = input;
		}

		public FormulaModelUserInput Input { get; private set; }
		public DependencyFrameworkObservableCollection<League> Leagues { get; private set; }
		public Stadium TheoreticalStadium { get; private set; }
		public DependencyFrameworkObservableCollection<NpvCostRevenueYear> NpvCostRevenueYears { get; private set; }

		public decimal CalculatedMarketingCosts
		{
			get
			{
				Property( () => CalculatedMarketingCosts )
					.Depends( p => p.OnCollectionChildProperty( NpvCostRevenueYears, y => y.MarketingCost ) );

				return CachedValue( () => CalculatedMarketingCosts, () => NpvCostRevenueYears.Sum( y => y.MarketingCost ) );
			}
		}

		public decimal CalculatedPracticeCosts
		{
			get
			{
				Property( () => CalculatedPracticeCosts )
					.Depends( p => p.OnCollectionChildProperty( NpvCostRevenueYears, y => y.PracticeCost ) );

				return CachedValue( () => CalculatedPracticeCosts, () => NpvCostRevenueYears.Sum( y => y.PracticeCost ) );
			}
		}

		public decimal CalculatedParkingLotMaintenanceCosts
		{
			get
			{
				Property( () => CalculatedParkingLotMaintenanceCosts )
					.Depends( p => p.OnCollectionChildProperty( NpvCostRevenueYears, y => y.ParkingLotMaintenanceCost ) );

				return CachedValue( () => CalculatedParkingLotMaintenanceCosts, () => NpvCostRevenueYears.Sum( y => y.ParkingLotMaintenanceCost ) );
			}
		}

		public decimal DifferenceInMarketingCosts
		{
			get
			{
				Property( () => DifferenceInMarketingCosts )
					.Depends( p => p.On( Input, i => i.MarketingCosts )
									.AndOn( () => CalculatedMarketingCosts ) );

				return CachedValue( () => DifferenceInMarketingCosts, () => Input.MarketingCosts - CalculatedMarketingCosts );
			}
		}

		public decimal DifferenceInPracticeCosts
		{
			get
			{
				Property( () => DifferenceInPracticeCosts )
					.Depends( p => p.On( Input, i => i.PracticeCosts )
									.AndOn( () => CalculatedPracticeCosts ) );

				return CachedValue( () => DifferenceInPracticeCosts, () => Input.PracticeCosts - CalculatedPracticeCosts );
			}
		}

		public decimal DifferenceInParkingLotMaintenanceCosts
		{
			get
			{
				Property( () => DifferenceInParkingLotMaintenanceCosts )
					.Depends( p => p.On( Input, i => i.ParkingLotMaintenanceCosts )
									.AndOn( () => CalculatedParkingLotMaintenanceCosts ) );

				return CachedValue( () => DifferenceInParkingLotMaintenanceCosts, () => Input.ParkingLotMaintenanceCosts - CalculatedParkingLotMaintenanceCosts );
			}
		}

		public decimal TotalCosts
		{
			get
			{
				Property( () => TotalCosts )
					.Depends( p => p.OnCollectionChildProperty( Leagues, l => l.TotalCosts ) );

				return CachedValue( () => TotalCosts, () => Leagues.Sum( l => l.TotalCosts ) );
			}
		}

		public void IntitializeCallbacks()
		{
			foreach (League league in Leagues)
			{
				league.InitializeCallbacks();
			}
			Input.InitializeCallbacks();
		}
	}
}