﻿namespace ProvingGround.PDFx.Model
{
	public class DesiredStadiumTeamCostRevenueData : StadiumTeamCostRevenueData
	{
		public DesiredStadiumTeamCostRevenueData( StadiumTeamData stadiumTeamData, CurrentStadiumTeamCostRevenueData currentStadiumTeamCostRevenueData )
			: base( stadiumTeamData )
		{
			CurrentStadiumTeamCostRevenueData = currentStadiumTeamCostRevenueData;
		}

		public CurrentStadiumTeamCostRevenueData CurrentStadiumTeamCostRevenueData { get; private set; }

		public sealed override decimal WinRatio
		{
			get
			{
				Property( () => WinRatio )
					.Depends( p => p.On( CurrentStadiumTeamCostRevenueData, currentCRD => currentCRD.WinRatio )
					                .AndOn( StadiumTeamData.Stadium.Input, s => s.Include )
					                .AndOn( StadiumTeamData.Team, t => t.ChangeInWinRatio ) );

				return CachedValue( () => WinRatio,
				                    () =>
					                    {
						                    if ( StadiumTeamData.Stadium.Input.Include )
						                    {
							                    return CurrentStadiumTeamCostRevenueData.WinRatio * StadiumTeamData.Team.ChangeInWinRatio;
						                    }

						                    return 0;
					                    } );
			}
		}
	}
}