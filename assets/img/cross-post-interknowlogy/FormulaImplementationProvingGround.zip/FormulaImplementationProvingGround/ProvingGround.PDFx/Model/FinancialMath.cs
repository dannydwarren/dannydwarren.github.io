﻿using System;
using System.Linq;

namespace ProvingGround.PDFx.Model
{
	public static class FinancialMath
	{
		public static decimal FutureValue(decimal rate, int nper, decimal pmt, decimal pv)
		{
			if (pmt != 0)
			{
				throw new NotImplementedException(
					"pmt parameter on FV must be zero: annuitized FV calculations are not currently supported.");
			}
			return -1*pv*Convert.ToDecimal(Math.Pow((1 + Convert.ToDouble(rate)), nper));
		}

		public static decimal PresentValue(double rate, decimal[] values)
		{
			return values.Select((t, i) => (t/Convert.ToDecimal(Math.Pow(1 + rate, i + 1)))).Sum();
		}
	}
}