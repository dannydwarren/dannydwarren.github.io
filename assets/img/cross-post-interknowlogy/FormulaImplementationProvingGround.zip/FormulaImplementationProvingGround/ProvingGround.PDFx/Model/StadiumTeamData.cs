﻿using PropertyDependencyFramework;
using ProvingGround.Model.Input;
using ProvingGround.PDFx.Model.Input;

namespace ProvingGround.PDFx.Model
{
	public class StadiumTeamData : Bindable
	{
		public static int StadiumTeamDataCount = 0;

		public StadiumTeamData( Stadium stadium, Team team, StadiumTeamDataInput input, FormulaModel model )
		{
			StadiumTeamDataCount++;

			StadiumTeamCostRevenueYears = new DependencyFrameworkObservableCollection<StadiumTeamCostRevenueYear>();

			Stadium = stadium;
			Team = team;
			Input = input;

			CurrentStadiumTeamCostRevenueData = new CurrentStadiumTeamCostRevenueData( this );
			DesiredStadiumTeamCostRevenueData = new DesiredStadiumTeamCostRevenueData( this, CurrentStadiumTeamCostRevenueData );

			Team.StadiumTeamDatas.Add( this );

			for ( int i = 0; i < FormulaModelUserInput.YEARS_IN_MODEL; i++ )
			{
				var year = new StadiumTeamCostRevenueYear( i, FormulaModelUserInput.YEARS_IN_MODEL, this, model );
				StadiumTeamCostRevenueYears.Add( year );
			}
		}

		public Stadium Stadium { get; private set; }
		public Team Team { get; private set; }
		public StadiumTeamDataInput Input { get; private set; }
		public CurrentStadiumTeamCostRevenueData CurrentStadiumTeamCostRevenueData { get; private set; }
		public DesiredStadiumTeamCostRevenueData DesiredStadiumTeamCostRevenueData { get; private set; }
		public DependencyFrameworkObservableCollection<StadiumTeamCostRevenueYear> StadiumTeamCostRevenueYears { get; private set; }

		public decimal CurrentTicketsSold
		{
			get
			{
				Property( () => CurrentTicketsSold )
					.Depends( p => p.On( CurrentStadiumTeamCostRevenueData, currentCRD => currentCRD.TicketsSold ) );

				return CachedValue( () => CurrentTicketsSold, () => CurrentStadiumTeamCostRevenueData.TicketsSold );
			}
		}

		public decimal DesiredTicketsSold
		{
			get
			{
				Property( () => DesiredTicketsSold )
					.Depends( p => p.On( DesiredStadiumTeamCostRevenueData, desiredCRD => desiredCRD.TicketsSold ) );

				return CachedValue( () => DesiredTicketsSold, () => DesiredStadiumTeamCostRevenueData.TicketsSold );
			}
		}

		public decimal DifferenceInTicketsSold
		{
			get
			{
				Property( () => DifferenceInTicketsSold )
					.Depends( p => p.On( () => DesiredTicketsSold )
									.AndOn( () => CurrentTicketsSold ) );

				return CachedValue( () => DifferenceInTicketsSold, () => DesiredTicketsSold - CurrentTicketsSold );
			}
		}

		public decimal PracticeCost
		{
			get
			{
				Property( () => PracticeCost )
					.Depends( p => p.On( () => DifferenceInTicketsSold )
									.AndOn( Stadium.Input, s => s.PracticeCost ) );

				return CachedValue( () => PracticeCost, () => DifferenceInTicketsSold * Stadium.Input.PracticeCost );
			}
		}

		public decimal MarketingCost
		{
			get
			{
				Property( () => MarketingCost )
					.Depends( p => p.On( () => DifferenceInTicketsSold )
									.AndOn( Stadium.Input, s => s.MarketingCost ) );

				return CachedValue( () => MarketingCost, () => DifferenceInTicketsSold * Stadium.Input.MarketingCost );
			}
		}

		public decimal ParkingLotMaintenanceCost
		{
			get
			{
				Property( () => ParkingLotMaintenanceCost )
					.Depends( p => p.On( () => DifferenceInTicketsSold )
									.AndOn( Stadium.Input, s => s.ParkingLotMaintenancePerTicket ) );

				return CachedValue( () => ParkingLotMaintenanceCost, () => DifferenceInTicketsSold * Stadium.Input.ParkingLotMaintenancePerTicket );
			}
		}

		public decimal DifferenceInRevenue
		{
			get
			{
				Property( () => DifferenceInRevenue )
					.Depends( p => p.On( DesiredStadiumTeamCostRevenueData, desiredCRD => desiredCRD.RevenueTotal )
									.AndOn( CurrentStadiumTeamCostRevenueData, currentCRD => currentCRD.RevenueTotal ) );

				return CachedValue( () => DifferenceInRevenue, () => DesiredStadiumTeamCostRevenueData.RevenueTotal - CurrentStadiumTeamCostRevenueData.RevenueTotal );
			}
		}
	}
}