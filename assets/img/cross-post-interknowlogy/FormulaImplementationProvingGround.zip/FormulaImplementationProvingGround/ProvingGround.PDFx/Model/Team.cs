﻿using System.Linq;
using PropertyDependencyFramework;
using ProvingGround.Model.Input;
using ProvingGround.PDFx.Model.Input;

namespace ProvingGround.PDFx.Model
{
	public class Team : Bindable
	{
		public Team( string name, TeamUserInput input )
		{
			StadiumTeamDatas = new DependencyFrameworkObservableCollection<StadiumTeamData>();
			StadiumTeamDataInputs = new DependencyFrameworkObservableCollection<StadiumTeamDataInput>();
			CurrentStadiumTeamCostRevenueDatas = new DependencyFrameworkObservableCollection<CurrentStadiumTeamCostRevenueData>();
			DesiredStadiumTeamCostRevenueDatas = new DependencyFrameworkObservableCollection<DesiredStadiumTeamCostRevenueData>();

			Name = name;
			input.Team = this;
			Input = input;
		}

		protected DependencyFrameworkObservableCollection<CurrentStadiumTeamCostRevenueData> CurrentStadiumTeamCostRevenueDatas { get; private set; }
		protected DependencyFrameworkObservableCollection<DesiredStadiumTeamCostRevenueData> DesiredStadiumTeamCostRevenueDatas { get; private set; }

		public DependencyFrameworkObservableCollection<StadiumTeamData> StadiumTeamDatas { get; private set; }
		public DependencyFrameworkObservableCollection<StadiumTeamDataInput> StadiumTeamDataInputs { get; private set; }
		public string Name { get; private set; }
		public TeamUserInput Input { get; private set; }

		public decimal TotalCosts
		{
			get
			{
				Property( () => TotalCosts )
					.Depends( p => p.OnCollectionChildProperty( StadiumTeamDatas, std => std.MarketingCost )
									.OnCollectionChildProperty( StadiumTeamDatas, std => std.PracticeCost )
									.OnCollectionChildProperty( StadiumTeamDatas, std => std.ParkingLotMaintenanceCost ) );

				return CachedValue( () => TotalCosts, () => StadiumTeamDatas.Sum( std => std.MarketingCost + std.PracticeCost + std.ParkingLotMaintenanceCost ) );
			}
		}

		public decimal CurrentWins
		{
			get
			{
				Property( () => CurrentWins )
					.Depends( p => p.OnCollectionChildProperty( StadiumTeamDataInputs, i => i.Wins ) );

				return CachedValue( () => CurrentWins, () => StadiumTeamDataInputs.Sum( i => i.Wins ) );
			}
		}

		public decimal CurrentWinRatio
		{
			get
			{
				Property( () => CurrentWinRatio )
					.Depends( p => p.On( () => CurrentWins )
						.AndOn( () => CurrentTotalGames ) );

				return CachedValue( () => CurrentWinRatio, () => CurrentTotalGames == 0 ? 0 : CurrentWins / CurrentTotalGames );
			}
		}

		public decimal DesiredWinRatio
		{
			get
			{
				Property( () => DesiredWinRatio )
					.Depends( p => p.On( Input, i => i.DesiredWinRatio ) );

				return CachedValue( () => DesiredWinRatio, () => Input.DesiredWinRatio );
			}
		}

		public decimal ChangeInWinRatio
		{
			get
			{
				Property( () => ChangeInWinRatio )
					.Depends( p => p.On( () => DesiredWinRatio )
									.AndOn( () => CurrentWinRatio ) );

				return CachedValue( () => ChangeInWinRatio, () => CurrentWinRatio == 0 ? 0 : DesiredWinRatio / CurrentWinRatio );
			}
		}

		public decimal CurrentTotalGames
		{
			get
			{
				Property( () => CurrentTotalGames )
					.Depends( p => p.OnCollectionChildProperty( CurrentStadiumTeamCostRevenueDatas, currentCRD => currentCRD.TotalGames ) );

				return CachedValue( () => CurrentTotalGames, () => CurrentStadiumTeamCostRevenueDatas.Sum( currentCRD => currentCRD.TotalGames ) );
			}
		}

		public decimal DesiredTotalGames
		{
			get
			{
				Property( () => DesiredTotalGames )
					.Depends( p => p.OnCollectionChildProperty( DesiredStadiumTeamCostRevenueDatas, desiredCRD => desiredCRD.TotalGames ) );

				return CachedValue( () => DesiredTotalGames, () => DesiredStadiumTeamCostRevenueDatas.Sum( desiredCRD => desiredCRD.TotalGames ) );
			}
		}

		public void InitializeCallbacks()
		{
			Input.InitializeCallbacks();

			StadiumTeamDataChangedCallback();
			RegisterCallbackDependency( StadiumTeamDatas, StadiumTeamDataChangedCallback );
		}

		private void StadiumTeamDataChangedCallback()
		{
			CurrentStadiumTeamCostRevenueDatas.ReplaceAllWith( StadiumTeamDatas.Select( std => std.CurrentStadiumTeamCostRevenueData ) );
			DesiredStadiumTeamCostRevenueDatas.ReplaceAllWith( StadiumTeamDatas.Select( std => std.DesiredStadiumTeamCostRevenueData ) );
			StadiumTeamDataInputs.ReplaceAllWith( StadiumTeamDatas.Select( std => std.Input ) );
		}
	}
}