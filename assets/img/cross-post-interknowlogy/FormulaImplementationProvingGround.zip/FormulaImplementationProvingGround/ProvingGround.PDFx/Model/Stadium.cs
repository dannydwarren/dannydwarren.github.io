﻿using PropertyDependencyFramework;
using ProvingGround.Model.Input;
using ProvingGround.PDFx.Model.Input;

namespace ProvingGround.PDFx.Model
{
	public class Stadium : Bindable
	{
		public Stadium( string cityName, StadiumInput input )
		{
			CityName = cityName;
			Input = input;
		}

		public string CityName { get; private set; }
		public StadiumInput Input { get; private set; }
	}
}