﻿using PropertyDependencyFramework;
using ProvingGround.Model;

namespace ProvingGround.PDFx.Model
{
	public abstract class CostRevenueYear : Bindable
	{
		protected CostRevenueYear( int yearIndex, int totalYears )
		{
			YearIndex = yearIndex;
			TotalYears = totalYears;
		}

		public int YearIndex { get; private set; }
		public int TotalYears { get; private set; }
		public abstract Stadium Stadium { get; }

		protected bool IsStadiumUsedThisYear
		{
			get
			{
				//NOTE: MaintenanceSchedule is used in the method CalculateStadiumUsageForYear
				Property( () => IsStadiumUsedThisYear )
					.Depends( p => p.On( Stadium.Input, s => s.MaintenanceSchedule ) );
				//	.AndOn( () => YearIndex ) );
				//NOTE: No Dependency on YearIndex required because it will never change. It does not leverage NotifyPropertyChanged();

				return CachedValue( () => IsStadiumUsedThisYear, () => CalculateStadiumUsageForYear( YearIndex ) );
			}
		}

		protected int CalculatedIntForIsStadiumUsedThisYear
		{
			get
			{
				Property( () => CalculatedIntForIsStadiumUsedThisYear )
					.Depends( p => p.On( () => IsStadiumUsedThisYear ) );

				return CachedValue( () => CalculatedIntForIsStadiumUsedThisYear, () => IsStadiumUsedThisYear ? 1 : 0 );
			}
		}

		protected decimal TotalYearsStadiumIsInUse
		{
			get
			{
				Property( () => TotalYearsStadiumIsInUse )
					.Depends( p => p.On( Stadium.Input, s => s.MaintenanceSchedule ) );

				return CachedValue( () => TotalYearsStadiumIsInUse,
					() =>
					{
						decimal numberOfYearsStadiumIsInUse = 0;
						for ( int i = 0; i < TotalYears; i++ )
						{
							if ( CalculateStadiumUsageForYear( i ) )
							{
								numberOfYearsStadiumIsInUse++;
							}
						}
						return numberOfYearsStadiumIsInUse;
					} );
			}
		}

		protected bool CalculateStadiumUsageForYear( int yearIndexToCalculate )
		{
			switch ( Stadium.Input.MaintenanceSchedule )
			{
				case MaintenanceSchedule.EveryEvenYear:
					return yearIndexToCalculate % 2 == 1;
				case MaintenanceSchedule.EveryOddYear:
					return yearIndexToCalculate % 2 == 0;
				default:
					return false;
			}
		}

	}
}