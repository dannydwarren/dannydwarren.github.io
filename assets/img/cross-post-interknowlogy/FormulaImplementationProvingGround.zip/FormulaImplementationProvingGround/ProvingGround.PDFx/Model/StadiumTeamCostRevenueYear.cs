﻿using PropertyDependencyFramework;

namespace ProvingGround.PDFx.Model
{
	public class StadiumTeamCostRevenueYear : CostRevenueYear
	{
		public StadiumTeamCostRevenueYear( int yearIndex, int totalYears, StadiumTeamData stadiumTeamData, FormulaModel model )
			: base( yearIndex, totalYears )
		{
			StadiumTeamData = stadiumTeamData;

			model.NpvCostRevenueYears[yearIndex].StadiumTeamCostRevenueYears.Add(this);
		}

		public StadiumTeamData StadiumTeamData { get; private set; }

		public sealed override Stadium Stadium { get { return StadiumTeamData.Stadium; } }

		public decimal PracticeCosts
		{
			get
			{
				Property( () => PracticeCosts )
					.Depends( p => p.On( StadiumTeamData.Stadium.Input, s => s.Include )
									.AndOn( StadiumTeamData, std => std.PracticeCost )
									.AndOn( () => TotalYearsStadiumIsInUse )
									.AndOn( () => CalculatedIntForIsStadiumUsedThisYear )
									.AndOn( StadiumTeamData.Stadium.Input, s => s.RateOfIncrease ) );

				return CachedValue( () => PracticeCosts,
					() =>
					{
						if ( StadiumTeamData.Stadium.Input.Include )
						{
							return StadiumTeamData.PracticeCost / TotalYearsStadiumIsInUse * CalculatedIntForIsStadiumUsedThisYear
								* (-1 * FinancialMath.FutureValue( StadiumTeamData.Stadium.Input.RateOfIncrease, YearIndex, 0, 1 ));
						}

						return 0;
					} );
			}
		}

		public decimal MarketingCosts
		{
			get
			{
				Property( () => MarketingCosts )
					.Depends( p => p.On( StadiumTeamData.Stadium.Input, s => s.Include )
									.AndOn( StadiumTeamData, std => std.MarketingCost )
									.AndOn( () => TotalYearsStadiumIsInUse )
									.AndOn( () => CalculatedIntForIsStadiumUsedThisYear )
									.AndOn( StadiumTeamData.Stadium.Input, s => s.RateOfIncrease ) );

				return CachedValue( () => MarketingCosts,
					() =>
					{
						if ( StadiumTeamData.Stadium.Input.Include )
						{
							return StadiumTeamData.MarketingCost / TotalYearsStadiumIsInUse * CalculatedIntForIsStadiumUsedThisYear
								* (-1 * FinancialMath.FutureValue( StadiumTeamData.Stadium.Input.RateOfIncrease, YearIndex, 0, 1 ));
						}

						return 0;
					} );
			}
		}

		public decimal ParkingLogMaintenanceCosts
		{
			get
			{
				Property( () => ParkingLogMaintenanceCosts )
					.Depends( p => p.On( StadiumTeamData.Stadium.Input, s => s.Include )
									.AndOn( StadiumTeamData, std => std.ParkingLotMaintenanceCost )
									.AndOn( () => TotalYearsStadiumIsInUse )
									.AndOn( () => CalculatedIntForIsStadiumUsedThisYear )
									.AndOn( StadiumTeamData.Stadium.Input, s => s.RateOfIncrease ) );

				return CachedValue( () => ParkingLogMaintenanceCosts,
					() =>
					{
						if ( StadiumTeamData.Stadium.Input.Include )
						{
							return StadiumTeamData.ParkingLotMaintenanceCost / TotalYearsStadiumIsInUse * CalculatedIntForIsStadiumUsedThisYear
								* (-1 * FinancialMath.FutureValue( StadiumTeamData.Stadium.Input.RateOfIncrease, YearIndex, 0, 1 ));
						}

						return 0;
					} );
			}
		}

		public decimal DifferenceInRevenue
		{
			get
			{
				Property( () => DifferenceInRevenue )
					.Depends( p => p.On( StadiumTeamData.Stadium.Input, s => s.Include )
									.AndOn( StadiumTeamData, std => std.DifferenceInRevenue )
									.AndOn( () => TotalYearsStadiumIsInUse )
									.AndOn( () => CalculatedIntForIsStadiumUsedThisYear )
									.AndOn( StadiumTeamData.Stadium.Input, s => s.RateOfIncrease ) );

				return CachedValue( () => DifferenceInRevenue,
					() =>
					{
						if ( StadiumTeamData.Stadium.Input.Include )
						{
							return StadiumTeamData.DifferenceInRevenue / TotalYearsStadiumIsInUse * CalculatedIntForIsStadiumUsedThisYear
								* (-1 * FinancialMath.FutureValue( StadiumTeamData.Stadium.Input.RateOfIncrease, YearIndex, 0, 1 ));
						}

						return 0;
					} );
			}
		}
	}
}