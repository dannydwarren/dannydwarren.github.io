﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PropertyDependencyFramework;
using ProvingGround.Model.NoMath;
using ProvingGround.PDFx.DataProviders;

namespace ProvingGround.PDFx
{
	public class InRuleVM : Bindable
	{
		public InRuleVM()
		{
			var dp = new MatchesModelNoMathDataProvider();
			Model = dp.CreateModel();

		}

		private FormulaModel _model;
		public FormulaModel Model
		{
			[DebuggerStepThrough]
			get { return _model; }
			set
			{
				if ( value == _model )
					return;

				_model = value;
				NotifyPropertyChanged( () => Model );
			}
		}

	}
}
