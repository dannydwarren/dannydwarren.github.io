﻿using Microsoft.Practices.Prism.PubSubEvents;

namespace ProvingGround
{
	public class EventAggregatorProvider
	{
		#region Singleton
		private static EventAggregatorProvider _instance;
		public static EventAggregatorProvider Instance
		{
			get
			{
				if ( _instance == null )
					_instance = new EventAggregatorProvider();
				return _instance;
			}
		}
		private EventAggregatorProvider()
		{
			EventAggregator = new EventAggregator();
		}
		#endregion

		public IEventAggregator EventAggregator { get; private set; }
	}
}