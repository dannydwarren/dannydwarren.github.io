﻿namespace ProvingGround.Model
{
	public enum MaintenanceSchedule
	{
		EveryEvenYear,
		EveryOddYear,
	}
}