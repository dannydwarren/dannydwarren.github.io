﻿using System.Collections.ObjectModel;
using System.Linq;
using PropertyDependencyFramework;

namespace ProvingGround.Model.NoMath
{
	public class League : Bindable
	{
		public League(DependencyFrameworkObservableCollection<Division> divisions )
		{
			Divisions = divisions;
		}

		public ObservableCollection<Division> Divisions { get; private set; }

		public decimal TotalCosts
		{
			get
			{
				Property( () => TotalCosts )
					.Depends( p => p.OnCollectionChildProperty( Divisions, d => d.TotalCosts ) );

				return CachedValue( () => TotalCosts, () => Divisions.Sum( d => d.TotalCosts ) );
			}
		}
	}
}
