﻿using System.Collections.ObjectModel;
using System.Linq;
using PropertyDependencyFramework;

namespace ProvingGround.Model.NoMath
{
	public class Division : Bindable
	{
		public Division( DependencyFrameworkObservableCollection<Team> teams )
		{
			Teams = teams;
		}

		public ObservableCollection<Team> Teams { get; private set; }

		public decimal TotalCosts
		{
			get
			{
				Property( () => TotalCosts )
					.Depends( p => p.OnCollectionChildProperty( Teams, t => t.TotalCosts ) );

				return CachedValue( () => TotalCosts, () => Teams.Sum( t => t.TotalCosts ) );
			}
		}
	}
}
