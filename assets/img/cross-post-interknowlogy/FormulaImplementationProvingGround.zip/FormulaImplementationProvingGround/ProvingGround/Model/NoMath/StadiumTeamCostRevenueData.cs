﻿using PropertyDependencyFramework;

namespace ProvingGround.Model.NoMath
{
	public abstract class StadiumTeamCostRevenueData : Bindable
	{
		private decimal _totalGames;
		private decimal _revenueTotal;
		private decimal _poorSalesCost;
		private decimal _lockerRoomCost;
		private decimal _revenueSubtotal;
		private decimal _consessionRevenue;
		private decimal _consessionsSold;
		private decimal _revenueFromTickets;
		private decimal _ticketsSold;
		private decimal _winRatio;

		protected StadiumTeamCostRevenueData( StadiumTeamData stadiumTeamData )
		{
			StadiumTeamData = stadiumTeamData;
		}

		public StadiumTeamData StadiumTeamData { get; private set; }
		
		public decimal TotalGames
		{
			get { return _totalGames; }
			set
			{
				if (value == _totalGames) return;
				_totalGames = value;
				NotifyPropertyChanged(() => TotalGames);
			}
		}

		public virtual decimal WinRatio
		{
			get { return _winRatio; }
			set
			{
				if (value == _winRatio) return;
				_winRatio = value;
				NotifyPropertyChanged(() => WinRatio);
			}
		}

		public decimal TicketsSold
		{
			get { return _ticketsSold; }
			set
			{
				if (value == _ticketsSold) return;
				_ticketsSold = value;
				NotifyPropertyChanged(() => TicketsSold);
			}
		}

		public decimal RevenueFromTickets
		{
			get { return _revenueFromTickets; }
			set
			{
				if (value == _revenueFromTickets) return;
				_revenueFromTickets = value;
				NotifyPropertyChanged(() => RevenueFromTickets);
			}
		}

		public decimal ConsessionsSold
		{
			get { return _consessionsSold; }
			set
			{
				if (value == _consessionsSold) return;
				_consessionsSold = value;
				NotifyPropertyChanged(() => ConsessionsSold);
			}
		}

		public decimal ConsessionRevenue
		{
			get { return _consessionRevenue; }
			set
			{
				if (value == _consessionRevenue) return;
				_consessionRevenue = value;
				NotifyPropertyChanged(() => ConsessionRevenue);
			}
		}

		public decimal RevenueSubtotal
		{
			get { return _revenueSubtotal; }
			set
			{
				if (value == _revenueSubtotal) return;
				_revenueSubtotal = value;
				NotifyPropertyChanged(() => RevenueSubtotal);
			}
		}

		public decimal LockerRoomCost
		{
			get { return _lockerRoomCost; }
			set
			{
				if (value == _lockerRoomCost) return;
				_lockerRoomCost = value;
				NotifyPropertyChanged(() => LockerRoomCost);
			}
		}

		public decimal PoorSalesCost
		{
			get { return _poorSalesCost; }
			set
			{
				if (value == _poorSalesCost) return;
				_poorSalesCost = value;
				NotifyPropertyChanged(() => PoorSalesCost);
			}
		}

		public decimal RevenueTotal
		{
			get { return _revenueTotal; }
			set
			{
				if (value == _revenueTotal) return;
				_revenueTotal = value;
				NotifyPropertyChanged(() => RevenueTotal);
			}
		}
	}
}
