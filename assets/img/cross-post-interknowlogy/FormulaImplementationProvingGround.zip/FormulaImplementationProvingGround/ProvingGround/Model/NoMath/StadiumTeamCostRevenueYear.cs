﻿namespace ProvingGround.Model.NoMath
{
	public class StadiumTeamCostRevenueYear : CostRevenueYear
	{
		private decimal _differenceInRevenue;
		private decimal _parkingLogMaintenanceCosts;
		private decimal _marketingCosts;
		private decimal _practiceCosts;

		public StadiumTeamCostRevenueYear( int yearIndex, int totalYears, StadiumTeamData stadiumTeamData, FormulaModel model )
			: base( yearIndex, totalYears )
		{
			StadiumTeamData = stadiumTeamData;

			model.NpvCostRevenueYears[yearIndex].StadiumTeamCostRevenueYears.Add(this);
		}

		public StadiumTeamData StadiumTeamData { get; private set; }
		
		public decimal PracticeCosts
		{
			get { return _practiceCosts; }
			set
			{
				if (value == _practiceCosts) return;
				_practiceCosts = value;
				NotifyPropertyChanged(() => PracticeCosts);
			}
		}

		public decimal MarketingCosts
		{
			get { return _marketingCosts; }
			set
			{
				if (value == _marketingCosts) return;
				_marketingCosts = value;
				NotifyPropertyChanged(() => MarketingCosts);
			}
		}

		public decimal ParkingLogMaintenanceCosts
		{
			get { return _parkingLogMaintenanceCosts; }
			set
			{
				if (value == _parkingLogMaintenanceCosts) return;
				_parkingLogMaintenanceCosts = value;
				NotifyPropertyChanged(() => ParkingLogMaintenanceCosts);
			}
		}

		public decimal DifferenceInRevenue
		{
			get { return _differenceInRevenue; }
			set
			{
				if (value == _differenceInRevenue) return;
				_differenceInRevenue = value;
				NotifyPropertyChanged(() => DifferenceInRevenue);
			}
		}
	}
}
