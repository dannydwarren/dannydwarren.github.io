﻿using System.Collections.ObjectModel;
using PropertyDependencyFramework;
using ProvingGround.Model.Input;

namespace ProvingGround.Model.NoMath
{
	public class NpvCostRevenueYear : CostRevenueYear
	{
		private readonly Stadium _theoreticalStadium;
		private decimal _npv;
		private decimal _totalWorth;
		private decimal _totalRevenue;
		private decimal _donations;
		private decimal _differenceInRevenue;
		private decimal _totalScheduledDifferenceInCosts;
		private decimal _scheduledDifferenceInParkingLotMaintenanceCosts;
		private decimal _scheduledDifferenceInPracticeCosts;
		private decimal _scheduledDifferenceInMarketingCosts;
		private decimal _totalCosts;
		private decimal _parkingLotMaintenanceCost;
		private decimal _practiceCost;
		private decimal _totalMarketingCost;
		private decimal _additionalMarketingCost;
		private decimal _marketingCost;

		public NpvCostRevenueYear( int yearIndex, int totalYears, Stadium theoreticalStadium, FormulaModel model )
			: base( yearIndex, totalYears )
		{
			Model = model;
			StadiumTeamCostRevenueYears = new DependencyFrameworkObservableCollection<StadiumTeamCostRevenueYear>();
			TeamInputs = new DependencyFrameworkObservableCollection<TeamInput>();

			_theoreticalStadium = theoreticalStadium;
		}

		public FormulaModel Model { get; private set; }
		public ObservableCollection<TeamInput> TeamInputs { get; private set; }
		public ObservableCollection<StadiumTeamCostRevenueYear> StadiumTeamCostRevenueYears { get; private set; }
		
		public decimal MarketingCost
		{
			get { return _marketingCost; }
			set
			{
				if (value == _marketingCost) return;
				_marketingCost = value;
				NotifyPropertyChanged(() => MarketingCost);
			}
		}

		public decimal AdditionalMarketingCost
		{
			get { return _additionalMarketingCost; }
			set
			{
				if (value == _additionalMarketingCost) return;
				_additionalMarketingCost = value;
				NotifyPropertyChanged(() => AdditionalMarketingCost);
			}
		}

		public decimal TotalMarketingCost
		{
			get { return _totalMarketingCost; }
			set
			{
				if (value == _totalMarketingCost) return;
				_totalMarketingCost = value;
				NotifyPropertyChanged(() => TotalMarketingCost);
			}
		}

		public decimal PracticeCost
		{
			get { return _practiceCost; }
			set
			{
				if (value == _practiceCost) return;
				_practiceCost = value;
				NotifyPropertyChanged(() => PracticeCost);
			}
		}

		public decimal ParkingLotMaintenanceCost
		{
			get { return _parkingLotMaintenanceCost; }
			set
			{
				if (value == _parkingLotMaintenanceCost) return;
				_parkingLotMaintenanceCost = value;
				NotifyPropertyChanged(() => ParkingLotMaintenanceCost);
			}
		}

		public decimal TotalCosts
		{
			get { return _totalCosts; }
			set
			{
				if (value == _totalCosts) return;
				_totalCosts = value;
				NotifyPropertyChanged(() => TotalCosts);
			}
		}

		public decimal ScheduledDifferenceInMarketingCosts
		{
			get { return _scheduledDifferenceInMarketingCosts; }
			set
			{
				if (value == _scheduledDifferenceInMarketingCosts) return;
				_scheduledDifferenceInMarketingCosts = value;
				NotifyPropertyChanged(() => ScheduledDifferenceInMarketingCosts);
			}
		}

		public decimal ScheduledDifferenceInPracticeCosts
		{
			get { return _scheduledDifferenceInPracticeCosts; }
			set
			{
				if (value == _scheduledDifferenceInPracticeCosts) return;
				_scheduledDifferenceInPracticeCosts = value;
				NotifyPropertyChanged(() => ScheduledDifferenceInPracticeCosts);
			}
		}

		public decimal ScheduledDifferenceInParkingLotMaintenanceCosts
		{
			get { return _scheduledDifferenceInParkingLotMaintenanceCosts; }
			set
			{
				if (value == _scheduledDifferenceInParkingLotMaintenanceCosts) return;
				_scheduledDifferenceInParkingLotMaintenanceCosts = value;
				NotifyPropertyChanged(() => ScheduledDifferenceInParkingLotMaintenanceCosts);
			}
		}

		public decimal TotalScheduledDifferenceInCosts
		{
			get { return _totalScheduledDifferenceInCosts; }
			set
			{
				if (value == _totalScheduledDifferenceInCosts) return;
				_totalScheduledDifferenceInCosts = value;
				NotifyPropertyChanged(() => TotalScheduledDifferenceInCosts);
			}
		}

		public decimal DifferenceInRevenue
		{
			get { return _differenceInRevenue; }
			set
			{
				if (value == _differenceInRevenue) return;
				_differenceInRevenue = value;
				NotifyPropertyChanged(() => DifferenceInRevenue);
			}
		}

		public decimal Donations
		{
			get { return _donations; }
			set
			{
				if (value == _donations) return;
				_donations = value;
				NotifyPropertyChanged(() => Donations);
			}
		}

		public decimal TotalRevenue
		{
			get { return _totalRevenue; }
			set
			{
				if (value == _totalRevenue) return;
				_totalRevenue = value;
				NotifyPropertyChanged(() => TotalRevenue);
			}
		}

		public decimal TotalWorth
		{
			get { return _totalWorth; }
			set
			{
				if (value == _totalWorth) return;
				_totalWorth = value;
				NotifyPropertyChanged(() => TotalWorth);
			}
		}

		public decimal Npv
		{
			get { return _npv; }
			set
			{
				if (value == _npv) return;
				_npv = value;
				NotifyPropertyChanged(() => Npv);
			}
		}
	}
}
