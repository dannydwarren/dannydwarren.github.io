﻿namespace ProvingGround.Model.NoMath
{
	public class CurrentStadiumTeamCostRevenueData : StadiumTeamCostRevenueData
	{
		public CurrentStadiumTeamCostRevenueData( StadiumTeamData stadiumTeamData )
			: base( stadiumTeamData )
		{
		}
	}
}
