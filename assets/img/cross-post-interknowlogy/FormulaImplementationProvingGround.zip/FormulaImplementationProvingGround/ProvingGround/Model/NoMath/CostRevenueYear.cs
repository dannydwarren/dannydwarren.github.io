﻿using PropertyDependencyFramework;

namespace ProvingGround.Model.NoMath
{
	public class CostRevenueYear : Bindable
	{
		protected CostRevenueYear( int yearIndex, int totalYears )
		{
			YearIndex = yearIndex;
			TotalYears = totalYears;
		}

		public int YearIndex { get; private set; }
		public int TotalYears { get; private set; }
		public Stadium Stadium { get; private set; }
	}
}
