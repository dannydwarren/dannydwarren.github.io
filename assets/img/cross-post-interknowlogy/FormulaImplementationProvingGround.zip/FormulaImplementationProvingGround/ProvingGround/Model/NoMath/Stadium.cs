using PropertyDependencyFramework;
using ProvingGround.Model.Input;

namespace ProvingGround.Model.NoMath
{
	public class Stadium : Bindable
	{
		//HACK: For sake of this demo Ids are generated statically
		private static long _nextId = 1;
		
		public Stadium( string cityName, StadiumInput input )
		{
			Id = _nextId++;
			CityName = cityName;
			Input = input;
		}

		public long Id { get; private set; }
		public string CityName { get; private set; }
		public StadiumInput Input { get; private set; }
	}
}