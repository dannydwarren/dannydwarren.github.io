﻿using System.Collections.ObjectModel;
using PropertyDependencyFramework;
using ProvingGround.Model.Input;

namespace ProvingGround.Model.NoMath
{
	public class StadiumTeamData : Bindable
	{
		public static int StadiumTeamDataCount = 0;
		private decimal _differenceInRevenue;
		private decimal _parkingLotMaintenanceCost;
		private decimal _marketingCost;
		private decimal _practiceCost;
		private decimal _differenceInTicketsSold;
		private decimal _desiredTicketsSold;
		private decimal _currentTicketsSold;

		public StadiumTeamData( Stadium stadium, Team team, StadiumTeamDataInput input, FormulaModel model )
		{
			StadiumTeamDataCount++;

			StadiumTeamCostRevenueYears = new DependencyFrameworkObservableCollection<StadiumTeamCostRevenueYear>();

			Stadium = stadium;
			Team = team;
			Input = input;

			CurrentStadiumTeamCostRevenueData = new CurrentStadiumTeamCostRevenueData( this );
			DesiredStadiumTeamCostRevenueData = new DesiredStadiumTeamCostRevenueData( this, CurrentStadiumTeamCostRevenueData );

			Team.StadiumTeamDatas.Add( this );

			for ( int i = 0; i < FormulaModelInput.YEARS_IN_MODEL; i++ )
			{
				var year = new StadiumTeamCostRevenueYear( i, FormulaModelInput.YEARS_IN_MODEL, this, model );
				StadiumTeamCostRevenueYears.Add( year );
			}
		}

		public Stadium Stadium { get;  set; }
		public Team Team { get;  set; }
		public StadiumTeamDataInput Input { get; private set; }
		public CurrentStadiumTeamCostRevenueData CurrentStadiumTeamCostRevenueData { get;  set; }
		public DesiredStadiumTeamCostRevenueData DesiredStadiumTeamCostRevenueData { get;  set; }
		public ObservableCollection<StadiumTeamCostRevenueYear> StadiumTeamCostRevenueYears { get;  set; }
		
		public decimal CurrentTicketsSold
		{
			get { return _currentTicketsSold; }
			set
			{
				if (value == _currentTicketsSold) return;
				_currentTicketsSold = value;
				NotifyPropertyChanged(() => CurrentTicketsSold);
			}
		}

		public decimal DesiredTicketsSold
		{
			get { return _desiredTicketsSold; }
			set
			{
				if (value == _desiredTicketsSold) return;
				_desiredTicketsSold = value;
				NotifyPropertyChanged(() => DesiredTicketsSold);
			}
		}

		public decimal DifferenceInTicketsSold
		{
			get { return _differenceInTicketsSold; }
			set
			{
				if (value == _differenceInTicketsSold) return;
				_differenceInTicketsSold = value;
				NotifyPropertyChanged(() => DifferenceInTicketsSold);
			}
		}

		public decimal PracticeCost
		{
			get { return _practiceCost; }
			set
			{
				if (value == _practiceCost) return;
				_practiceCost = value;
				NotifyPropertyChanged(() => PracticeCost);
			}
		}

		public decimal MarketingCost
		{
			get { return _marketingCost; }
			set
			{
				if (value == _marketingCost) return;
				_marketingCost = value;
				NotifyPropertyChanged(() => MarketingCost);
			}
		}

		public decimal ParkingLotMaintenanceCost
		{
			get { return _parkingLotMaintenanceCost; }
			set
			{
				if (value == _parkingLotMaintenanceCost) return;
				_parkingLotMaintenanceCost = value;
				NotifyPropertyChanged(() => ParkingLotMaintenanceCost);
			}
		}

		public decimal DifferenceInRevenue
		{
			get { return _differenceInRevenue; }
			set
			{
				if (value == _differenceInRevenue) return;
				_differenceInRevenue = value;
				NotifyPropertyChanged(() => DifferenceInRevenue);
			}
		}
	}
}
