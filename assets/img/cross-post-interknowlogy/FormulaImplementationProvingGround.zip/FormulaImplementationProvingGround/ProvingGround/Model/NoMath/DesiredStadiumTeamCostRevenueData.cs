﻿namespace ProvingGround.Model.NoMath
{
	public class DesiredStadiumTeamCostRevenueData : StadiumTeamCostRevenueData
	{
		public DesiredStadiumTeamCostRevenueData( StadiumTeamData stadiumTeamData, CurrentStadiumTeamCostRevenueData currentStadiumTeamCostRevenueData )
			: base( stadiumTeamData )
		{
			CurrentStadiumTeamCostRevenueData = currentStadiumTeamCostRevenueData;
		}

		public CurrentStadiumTeamCostRevenueData CurrentStadiumTeamCostRevenueData { get; private set; }
	}
}
