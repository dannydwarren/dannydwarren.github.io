﻿using System.Collections.ObjectModel;
using System.Linq;
using PropertyDependencyFramework;
using ProvingGround.Model.Input;

namespace ProvingGround.Model.NoMath
{
	public class Team : Bindable
	{
		private decimal _desiredTotalGames;
		private decimal _currentTotalGames;
		private decimal _changeInWinRatio;
		private decimal _desiredWinRatio;
		private decimal _currentWinRatio;
		private decimal _currentWins;

		public Team( string name, TeamInput input )
		{
			Id = _nextId++;

			StadiumTeamDatas = new DependencyFrameworkObservableCollection<StadiumTeamData>();

			Name = name;
			Input = input;
		}

		//HACK: For sake of this demo Ids are generated statically
		private static long _nextId = 1;
		public static long NextId
		{
			get { return _nextId; }
		}

		public long Id { get; private set; }
		public ObservableCollection<StadiumTeamData> StadiumTeamDatas { get; private set; }
		public string Name { get; private set; }
		public TeamInput Input { get; set; }

		public decimal TotalCosts
		{
			get
			{
				Property( () => TotalCosts )
					.Depends( p => p.OnCollectionChildProperty( StadiumTeamDatas, std => std.MarketingCost )
									.OnCollectionChildProperty( StadiumTeamDatas, std => std.PracticeCost )
									.OnCollectionChildProperty( StadiumTeamDatas, std => std.ParkingLotMaintenanceCost ) );

				return CachedValue( () => TotalCosts, () => StadiumTeamDatas.Sum( std => std.MarketingCost + std.PracticeCost + std.ParkingLotMaintenanceCost ) );
			}
		}

		public decimal CurrentWins
		{
			get { return _currentWins; }
			set
			{
				if ( value == _currentWins ) return;
				_currentWins = value;
				NotifyPropertyChanged( () => CurrentWins );
			}
		}

		public decimal CurrentWinRatio
		{
			get { return _currentWinRatio; }
			set
			{
				if ( value == _currentWinRatio ) return;
				_currentWinRatio = value;
				NotifyPropertyChanged( () => CurrentWinRatio );
			}
		}

		public decimal DesiredWinRatio
		{
			get { return _desiredWinRatio; }
			set
			{
				if ( value == _desiredWinRatio ) return;
				_desiredWinRatio = value;
				NotifyPropertyChanged( () => DesiredWinRatio );
			}
		}

		public decimal ChangeInWinRatio
		{
			get { return _changeInWinRatio; }
			set
			{
				if ( value == _changeInWinRatio ) return;
				_changeInWinRatio = value;
				NotifyPropertyChanged( () => ChangeInWinRatio );
			}
		}

		public decimal CurrentTotalGames
		{
			get { return _currentTotalGames; }
			set
			{
				if ( value == _currentTotalGames ) return;
				_currentTotalGames = value;
				NotifyPropertyChanged( () => CurrentTotalGames );
			}
		}

		public decimal DesiredTotalGames
		{
			get { return _desiredTotalGames; }
			set
			{
				if ( value == _desiredTotalGames ) return;
				_desiredTotalGames = value;
				NotifyPropertyChanged( () => DesiredTotalGames );
			}
		}
	}
}
