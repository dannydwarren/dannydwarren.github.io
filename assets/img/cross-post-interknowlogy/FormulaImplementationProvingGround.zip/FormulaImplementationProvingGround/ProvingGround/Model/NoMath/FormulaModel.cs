﻿using System.Collections.ObjectModel;
using System.Linq;
using PropertyDependencyFramework;
using ProvingGround.Model.Input;

namespace ProvingGround.Model.NoMath
{
	public class FormulaModel : Bindable
	{
		private decimal _calculatedMarketingCosts;
		private decimal _calculatedPracticeCosts;
		private decimal _calculatedParkingLotMaintenanceCosts;
		private decimal _desiredTotalGames;
		private decimal _currentTotalGames;
		private decimal _differenceInParkingLotMaintenanceCosts;
		private decimal _differenceInPracticeCosts;
		private decimal _differenceInMarketingCosts;

		public FormulaModel( Stadium theoreticalStadium, FormulaModelInput input )
		{
			NpvCostRevenueYears = new DependencyFrameworkObservableCollection<NpvCostRevenueYear>();
			Leagues = new DependencyFrameworkObservableCollection<League>();

			TheoreticalStadium = theoreticalStadium;

			for ( int i = 0; i < FormulaModelInput.YEARS_IN_MODEL; i++ )
			{
				var year = new NpvCostRevenueYear( i, FormulaModelInput.YEARS_IN_MODEL, TheoreticalStadium, this );
				NpvCostRevenueYears.Add( year );
			}

			//input.FormulaModel = this;
			Input = input;
		}

		public FormulaModelInput Input { get; private set; }
		public ObservableCollection<League> Leagues { get; private set; }
		public Stadium TheoreticalStadium { get; private set; }
		public ObservableCollection<NpvCostRevenueYear> NpvCostRevenueYears { get; private set; }
		
		public decimal CalculatedMarketingCosts
		{
			get { return _calculatedMarketingCosts; }
			set
			{
				if (value == _calculatedMarketingCosts) return;
				_calculatedMarketingCosts = value;
				NotifyPropertyChanged(() => CalculatedMarketingCosts);
			}
		}

		public decimal CalculatedPracticeCosts
		{
			get { return _calculatedPracticeCosts; }
			set
			{
				if (value == _calculatedPracticeCosts) return;
				_calculatedPracticeCosts = value;
				NotifyPropertyChanged(() => CalculatedPracticeCosts);
			}
		}

		public decimal CalculatedParkingLotMaintenanceCosts
		{
			get { return _calculatedParkingLotMaintenanceCosts; }
			set
			{
				if (value == _calculatedParkingLotMaintenanceCosts) return;
				_calculatedParkingLotMaintenanceCosts = value;
				NotifyPropertyChanged(() => CalculatedParkingLotMaintenanceCosts);
			}
		}

		public decimal DifferenceInMarketingCosts
		{
			get { return _differenceInMarketingCosts; }
			set
			{
				if (value == _differenceInMarketingCosts) return;
				_differenceInMarketingCosts = value;
				NotifyPropertyChanged(() => DifferenceInMarketingCosts);
			}
		}

		public decimal DifferenceInPracticeCosts
		{
			get { return _differenceInPracticeCosts; }
			set
			{
				if (value == _differenceInPracticeCosts) return;
				_differenceInPracticeCosts = value;
				NotifyPropertyChanged(() => DifferenceInPracticeCosts);
			}
		}

		public decimal DifferenceInParkingLotMaintenanceCosts
		{
			get { return _differenceInParkingLotMaintenanceCosts; }
			set
			{
				if (value == _differenceInParkingLotMaintenanceCosts) return;
				_differenceInParkingLotMaintenanceCosts = value;
				NotifyPropertyChanged(() => DifferenceInParkingLotMaintenanceCosts);
			}
		}

		public decimal CurrentTotalGames
		{
			get { return _currentTotalGames; }
			set
			{
				if (value == _currentTotalGames) return;
				_currentTotalGames = value;
				NotifyPropertyChanged(() => CurrentTotalGames);
			}
		}

		public decimal DesiredTotalGames
		{
			get { return _desiredTotalGames; }
			set
			{
				if (value == _desiredTotalGames) return;
				_desiredTotalGames = value;
				NotifyPropertyChanged(() => DesiredTotalGames);
			}
		}

		public decimal TotalCosts
		{
			get
			{
				Property( () => TotalCosts )
					.Depends( p => p.OnCollectionChildProperty( Leagues, l => l.TotalCosts ) );

				return CachedValue( () => TotalCosts, () => Leagues.Sum( l => l.TotalCosts ) );
			}
		}
	}
}
