﻿using System;
using System.Diagnostics;
using Microsoft.Practices.Prism.PubSubEvents;
using PropertyDependencyFramework;

namespace ProvingGround.Model.Input
{
	public class FormulaModelInput : Bindable
	{
		public static readonly int YEARS_IN_MODEL = 10;

		protected bool _marketingCostsSettingInternally;
		protected bool _practiceCostsSettingInternally;
		protected bool _parkingLotMaintenanceCostsSettingInternally;

		private bool _marketingCostsSetExternally;
		public bool MarketingCostsSetExternally
		{
			[DebuggerStepThrough]
			get { return _marketingCostsSetExternally; }
			set
			{
				if ( value == _marketingCostsSetExternally )
					return;

				_marketingCostsSetExternally = value;
				NotifyPropertyChanged( () => MarketingCostsSetExternally );
			}
		}

		private decimal _marketingCostsMin;
		public decimal MarketingCostsMin
		{
			[DebuggerStepThrough]
			get { return _marketingCostsMin; }
			set
			{
				if ( value == _marketingCostsMin )
					return;

				_marketingCostsMin = value;
				NotifyPropertyChanged( () => MarketingCostsMin );
			}
		}

		private decimal _marketingCosts;
		public decimal MarketingCosts
		{
			[DebuggerStepThrough]
			get { return _marketingCosts; }
			set
			{
				if ( value == _marketingCosts )
					return;

				if ( !_marketingCostsSettingInternally )
				{
					MarketingCostsSetExternally = true;
				}

				if ( MarketingCostsSetExternally && _marketingCostsSettingInternally )
				{
					return;
				}

				_marketingCosts = value;

				if ( _marketingCostsSettingInternally )
				{
					MarketingCostsMin = MarketingCosts - 1000;
					MarketingCostsMax = MarketingCosts + 1000;
				}
				else
				{
									EventAggregatorProvider.Instance.EventAggregator.GetEvent<PubSubEvent<object>>().Publish( null );

					//ChangeCount++;
				}

				NotifyPropertyChanged( () => MarketingCosts );
			}
		}

		private decimal _marketingCostsMax;
		public decimal MarketingCostsMax
		{
			[DebuggerStepThrough]
			get { return _marketingCostsMax; }
			set
			{
				if ( value == _marketingCostsMax )
					return;

				_marketingCostsMax = value;
				NotifyPropertyChanged( () => MarketingCostsMax );
			}
		}

		private bool _practiceCostsSetExternally;
		public bool PracticeCostsSetExternally
		{
			[DebuggerStepThrough]
			get { return _practiceCostsSetExternally; }
			set
			{
				if ( value == _practiceCostsSetExternally )
					return;

				_practiceCostsSetExternally = value;
				NotifyPropertyChanged( () => PracticeCostsSetExternally );
			}
		}

		private decimal _practiceCostsMin;
		public decimal PracticeCostsMin
		{
			[DebuggerStepThrough]
			get { return _practiceCostsMin; }
			set
			{
				if ( value == _practiceCostsMin )
					return;

				_practiceCostsMin = value;
				NotifyPropertyChanged( () => PracticeCostsMin );
			}
		}

		private decimal _practiceCosts;
		public decimal PracticeCosts
		{
			[DebuggerStepThrough]
			get { return _practiceCosts; }
			set
			{
				if ( value == _practiceCosts )
					return;

				if ( !_practiceCostsSettingInternally )
				{
					PracticeCostsSetExternally = true;
				}

				if ( PracticeCostsSetExternally && _practiceCostsSettingInternally )
				{
					return;
				}

				_practiceCosts = value;
				if ( _practiceCostsSettingInternally )
				{
					PracticeCostsMin = PracticeCosts - 1000;
					PracticeCostsMax = PracticeCosts + 1000;
				}
				else
				{
									EventAggregatorProvider.Instance.EventAggregator.GetEvent<PubSubEvent<object>>().Publish( null );

					//ChangeCount++;
				}

				NotifyPropertyChanged( () => PracticeCosts );
			}
		}

		private decimal _practiceCostsMax;
		public decimal PracticeCostsMax
		{
			[DebuggerStepThrough]
			get { return _practiceCostsMax; }
			set
			{
				if ( value == _practiceCostsMax )
					return;

				_practiceCostsMax = value;
				NotifyPropertyChanged( () => PracticeCostsMax );
			}
		}

		private bool _parkingLotMaintenanceCostsSetExternally;
		public bool ParkingLotMaintenanceCostsSetExternally
		{
			[DebuggerStepThrough]
			get { return _parkingLotMaintenanceCostsSetExternally; }
			set
			{
				if ( value == _parkingLotMaintenanceCostsSetExternally )
					return;

				_parkingLotMaintenanceCostsSetExternally = value;
				NotifyPropertyChanged( () => ParkingLotMaintenanceCostsSetExternally );
			}
		}

		private decimal _parkingLotMaintenanceCostsMin;
		public decimal ParkingLotMaintenanceCostsMin
		{
			[DebuggerStepThrough]
			get { return _parkingLotMaintenanceCostsMin; }
			set
			{
				if ( value == _parkingLotMaintenanceCostsMin )
					return;

				_parkingLotMaintenanceCostsMin = value;
				NotifyPropertyChanged( () => ParkingLotMaintenanceCostsMin );
			}
		}

		private decimal _parkingLotMaintenanceCosts;
		public decimal ParkingLotMaintenanceCosts
		{
			[DebuggerStepThrough]
			get { return _parkingLotMaintenanceCosts; }
			set
			{
				if ( value == _parkingLotMaintenanceCosts )
					return;

				if ( !_parkingLotMaintenanceCostsSettingInternally )
				{
					ParkingLotMaintenanceCostsSetExternally = true;
				}

				if ( ParkingLotMaintenanceCostsSetExternally && _parkingLotMaintenanceCostsSettingInternally )
				{
					return;
				}

				_parkingLotMaintenanceCosts = value;
				if ( _parkingLotMaintenanceCostsSettingInternally )
				{
					ParkingLotMaintenanceCostsMin = ParkingLotMaintenanceCosts - 1000;
					ParkingLotMaintenanceCostsMax = ParkingLotMaintenanceCosts + 1000;
				}
				else
				{
									EventAggregatorProvider.Instance.EventAggregator.GetEvent<PubSubEvent<object>>().Publish( null );

					//ChangeCount++;
				}

				NotifyPropertyChanged( () => ParkingLotMaintenanceCosts );
			}
		}

		private decimal _parkingLotMaintenanceCostsMax;
		public decimal ParkingLotMaintenanceCostsMax
		{
			[DebuggerStepThrough]
			get { return _parkingLotMaintenanceCostsMax; }
			set
			{
				if ( value == _parkingLotMaintenanceCostsMax )
					return;

				_parkingLotMaintenanceCostsMax = value;
				NotifyPropertyChanged( () => ParkingLotMaintenanceCostsMax );
			}
		}

		private double _npvRate;
		public double NpvRate
		{
			[DebuggerStepThrough]
			get { return _npvRate; }
			set
			{
				if ( Math.Abs(value - _npvRate) < double.Epsilon )
					return;

				_npvRate = value;

				EventAggregatorProvider.Instance.EventAggregator.GetEvent<PubSubEvent<object>>().Publish( null );
				//ChangeCount++;

				NotifyPropertyChanged( () => NpvRate );
			}
		}

		//NOTE: This property is built for leveraging PDFx
		//private int _changeCount;
		//public int ChangeCount
		//{
		//	[DebuggerStepThrough]
		//	get { return _changeCount; }
		//	set
		//	{
		//		if ( value == _changeCount )
		//			return;

		//		_changeCount = value;
		//		NotifyPropertyChanged( () => ChangeCount );
		//	}
		//}

		public void SilentlySetMarketingCosts( decimal calculatedMarketingCosts )
		{
			_marketingCostsSettingInternally = true;
			MarketingCosts = calculatedMarketingCosts;
			_marketingCostsSettingInternally = false;

		}

		public void SilentlySetPracticeCosts( decimal calculatedPracticeCosts )
		{
			_practiceCostsSettingInternally = true;
			PracticeCosts = calculatedPracticeCosts;
			_practiceCostsSettingInternally = false;
		}

		public void SilentlySetParkingLotMaintenanceCosts( decimal calculatedParkingLotMaintenanceCosts )
		{
			_parkingLotMaintenanceCostsSettingInternally = true;
			ParkingLotMaintenanceCosts = calculatedParkingLotMaintenanceCosts;
			_parkingLotMaintenanceCostsSettingInternally = false;
		}
	}
}