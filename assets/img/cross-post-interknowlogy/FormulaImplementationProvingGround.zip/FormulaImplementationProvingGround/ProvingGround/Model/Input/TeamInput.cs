﻿using System.Diagnostics;
using Microsoft.Practices.Prism.PubSubEvents;
using PropertyDependencyFramework;

namespace ProvingGround.Model.Input
{
	public class TeamInput : Bindable
	{
		protected bool _desiredWinRatioSettingInternally;
		private readonly TeamInputChangedPayload _inputChangedPayload;

		public TeamInput()
		{

		}

		public TeamInput( long teamId )
		{
			_inputChangedPayload = new TeamInputChangedPayload( teamId );
		}

		protected bool _desiredWinRatioSetExternally;
		public bool DesiredWinRatioSetExternally
		{
			[DebuggerStepThrough]
			get { return _desiredWinRatioSetExternally; }
			set
			{
				if ( value == _desiredWinRatioSetExternally )
					return;

				_desiredWinRatioSetExternally = value;
				NotifyPropertyChanged( () => DesiredWinRatioSetExternally );
			}
		}

		private decimal _desiredWinRatio;
		public decimal DesiredWinRatio
		{
			[DebuggerStepThrough]
			get { return _desiredWinRatio; }
			set
			{
				if ( value == _desiredWinRatio )
					return;

				if ( !_desiredWinRatioSettingInternally )
				{
					DesiredWinRatioSetExternally = true;
				}

				if ( DesiredWinRatioSetExternally && _desiredWinRatioSettingInternally )
				{
					return;
				}

				_desiredWinRatio = value;

				var stopwatch = new Stopwatch();
				if ( !_desiredWinRatioSettingInternally )
				{
					EventAggregatorProvider.Instance.EventAggregator.GetEvent<PubSubEvent<TeamInputChangedPayload>>().Publish( _inputChangedPayload );
					//ChangeCount++;
					stopwatch.Start();
				}


				NotifyPropertyChanged( () => DesiredWinRatio );

				if ( !_desiredWinRatioSettingInternally )
				{
					stopwatch.Stop();
					Debug.WriteLine( string.Format( "DesiredWinRatio Set Complete: {0}", stopwatch.ElapsedMilliseconds ) );
				}
			}
		}

		private decimal _additionalMarketingCost;
		public decimal AdditionalMarketingCost
		{
			[DebuggerStepThrough]
			get { return _additionalMarketingCost; }
			set
			{
				if ( value == _additionalMarketingCost )
					return;

				_additionalMarketingCost = value;

				EventAggregatorProvider.Instance.EventAggregator.GetEvent<PubSubEvent<TeamInputChangedPayload>>().Publish( _inputChangedPayload );
				//ChangeCount++;

				NotifyPropertyChanged( () => AdditionalMarketingCost );
			}
		}

		private decimal _donations;
		public decimal Donations
		{
			[DebuggerStepThrough]
			get { return _donations; }
			set
			{
				if ( value == _donations )
					return;

				_donations = value;

				EventAggregatorProvider.Instance.EventAggregator.GetEvent<PubSubEvent<TeamInputChangedPayload>>().Publish( _inputChangedPayload );
				//ChangeCount++;

				NotifyPropertyChanged( () => Donations );
			}
		}

		//private int _changeCount;
		//public int ChangeCount
		//{
		//	[DebuggerStepThrough]
		//	get { return _changeCount; }
		//	set
		//	{
		//		if ( value == _changeCount )
		//			return;

		//		_changeCount = value;
		//		NotifyPropertyChanged( () => ChangeCount );
		//	}
		//}

		public void SilentlySetDesiredWinRatio( decimal calculatedDesiredWinRatio )
		{
			_desiredWinRatioSettingInternally = true;
			DesiredWinRatio = calculatedDesiredWinRatio;
			_desiredWinRatioSettingInternally = false;
		}
	}

	public class TeamInputChangedPayload
	{
		public TeamInputChangedPayload( long teamId )
		{
			TeamId = teamId;
		}

		public long TeamId { get; private set; }
	}
}