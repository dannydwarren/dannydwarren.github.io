﻿using System.Diagnostics;
using Microsoft.Practices.Prism.PubSubEvents;
using PropertyDependencyFramework;

namespace ProvingGround.Model.Input
{
	public class StadiumTeamDataInput : Bindable
	{
		private readonly StadiumTeamDataInputChangedPayload _inputChangedPayload;

		public StadiumTeamDataInput()
		{
			
		}

		public StadiumTeamDataInput( long stadiumId, long teamId )
		{
			_inputChangedPayload = new StadiumTeamDataInputChangedPayload( stadiumId, teamId );
		}

		private bool _isHome;
		public bool IsHome
		{
			[DebuggerStepThrough]
			get { return _isHome; }
			set
			{
				if ( value == _isHome )
					return;

				_isHome = value;

				EventAggregatorProvider.Instance.EventAggregator.GetEvent<PubSubEvent<StadiumTeamDataInputChangedPayload>>().Publish( _inputChangedPayload );
				//ChangeCount++;

				NotifyPropertyChanged( () => IsHome );
			}
		}

		private decimal _wins;
		public decimal Wins
		{
			[DebuggerStepThrough]
			get { return _wins; }
			set
			{
				if ( value == _wins )
					return;

				_wins = value;

				EventAggregatorProvider.Instance.EventAggregator.GetEvent<PubSubEvent<StadiumTeamDataInputChangedPayload>>().Publish( _inputChangedPayload );
				//ChangeCount++;

				NotifyPropertyChanged( () => Wins );
			}
		}

		private decimal _losses;
		public decimal Losses
		{
			[DebuggerStepThrough]
			get { return _losses; }
			set
			{
				if ( value == _losses )
					return;

				_losses = value;

				EventAggregatorProvider.Instance.EventAggregator.GetEvent<PubSubEvent<StadiumTeamDataInputChangedPayload>>().Publish( _inputChangedPayload );
				//ChangeCount++;

				NotifyPropertyChanged( () => Losses );
			}
		}

		//private int _changeCount;
		//public int ChangeCount
		//{
		//	[DebuggerStepThrough]
		//	get { return _changeCount; }
		//	set
		//	{
		//		if ( value == _changeCount )
		//			return;

		//		_changeCount = value;
		//		NotifyPropertyChanged( () => ChangeCount );
		//	}
		//}
	}

	public class StadiumTeamDataInputChangedPayload
	{
		public StadiumTeamDataInputChangedPayload( long stadiumId, long teamId )
		{
			StadiumId = stadiumId;
			TeamId = teamId;
		}

		public long StadiumId { get; private set; }
		public long TeamId { get; private set; }
	}
}