﻿using System.Diagnostics;
using PropertyDependencyFramework;

namespace ProvingGround.Model.Input
{
	public class StadiumInput : Bindable
	{
		private decimal _ticketPrice;
		public decimal TicketPrice
		{
			[DebuggerStepThrough]
			get { return _ticketPrice; }
			set
			{
				if ( value == _ticketPrice )
					return;

				_ticketPrice = value;
				NotifyPropertyChanged( () => TicketPrice );
			}
		}

		private decimal _seats;
		public decimal Seats
		{
			[DebuggerStepThrough]
			get { return _seats; }
			set
			{
				if ( value == _seats )
					return;

				_seats = value;
				NotifyPropertyChanged( () => Seats );
			}
		}

		private decimal _consessionProfitRatio;
		public decimal ConsessionProfitRatio
		{
			[DebuggerStepThrough]
			get { return _consessionProfitRatio; }
			set
			{
				if ( value == _consessionProfitRatio )
					return;

				_consessionProfitRatio = value;
				NotifyPropertyChanged( () => ConsessionProfitRatio );
			}
		}

		private decimal _averageConsessionPricePerItem;
		public decimal AverageConsessionPricePerItem
		{
			[DebuggerStepThrough]
			get { return _averageConsessionPricePerItem; }
			set
			{
				if ( value == _averageConsessionPricePerItem )
					return;

				_averageConsessionPricePerItem = value;
				NotifyPropertyChanged( () => AverageConsessionPricePerItem );
			}
		}

		private decimal _consessionPurchaseRatio;
		public decimal ConsessionPurchaseRatio
		{
			[DebuggerStepThrough]
			get { return _consessionPurchaseRatio; }
			set
			{
				if ( value == _consessionPurchaseRatio )
					return;

				_consessionPurchaseRatio = value;
				NotifyPropertyChanged( () => ConsessionPurchaseRatio );
			}
		}

		private decimal _revenueSplitWithVisitingTeamRatio;
		public decimal RevenueSplitWithVisitingTeamRatio
		{
			[DebuggerStepThrough]
			get { return _revenueSplitWithVisitingTeamRatio; }
			set
			{
				if ( value == _revenueSplitWithVisitingTeamRatio )
					return;

				_revenueSplitWithVisitingTeamRatio = value;
				NotifyPropertyChanged( () => RevenueSplitWithVisitingTeamRatio );
			}
		}

		private decimal _lockerRoomRentalFeePercent;
		public decimal LockerRoomRentalFeePercent
		{
			[DebuggerStepThrough]
			get { return _lockerRoomRentalFeePercent; }
			set
			{
				if ( value == _lockerRoomRentalFeePercent )
					return;

				_lockerRoomRentalFeePercent = value;
				NotifyPropertyChanged( () => LockerRoomRentalFeePercent );
			}
		}

		private decimal _poorSalesFeePercent;
		public decimal PoorSalesFeePercent
		{
			[DebuggerStepThrough]
			get { return _poorSalesFeePercent; }
			set
			{
				if ( value == _poorSalesFeePercent )
					return;

				_poorSalesFeePercent = value;
				NotifyPropertyChanged( () => PoorSalesFeePercent );
			}
		}

		private decimal _practiceCost;
		public decimal PracticeCost
		{
			[DebuggerStepThrough]
			get { return _practiceCost; }
			set
			{
				if ( value == _practiceCost )
					return;

				_practiceCost = value;
				NotifyPropertyChanged( () => PracticeCost );
			}
		}

		private decimal _marketingCost;
		public decimal MarketingCost
		{
			[DebuggerStepThrough]
			get { return _marketingCost; }
			set
			{
				if ( value == _marketingCost )
					return;

				_marketingCost = value;
				NotifyPropertyChanged( () => MarketingCost );
			}
		}

		private decimal _parkingLotMaintenancePerTicket;
		public decimal ParkingLotMaintenancePerTicket
		{
			[DebuggerStepThrough]
			get { return _parkingLotMaintenancePerTicket; }
			set
			{
				if ( value == _parkingLotMaintenancePerTicket )
					return;

				_parkingLotMaintenancePerTicket = value;
				NotifyPropertyChanged( () => ParkingLotMaintenancePerTicket );
			}
		}

		private MaintenanceSchedule _maintenanceSchedule;
		public MaintenanceSchedule MaintenanceSchedule
		{
			[DebuggerStepThrough]
			get { return _maintenanceSchedule; }
			set
			{
				if ( value == _maintenanceSchedule )
					return;

				_maintenanceSchedule = value;
				NotifyPropertyChanged( () => MaintenanceSchedule );
			}
		}

		private bool _include;
		public bool Include
		{
			[DebuggerStepThrough]
			get { return _include; }
			set
			{
				if ( value == _include )
					return;

				_include = value;
				NotifyPropertyChanged( () => Include );
			}
		}

		private decimal _rateOfIncrease;
		public decimal RateOfIncrease
		{
			[DebuggerStepThrough]
			get { return _rateOfIncrease; }
			set
			{
				if ( value == _rateOfIncrease )
					return;

				_rateOfIncrease = value;
				NotifyPropertyChanged( () => RateOfIncrease );
			}
		}
	}
}