﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using WinRTUsingMvvm.Models;

namespace WinRTUsingMvvm.ViewModels
{
	public class MainVM : Bindable
	{
		private static readonly int NUM_MOCK_CONTACTS = 20;

		public MainVM()
		{
			Contacts = new ObservableCollection<Contact>();
			CreateEditContactVM = new CreateEditContactVM();
			CreateEditContactVM.ContactCreated += ContactCreatedHandler;

			CreateMockContacts();
		}

		private ObservableCollection<Contact> _contacts;
		public ObservableCollection<Contact> Contacts
		{
			[DebuggerStepThrough]
			get { return _contacts; }
			set
			{
				if ( value == _contacts )
					return;

				_contacts = value;
				OnPropertyChanged( "Contacts" );
			}
		}

		private Contact _selectedContact;
		public Contact SelectedContact
		{
			[DebuggerStepThrough]
			get { return _selectedContact; }
			set
			{
				if ( value == _selectedContact )
					return;

				_selectedContact = value;
				OnPropertyChanged( "SelectedContact" );
			}
		}

		private CreateEditContactVM _createEditContactVM;
		public CreateEditContactVM CreateEditContactVM
		{
			[DebuggerStepThrough]
			get { return _createEditContactVM; }
			set
			{
				if ( value == _createEditContactVM )
					return;

				_createEditContactVM = value;
				OnPropertyChanged( "CreateEditContactVM" );
			}
		}
		
		private DelegateCommand _createContactCommand;
		public DelegateCommand CreateContactCommand
		{
			get { return _createContactCommand = _createContactCommand ?? new DelegateCommand( CreateContactExecutedHandler ); }
		}
		private void CreateContactExecutedHandler()
		{
			CreateEditContactVM.Create();
		}

		private DelegateCommand<Contact> _editContactCommand;
		public DelegateCommand<Contact> EditContactCommand
		{
			get
			{
				return
					_editContactCommand =
					_editContactCommand ?? new DelegateCommand<Contact>( EditContactExecutedHandler, EditContactCanExecuteHandler );
			}
		}
		private bool EditContactCanExecuteHandler( Contact contact )
		{
			return contact != null;
		}
		private void EditContactExecutedHandler( Contact contact )
		{
			CreateEditContactVM.Edit( contact );
		}
		
		private DelegateCommand<Contact> _deleteContactCommand;
		public DelegateCommand<Contact> DeleteContactCommand
		{
			get
			{
				return
					_deleteContactCommand =
					_deleteContactCommand ?? new DelegateCommand<Contact>( DeleteContactExecutedHandler, DeleteContactCanExecuteHandler );
			}
		}
		private bool DeleteContactCanExecuteHandler( Contact contact )
		{
			return contact != null;
		}
		private void DeleteContactExecutedHandler( Contact contact )
		{
			Contacts.Remove( contact );
		}

		private void ContactCreatedHandler( object sender, ContactCreatedEventArgs e )
		{
			Contacts.Add( e.Contact );
		}

		private void CreateMockContacts()
		{
			for ( int i = 0; i < NUM_MOCK_CONTACTS; i++ )
			{
				Contact mockContact = new Contact
					                      {
											  ProfileImageUri = new Uri( "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRXhIrDbAlAQoAoFFPNIFTBpvIPDTCGRGadyYk3bLCK25oCXrQOxw" ),
											  FirstName = "First" + i,
											  LastName = "Last" + i,
											  Address= string.Format("123 Cool Street{0}Cool Town, CA 90210", Environment.NewLine),
											  Email = "cool@email.com",
											  FavoriteLanguage = ProgrammingLanguage.CSharp,
											  Age = i,
					                      };

				Contacts.Add(mockContact);
			}

		}
	}
}