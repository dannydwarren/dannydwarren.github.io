﻿using System;
using System.Diagnostics;
using System.Windows.Input;

namespace WinRTUsingMvvm.ViewModels
{
	//http://stackoverflow.com/questions/11960488/any-winrt-icommand-commandbinding-implementaiton-samples-out-there
	public class DelegateCommand : ICommand
	{
		#region Fields

		private readonly Func<bool> _canExecuteMethod;
		private readonly Action _executeMethod;

		#endregion

		#region Constructors

		public DelegateCommand( Action executeMethod )
			: this( executeMethod, null )
		{
		}

		public DelegateCommand( Action executeMethod, Func<bool> canExecuteMethod )
		{
			_executeMethod = executeMethod;
			_canExecuteMethod = canExecuteMethod;
		}

		#endregion

		#region ICommand Members

		public event EventHandler CanExecuteChanged = delegate { };
		private void OnCanExecuteChanged( EventArgs e )
		{
			var handler = CanExecuteChanged;
			if ( handler != null )
			{
				handler( this, e );
			}
		}

		bool ICommand.CanExecute( object parameter )
		{
			try
			{
				return CanExecute();
			}
			catch { return false; }
		}

		void ICommand.Execute( object parameter )
		{
			Execute();
		}

		#endregion

		#region Public Methods

		public bool CanExecute()
		{
			return ( ( _canExecuteMethod == null ) || _canExecuteMethod() );
		}

		public void Execute()
		{
			if ( _executeMethod != null )
			{
				_executeMethod();
			}
		}

		public void RaiseCanExecuteChanged()
		{
			OnCanExecuteChanged( EventArgs.Empty );
		}

		#endregion
	}

	public class DelegateCommand<T> : ICommand
	{
		#region Fields

		private readonly Func<T, bool> _canExecuteMethod;
		private readonly Action<T> _executeMethod;

		#endregion

		#region Constructors

		public DelegateCommand( Action<T> executeMethod )
			: this( executeMethod, null )
		{
		}

		public DelegateCommand( Action<T> executeMethod, Func<T, bool> canExecuteMethod )
		{
			_executeMethod = executeMethod;
			_canExecuteMethod = canExecuteMethod;
		}

		#endregion

		#region ICommand Members

		public event EventHandler CanExecuteChanged = delegate { };
		private void OnCanExecuteChanged( EventArgs e )
		{
			var handler = CanExecuteChanged;
			if ( handler != null )
			{
				handler( this, e );
			}
		}

		bool ICommand.CanExecute( object parameter )
		{
			try
			{
				return CanExecute( (T)parameter );
			}
			catch { return false; }
		}

		void ICommand.Execute( object parameter )
		{
			Execute( (T)parameter );
		}

		#endregion

		#region Public Methods

		public bool CanExecute( T parameter )
		{
			return ( ( _canExecuteMethod == null ) || _canExecuteMethod( parameter ) );
		}

		public void Execute( T parameter )
		{
			if ( _executeMethod != null )
			{
				_executeMethod( parameter );
			}
		}

		public void RaiseCanExecuteChanged()
		{
			OnCanExecuteChanged( EventArgs.Empty );
		}

		#endregion
	}

}