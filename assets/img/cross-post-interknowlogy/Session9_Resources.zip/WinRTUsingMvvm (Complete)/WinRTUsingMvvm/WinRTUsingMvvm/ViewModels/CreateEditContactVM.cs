﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;
using WinRTUsingMvvm.Models;

namespace WinRTUsingMvvm.ViewModels
{
	public class CreateEditContactVM : Bindable
	{
		private bool _isCreate;
		private Contact _originalContact;

		public CreateEditContactVM()
		{
			Languages = Enum.GetValues(typeof (ProgrammingLanguage))
			                .Cast<ProgrammingLanguage>()
			                .ToArray();
		}

		private bool _isEditing;
		public bool IsEditing
		{
			[DebuggerStepThrough]
			get { return _isEditing; }
			private set
			{
				if ( value == _isEditing )
					return;

				_isEditing = value;
				OnPropertyChanged( "IsEditing" );
			}
		}

		private Contact _contact;
		public Contact Contact
		{
			[DebuggerStepThrough]
			get { return _contact; }
			set
			{
				if ( value == _contact )
					return;

				_contact = value;
				OnPropertyChanged( "Contact" );
			}
		}

		private string _profileImageUriBridge;
		public string ProfileImageUriBridge
		{
			[DebuggerStepThrough]
			get { return _profileImageUriBridge; }
			set
			{
				if ( value == _profileImageUriBridge )
					return;

				_profileImageUriBridge = value;
				OnPropertyChanged( "ProfileImageUriBridge" );
			}
		}

		private ProgrammingLanguage[] _languages;
		public ProgrammingLanguage[] Languages
		{
			[DebuggerStepThrough]
			get { return _languages; }
			set
			{
				if ( value == _languages )
					return;

				_languages = value;
				OnPropertyChanged( "Languages" );
			}
		}

		public event EventHandler<ContactCreatedEventArgs> ContactCreated = delegate { };
		private void OnContactCreated( ContactCreatedEventArgs args )
		{
			ContactCreated( this, args );
		}

		private DelegateCommand _acceptChangesCommand;
		public DelegateCommand AcceptChangesCommand
		{
			get
			{
				return _acceptChangesCommand = _acceptChangesCommand ?? new DelegateCommand( AcceptChangesExecutedHandler, AcceptChangesCanExecuteHandler );
			}
		}
		private bool AcceptChangesCanExecuteHandler()
		{
			//return true;
			return IsValid();
		}
		private void AcceptChangesExecutedHandler()
		{
			if ( _isCreate )
			{
				OnContactCreated( new ContactCreatedEventArgs( Contact ) );
			}
			else
			{
				PersistChanges();
			}
			Reset();
		}

		private DelegateCommand _cancelChangesCommand;
		public DelegateCommand CancelChangesCommand
		{
			get
			{
				return _cancelChangesCommand = _cancelChangesCommand ?? new DelegateCommand( CancelChangesExecutedHandler, CancelChangesCanExecuteHandler );
			}
		}
		private bool CancelChangesCanExecuteHandler()
		{
			return true;
		}
		private void CancelChangesExecutedHandler()
		{
			Reset();
		}

		private void Reset()
		{
			_isCreate = false;
			Contact = null;
			_originalContact = null;
			IsEditing = false;
		}

		public void Create()
		{
			_isCreate = true;
			Contact = new Contact();
			InitializeProfileImageUriBridge();
			IsEditing = true;
		}

		private void InitializeProfileImageUriBridge()
		{
			ProfileImageUriBridge = Contact.ProfileImageUri != null ? Contact.ProfileImageUri.OriginalString : null;
		}

		public void Edit( Contact contact )
		{
			//STEP 4: Create a copy of the contact and enable AcceptChangesCanExecuteHandler
			Contact = contact.Copy();
			InitializeProfileImageUriBridge();
			_originalContact = contact;
			IsEditing = true;
		}

		private void PersistChanges()
		{
			_originalContact.ProfileImageUri = Contact.ProfileImageUri;
			_originalContact.FirstName = Contact.FirstName;
			_originalContact.LastName = Contact.LastName;
			_originalContact.Address = Contact.Address;
			_originalContact.Email = Contact.Email;
			_originalContact.FavoriteLanguage = Contact.FavoriteLanguage;
			_originalContact.Age = Contact.Age;
		}

		private bool IsValid()
		{
			return IsValidateProfileUri( ProfileImageUriBridge )
				   && IsValidateEmail( Contact.Email );
		}

		private bool IsValidateProfileUri( string profileUri )
		{
			return Uri.IsWellFormedUriString( profileUri, UriKind.Absolute );
		}

		private bool IsValidateEmail( string email )
		{
			Regex regex = new Regex( @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$" );
			Match match = regex.Match( email );

			return match.Success;
		}
	}

	public class ContactCreatedEventArgs : EventArgs
	{
		public ContactCreatedEventArgs( Contact contact )
		{
			Contact = contact;
		}

		public Contact Contact { get; private set; }
	}
}