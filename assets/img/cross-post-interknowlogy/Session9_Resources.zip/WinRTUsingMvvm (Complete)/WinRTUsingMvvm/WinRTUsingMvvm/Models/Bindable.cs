﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace WinRTUsingMvvm.Models
{
	public class Bindable : INotifyPropertyChanged
	{
		//STEP 3: Bindable : INotifyPropertyChanged
		public event PropertyChangedEventHandler PropertyChanged;

		//Learn more about CallerMemberName: http://msdn.microsoft.com/en-us/library/system.runtime.compilerservices.callermembernameattribute.aspx
		//This app was built without CallerMemberName. However, using CallerMemberName is a better practice than what we have done. 
		// In the Contact class you will find in each property a usage of OnPropertyChanged not using CallerMemberName commented out and a usage benefiting from CallerMemberName in use.
		protected void OnPropertyChanged( [CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler handler = PropertyChanged;
			if (handler != null)
			{
				handler( this, new PropertyChangedEventArgs( propertyName ) );
			}
		}
	}
}
