﻿namespace WinRTUsingMvvm.Models
{
	public enum ProgrammingLanguage
	{
		None,
		CSharp,
		Java,
		Python,
		Ruby,
		Cobalt,
		C,
		CPlusPlus,
	}
}