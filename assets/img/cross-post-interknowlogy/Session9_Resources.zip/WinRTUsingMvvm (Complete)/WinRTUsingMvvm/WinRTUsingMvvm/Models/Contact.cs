﻿using System;
using System.Diagnostics;

namespace WinRTUsingMvvm.Models
{
	//NOTE: This class is using OnPropertyChanged benefiting from CallerMemberName. This means we do not need to pass in a string name of the property.
	public class Contact : Bindable
	{
		private Uri _profileImageUri;
		public Uri ProfileImageUri
		{
			[DebuggerStepThrough]
			get { return _profileImageUri; }
			set
			{
				if ( value == _profileImageUri )
				{
					return;
				}
				_profileImageUri = value;
				//OnPropertyChanged( "ProfileImageUri" );
				OnPropertyChanged();
			}
		}

		private string _firstName;
		public string FirstName
		{
			[DebuggerStepThrough]
			get { return _firstName; }
			set
			{
				if ( value == _firstName )
					return;

				_firstName = value;
				//OnPropertyChanged( "FirstName" );
				OnPropertyChanged();
			}
		}

		private string _lastName;
		public string LastName
		{
			[DebuggerStepThrough]
			get { return _lastName; }
			set
			{
				if ( value == _lastName )
					return;

				_lastName = value;
				//OnPropertyChanged( "LastName" );
				OnPropertyChanged();
			}
		}

		private string _address;
		public string Address
		{
			[DebuggerStepThrough]
			get { return _address; }
			set
			{
				if ( value == _address )
					return;

				_address = value;
				//OnPropertyChanged( "Address" );
				OnPropertyChanged();
			}
		}

		private string _email;
		public string Email
		{
			[DebuggerStepThrough]
			get { return _email; }
			set
			{
				if ( value == _email )
					return;

				_email = value;
				//OnPropertyChanged( "Email" );
				OnPropertyChanged();
			}
		}

		private ProgrammingLanguage _favoriteLanguage;
		public ProgrammingLanguage FavoriteLanguage
		{
			[DebuggerStepThrough]
			get { return _favoriteLanguage; }
			set
			{
				if ( value == _favoriteLanguage )
					return;

				_favoriteLanguage = value;
				//OnPropertyChanged( "FavoriteLanguage" );
				OnPropertyChanged();
			}
		}

		private int _age;
		public int Age
		{
			[DebuggerStepThrough]
			get { return _age; }
			set
			{
				if ( value == _age )
					return;

				_age = value;
				//OnPropertyChanged( "Age" );
				OnPropertyChanged();
			}
		}

		public Contact Copy()
		{
			return new Contact
					   {
						   ProfileImageUri = ProfileImageUri != null ? new Uri( ProfileImageUri.OriginalString ) : null,
						   FirstName = FirstName,
						   LastName = LastName,
						   Address = Address,
						   Email = Email,
						   FavoriteLanguage = FavoriteLanguage,
						   Age = Age,
					   };
		}
	}
}
