﻿namespace WinRTUsingMvvm.Models
{
	public class Bindable
	{
		//STEP 3: Bindable : INotifyPropertyChanged

		protected void OnPropertyChanged( string contact )
		{
			
		}
	}
}
