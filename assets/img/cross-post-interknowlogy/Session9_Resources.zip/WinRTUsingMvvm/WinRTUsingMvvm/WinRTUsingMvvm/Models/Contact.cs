﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace WinRTUsingMvvm.Models
{
	public class Contact : Bindable
	{
		private Uri _profileImageUri;
		public Uri ProfileImageUri
		{
			[DebuggerStepThrough]
			get { return _profileImageUri; }
			set
			{
				if ( value == _profileImageUri )
				{
					return;
				}
				_profileImageUri = value;
				//OnPropertyChanged( "ProfileImageUri" );
			}
		}

		private string _firstName;
		public string FirstName
		{
			[DebuggerStepThrough]
			get { return _firstName; }
			set
			{
				if ( value == _firstName )
					return;

				_firstName = value;
				//OnPropertyChanged( "FirstName" );
			}
		}

		private string _lastName;
		public string LastName
		{
			[DebuggerStepThrough]
			get { return _lastName; }
			set
			{
				if ( value == _lastName )
					return;

				_lastName = value;
				//OnPropertyChanged( "LastName" );
			}
		}

		private string _address;
		public string Address
		{
			[DebuggerStepThrough]
			get { return _address; }
			set
			{
				if ( value == _address )
					return;

				_address = value;
				//OnPropertyChanged( "Address" );
			}
		}

		private string _email;
		public string Email
		{
			[DebuggerStepThrough]
			get { return _email; }
			set
			{
				if ( value == _email )
					return;
				
				_email = value;
				//OnPropertyChanged( "Email" );
			}
		}

		private ProgrammingLanguage _favoriteLanguage;
		public ProgrammingLanguage FavoriteLanguage
		{
			[DebuggerStepThrough]
			get { return _favoriteLanguage; }
			set
			{
				if ( value == _favoriteLanguage )
					return;

				_favoriteLanguage = value;
				//OnPropertyChanged( "FavoriteLanguage" );
			}
		}

		private int _age;
		public int Age
		{
			[DebuggerStepThrough]
			get { return _age; }
			set
			{
				if ( value == _age )
					return;

				_age = value;
				//OnPropertyChanged( "Age" );
			}
		}

		public Contact Copy()
		{
			return new Contact
					   {
						   ProfileImageUri = new Uri( ProfileImageUri.OriginalString ),
						   FirstName = FirstName,
						   LastName = LastName,
						   Address = Address,
						   Email = Email,
						   FavoriteLanguage = FavoriteLanguage,
						   Age = Age,
					   };
		}
	}
}
