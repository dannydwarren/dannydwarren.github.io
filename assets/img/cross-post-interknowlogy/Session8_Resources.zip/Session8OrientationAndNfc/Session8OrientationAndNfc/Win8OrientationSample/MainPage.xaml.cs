﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace Win8OrientationSample
{
	/// <summary>
	/// An empty page that can be used on its own or navigated to within a Frame.
	/// </summary>
	public sealed partial class MainPage : Page
	{
		public MainPage()
		{
			this.InitializeComponent();
		}

		public List<string> Strings { get; set; }

		/// <summary>
		/// Invoked when this page is about to be displayed in a Frame.
		/// </summary>
		/// <param name="e">Event data that describes how this page was reached.  The Parameter
		/// property is typically used to configure the page.</param>
		protected override void OnNavigatedTo( NavigationEventArgs e )
		{
			InitializeItems();

			DisplayProperties.OrientationChanged += DisplayProperties_OrientationChanged;
			UpdateUIFromCurrentOrientation();
		}

		private void InitializeItems()
		{
			Strings = new List<string>();
			for ( int i = 0; i < 100; i++ )
			{
				Strings.Add( string.Format( "This is my cool number: {0}!", i ) );
			}

		}

		void DisplayProperties_OrientationChanged( object sender )
		{
			UpdateUIFromCurrentOrientation();
		}

		private void UpdateUIFromCurrentOrientation()
		{
			DisplayOrientations orientation = DisplayProperties.CurrentOrientation;

			OrientationName.Text = orientation.ToString();

			switch ( orientation )
			{
				case DisplayOrientations.None:
				case DisplayOrientations.Landscape:
					case DisplayOrientations.LandscapeFlipped:
				VisualStateManager.GoToState( this, "Landscape", false);
					break;
				case DisplayOrientations.Portrait:
				case DisplayOrientations.PortraitFlipped:
					VisualStateManager.GoToState( this, "Portrait", false);
					break;
			}
		}
	}
}
