﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Networking.Proximity;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace Windows8Nfc
{
	/// <summary>
	/// An empty page that can be used on its own or navigated to within a Frame.
	/// </summary>
	public sealed partial class MainPage : Page
	{

		public MainPage()
		{
			this.InitializeComponent();
		}

		/// <summary>
		/// Invoked when this page is about to be displayed in a Frame.
		/// </summary>
		/// <param name="e">Event data that describes how this page was reached.  The Parameter
		/// property is typically used to configure the page.</param>
		protected override void OnNavigatedTo( NavigationEventArgs e )
		{
			InitializeProximityDevice();
		}

		private ProximityDevice _proximityDevice;
		private void InitializeProximityDevice()
		{
			_proximityDevice = ProximityDevice.GetDefault();

			string deviceInitializationResultMessage = "Failed to initialize Proximity Device.";
			if ( _proximityDevice != null )
			{
				deviceInitializationResultMessage = "Proximity Device initialized!";
			}
			var dialog = new MessageDialog( deviceInitializationResultMessage );
			dialog.ShowAsync();

		}

		private long _messageId = -1;

		private void StartPublishing()
		{
			StartPublishingButton.Visibility = Visibility.Collapsed;
			StopPublishingButton.Visibility = Visibility.Visible;

			if ( _messageId == -1 )
			{
				_proximityDevice.StopPublishingMessage( _messageId );
			}

			_messageId = _proximityDevice.PublishUriMessage( new Uri( "http://www.interknowlogy.com" ) );
		}

		private void StopPublishing()
		{
			StartPublishingButton.Visibility = Visibility.Visible;
			StopPublishingButton.Visibility = Visibility.Collapsed;

			_proximityDevice.StopPublishingMessage( _messageId );
			
			_messageId = -1;
		}

		private void Button_Click_1( object sender, RoutedEventArgs e )
		{
			//StartPublishing();
			StartSubscribing();
		}

		private void Button_Click_2( object sender, RoutedEventArgs e )
		{
			//StopPublishing();
			StopSubscribing();
		}

		private long _subscriptionMessageId = -1;
		private readonly string _subscriptionMessageType = "Windows.Win8DevClass";
		private void StartSubscribing()
		{
			StartPublishingButton.Visibility = Visibility.Collapsed;
			StopPublishingButton.Visibility = Visibility.Visible;
			
			if ( _subscriptionMessageId == -1 )
			{
				_subscriptionMessageId = _proximityDevice.SubscribeForMessage(_subscriptionMessageType, MessageRecieved);
			}	
		}

		private void MessageRecieved(ProximityDevice sender, ProximityMessage message)
		{
			WriteMessageText(string.Format("{0}: {1}", _subscriptionMessageType, message.DataAsString));
		}

		private void StopSubscribing()
		{
			StartPublishingButton.Visibility = Visibility.Visible;
			StopPublishingButton.Visibility = Visibility.Collapsed;
			
			_proximityDevice.StopSubscribingForMessage( _subscriptionMessageId );
			_subscriptionMessageId = -1;
		}

		private Windows.UI.Core.CoreDispatcher messageDispatcher = Window.Current.CoreWindow.Dispatcher;

		async private void WriteMessageText( string message, bool overwrite = false )
		{
			await messageDispatcher.RunAsync( Windows.UI.Core.CoreDispatcherPriority.Normal,
				() =>
				{
					if ( overwrite )
						MessageDisplay.Text = message;
					else
						MessageDisplay.Text += message;
				} );
		}

	}
}
