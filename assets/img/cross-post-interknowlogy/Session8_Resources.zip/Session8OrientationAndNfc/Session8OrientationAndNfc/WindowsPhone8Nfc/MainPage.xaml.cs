﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Windows.Networking.Proximity;
using Windows.UI.Core;
using WindowsPhone8Nfc.Resources;

namespace WindowsPhone8Nfc
{
	public partial class MainPage : PhoneApplicationPage
	{
		private ProximityDevice _proximityDevice;

		// Constructor
		public MainPage()
		{
			InitializeComponent();
		}

		protected override void OnNavigatedTo( NavigationEventArgs e )
		{
			base.OnNavigatedTo( e );

			InitializeProximityDevice();
		}

		private void InitializeProximityDevice()
		{
			_proximityDevice = ProximityDevice.GetDefault();

			string deviceInitializationResultMessage = "Failed to initialize Proximity Device.";
			if ( _proximityDevice != null )
			{
				deviceInitializationResultMessage = "Proximity Device initialized!";
			}
			MessageBox.Show( deviceInitializationResultMessage );
		}

		private long _messageId = -1;

		private void StartPublishingUri()
		{
			StartPublishingButton.Visibility = Visibility.Collapsed;
			StopPublishingButton.Visibility = Visibility.Visible;

			if ( _messageId == -1 )
			{
				_proximityDevice.StopPublishingMessage( _messageId );
			}

			_messageId = _proximityDevice.PublishUriMessage( new Uri( "http://www.interknowlogy.com" ) );
		}

		private void StartPublishingMessage()
		{
			StartPublishingButton.Visibility = Visibility.Collapsed;
			StopPublishingButton.Visibility = Visibility.Visible;

			if ( _messageId == -1 )
			{
				_proximityDevice.StopPublishingMessage( _messageId );
			}

			_messageId = _proximityDevice.PublishMessage(_subscriptionMessageType, MessageToSend.Text);
		}

		private void StopPublishingMessage()
		{
			StartPublishingButton.Visibility = Visibility.Visible;
			StopPublishingButton.Visibility = Visibility.Collapsed;

			_proximityDevice.StopPublishingMessage( _messageId );

			_messageId = -1;
		}


		private void Button_Click_1( object sender, RoutedEventArgs e )
		{
			//StartPublishingUri();
			//StartSubscribing();
			StartPublishingMessage();
		}

		private void Button_Click_2( object sender, RoutedEventArgs e )
		{
			//StopSubscribing();
			StopPublishingMessage();
		}


		private long _subscriptionMessageId = -1;
		private readonly string _subscriptionMessageType = "Windows.Win8DevClass"; // Must be "Windows.*"
		private void StartSubscribing()
		{
			StartPublishingButton.Visibility = Visibility.Collapsed;
			StopPublishingButton.Visibility = Visibility.Visible;
			
			if ( _subscriptionMessageId == -1 )
			{
				_subscriptionMessageId = _proximityDevice.SubscribeForMessage( _subscriptionMessageType, MessageRecieved );
			}
		}

		private void MessageRecieved( ProximityDevice sender, ProximityMessage message )
		{
			MessageDisplay.Text = string.Format( "{0}: {1}", _subscriptionMessageType, message.DataAsString );
		}

		private void StopSubscribing()
		{
			StartPublishingButton.Visibility = Visibility.Visible;
			StopPublishingButton.Visibility = Visibility.Collapsed;
			
			_proximityDevice.StopSubscribingForMessage( _subscriptionMessageId );
			_subscriptionMessageId = -1;
		}



	}
}