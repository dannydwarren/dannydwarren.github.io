﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel.Activation;
using Windows.Storage;
using Windows.Storage.Streams;
using WinRTFramework.Common;

namespace DemoApp
{
	class ShareTargetVM : Bindable,
		WinRTFramework.Interfaces.Contracts.Sharing.ISupportSharingTargetContract,
		WinRTFramework.Interfaces.Navigation.ViewModel.ICareAboutNavigationFlow
	{
		ShareTargetActivatedEventArgs _currentShareArgs;

		private string _sharedData;
		public string SharedData
		{
			get { return _sharedData; }
			set
			{
				_sharedData = value;
				NotifyPropertyChanged( () => SharedData );
			}
		}

		public DelegateCommand SaveCommand { get; set; }
		private async void SaveExecutedHandler()
		{
			string title = DateTime.Now.ToString().Replace( ":", "-" ).Replace( "/", "-" ).Replace( "\\", "-" );

			StorageFile file = await Windows.Storage.ApplicationData.Current.LocalFolder.CreateFileAsync( title, CreationCollisionOption.ReplaceExisting );

			using ( IRandomAccessStream stream = await file.OpenAsync( FileAccessMode.ReadWrite ) )
			{
				Stream netStream = stream.AsStream();

				var serializer = new DataContractSerializer( typeof( DemoApp.DiaryPageVM.TransientState ) );
				serializer.WriteObject( netStream, GetTransientState( title ) );
			}

			_currentShareArgs.ShareOperation.ReportCompleted();
		}


		public object GetTransientState(string title)
		{
			return new DemoApp.DiaryPageVM.TransientState
			{
				Text = SharedData,
				FontFamily = "Arial",
				FontSize = 12,
				Title = title,
			};
		}


		public ShareTargetVM()
		{
			SaveCommand = new DelegateCommand( SaveExecutedHandler );
		}

		public void OnNavigatedFrom()
		{
		}

		public async void OnNavigatedTo( object navigationParameter )
		{
			ShareTargetActivatedEventArgs args = navigationParameter as ShareTargetActivatedEventArgs;

			if ( args != null )
			{
				_currentShareArgs = args;

				SharedData = await args.ShareOperation.Data.GetTextAsync();
			}
		}

		public void OnNavigatingFrom()
		{
		}
	}
}
