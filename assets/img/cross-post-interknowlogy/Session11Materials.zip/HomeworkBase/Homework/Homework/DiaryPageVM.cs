﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using WinRTFramework.Common;
using Windows.Storage;
using Windows.Storage.Streams;

namespace DemoApp
{
	class DiaryPageVM : Bindable,
		WinRTFramework.Interfaces.Navigation.ViewModel.IRequireNavigationService,
		WinRTFramework.Interfaces.AppStates.ISupportTransientState,
		WinRTFramework.Interfaces.Contracts.Settings.ViewModel.ISupportContextSpecificSettings,
		WinRTFramework.Interfaces.Navigation.ViewModel.ICareAboutNavigationFlow
	{
		public DiaryPageVM()
		{
			Settings = new SettingsVM();
		}

		public WinRTFramework.Interfaces.Navigation.INavigationService NavigationService
		{
			get;
			set;
		}

		public SettingsVM Settings { get; set; }

		private string _diaryText;
		public string DiaryText
		{
			get
			{
				return _diaryText;
			}

			set
			{
				_diaryText = value;
				NotifyPropertyChanged(() => DiaryText);
			}
		}

		public object GetTransientState()
		{
			return new TransientState
			{
				Text = DiaryText,
				FontFamily = Settings.SelectedFontFamily,
				FontSize = Settings.SelectedFontSize,
				Title = _title
			};
		}

		public IEnumerable<Type> GetTransientStateTypes()
		{
			yield return typeof(TransientState);
		}

		public void UpdateTransientState(object state)
		{
			TransientState transientState = (TransientState)state;
			DiaryText = transientState.Text;
			Settings.SelectedFontSize = transientState.FontSize;
			Settings.SelectedFontFamily = transientState.FontFamily;
			_title = transientState.Title;
		}

		public IEnumerable<WinRTFramework.Interfaces.Contracts.Settings
			.ViewModel.ISupportSettingsFlyout> GetSettingsFlyoutViewModels()
		{
			yield return Settings;
		}

		async public void OnNavigatedFrom()
		{			
			StorageFile file = await Windows.Storage.ApplicationData.Current.LocalFolder.CreateFileAsync(_title, CreationCollisionOption.ReplaceExisting);

			using (IRandomAccessStream stream = await file.OpenAsync(FileAccessMode.ReadWrite))
			{
				Stream netStream = stream.AsStream();

				var serializer = new DataContractSerializer(typeof (TransientState));
				serializer.WriteObject(netStream, GetTransientState());
			}
		}

		private string _title;
		async public void OnNavigatedTo(object navigationParameter)
		{
			if (navigationParameter == null)
				_title = DateTime.Now.ToString().Replace(":", "-").Replace("/", "-").Replace("\\", "-");
			else
			{
				StorageFile file = await Windows.Storage.ApplicationData.Current.LocalFolder.GetFileAsync((string) navigationParameter);
				using (IRandomAccessStream stream = await file.OpenReadAsync())
				{
					Stream netStream = stream.AsStream();

					var serializer = new DataContractSerializer(typeof (TransientState));
					UpdateTransientState(serializer.ReadObject(netStream));
				}
			}
		}

		public void OnNavigatingFrom()
		{

		}

		[DataContract]
		public class TransientState
		{
			[DataMember]
			public string Text { get; set; }

			[DataMember]
			public string FontFamily { get; set; }

			[DataMember]
			public double FontSize { get; set; }

			[DataMember]
			public string Title { get; set; }
		}
	}


}
