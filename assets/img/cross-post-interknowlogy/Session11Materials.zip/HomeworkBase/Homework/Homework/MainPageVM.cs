﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinRTFramework.Common;

namespace DemoApp
{
	class MainPageVM : Bindable, WinRTFramework.Interfaces.Navigation.ViewModel.IRequireNavigationService,
		WinRTFramework.Interfaces.Navigation.ViewModel.ICareAboutNavigationFlow,
		WinRTFramework.Interfaces.Contracts.Search.ISupportSearchActivation,
		WinRTFramework.Interfaces.Contracts.Sharing.ISupportSharingSourceContract
	{
		ObservableCollection<string> _foundDiaryEntries = new ObservableCollection<string>();
		public ObservableCollection<string> FoundDiaryEntries { get { return _foundDiaryEntries; } }

		ObservableCollection<string> _diaryEntries = new ObservableCollection<string>();
		public ObservableCollection<string> DiaryEntries { get { return _diaryEntries; }} 

		public DelegateCommand NavigateToNewCommand
		{
			get
			{
				return new DelegateCommand(CreateNewDiaryEntry);
			}
		}

		private DelegateCommand _navigateToSelectedCommand;
		public DelegateCommand NavigateToSelectedCommand
		{
			get
			{
				return _navigateToSelectedCommand = _navigateToSelectedCommand ?? new DelegateCommand(NavigateToSelectedDiaryEntry, () => SelectedEntry != null);
			}
		}

		private string _selectedEntry;
		public string SelectedEntry
		{
			get { return _selectedEntry; }
			set
			{
				_selectedEntry = value;
				NotifyPropertyChanged(() => SelectedEntry);
				NavigateToSelectedCommand.RaiseCanExecuteChanged();
			}
		}

		private void CreateNewDiaryEntry()
		{
			NavigationService.Navigate<DiaryPageVM>();
		}

		private void NavigateToSelectedDiaryEntry()
		{
			NavigationService.Navigate<DiaryPageVM>(SelectedEntry);
		}

		async private void LoadDiaryEntriesFromLocalStorage()
		{
			DiaryEntries.Clear();
			foreach (var diaryEntry in await Windows.Storage.ApplicationData.Current.LocalFolder.GetFilesAsync())
			{
				if(diaryEntry.FileType == ".")
					DiaryEntries.Add(diaryEntry.Name);
			}

			foreach ( string diaryEntry in DiaryEntries )
			{
				FoundDiaryEntries.Add( diaryEntry );
			}
		}

		public WinRTFramework.Interfaces.Navigation.INavigationService 
			NavigationService
		{
			get;
			set;
		}

		public void OnNavigatedFrom()
		{
			
		}

		public void OnNavigatedTo(object navigationParameter)
		{
			LoadDiaryEntriesFromLocalStorage();
		}

		public void OnNavigatingFrom()
		{
			
		}

		public void ProcessActivationQueryText( string language, string queryText )
		{
			FoundDiaryEntries.Clear();
			foreach ( string diaryEntryTitle in DiaryEntries )
			{
				if ( diaryEntryTitle.Contains(queryText) )
				{
					FoundDiaryEntries.Add( diaryEntryTitle );
				}
			}
		}

		public void OnSearchPaneSuggestionsRequested( Windows.ApplicationModel.Search.SearchPaneSuggestionsRequestedEventArgs args )
		{
			foreach ( string diaryEntryTitle in DiaryEntries )
			{
				if ( diaryEntryTitle.Contains( args.QueryText ) )
				{
					args.Request.SearchSuggestionCollection.AppendQuerySuggestion( diaryEntryTitle );
				}	
			}
		}

		public void ProcessQueryText( Windows.ApplicationModel.Search.SearchPaneQuerySubmittedEventArgs args )
		{
			ProcessActivationQueryText( args.Language, args.QueryText );
		}

		public void OnShareRequested( Windows.ApplicationModel.DataTransfer.DataRequest dataRequest )
		{
			if ( !string.IsNullOrEmpty(SelectedEntry) )
			{
				dataRequest.Data.SetText( SelectedEntry );
				dataRequest.Data.Properties.Title = "Selected Diary Entry";
			}
		}

		public WinRTFramework.Interfaces.Contracts.Sharing.ISharingService SharingService
		{
			get;
			set;
		}
	}
}
