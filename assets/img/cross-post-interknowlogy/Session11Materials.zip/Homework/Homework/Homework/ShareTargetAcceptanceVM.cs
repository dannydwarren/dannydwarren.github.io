﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using WinRTFramework.Common;
using Windows.ApplicationModel.Activation;
using Windows.ApplicationModel.DataTransfer;
using Windows.Storage;
using Windows.Storage.Streams;

namespace DemoApp
{
	internal class ShareTargetAcceptanceVM : Bindable,
		//STEP: 5
											 WinRTFramework.Interfaces.Navigation.ViewModel.ICareAboutNavigationFlow,
											 WinRTFramework.Interfaces.Contracts.Sharing.ISupportSharingTargetContract
	{
		private ShareTargetActivatedEventArgs _shareTargetArgs;

		private string _sharedText;
		public string SharedText
		{
			get { return _sharedText; }
			set
			{
				_sharedText = value;
				NotifyPropertyChanged( () => SharedText );
			}
		}

		//STEP: 7
		private DelegateCommand _acceptCommand;
		public DelegateCommand AcceptCommand
		{
			get { return _acceptCommand = _acceptCommand ?? new DelegateCommand( AcceptExecutedHandler, AcceptCanExecuteHandler ); }
		}
		private bool AcceptCanExecuteHandler()
		{
			return _shareTargetArgs != null;
		}
		private async void AcceptExecutedHandler()
		{
			if ( _shareTargetArgs != null
				&& _shareTargetArgs.ShareOperation.Data.Contains( StandardDataFormats.Text ) )
			{
				string title = DateTime.Now.ToString().Replace( ":", "-" ).Replace( "/", "-" ).Replace( "\\", "-" );


				StorageFile file = await Windows.Storage.ApplicationData.Current.LocalFolder.CreateFileAsync( title, CreationCollisionOption.ReplaceExisting );

				using ( IRandomAccessStream stream = await file.OpenAsync( FileAccessMode.ReadWrite ) )
				{
					Stream netStream = stream.AsStream();

					var serializer = new DataContractSerializer( typeof( DiaryPageVM.TransientState ) );
					serializer.WriteObject( netStream, graph: GetTransientState( title, SharedText ) );
				}
			}

			_shareTargetArgs.ShareOperation.ReportCompleted();
		}

		public async void OnNavigatedTo( object navigationParameter )
		{
			//STEP: 6
			_shareTargetArgs = navigationParameter as ShareTargetActivatedEventArgs;
			AcceptCommand.RaiseCanExecuteChanged();

			SharedText = await _shareTargetArgs.ShareOperation.Data.GetTextAsync();
		}

		public object GetTransientState( string title, string text )
		{
			return new DiaryPageVM.TransientState
					   {
						   Text = text,
						   FontFamily = "Arial",
						   FontSize = 20,
						   Title = title
					   };
		}

		public void OnNavigatingFrom()
		{
		}

		public void OnNavigatedFrom()
		{
		}
	}
}
