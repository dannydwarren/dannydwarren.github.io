﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using WinRTFramework.FrameworkConfiguration;
using WinRTFramework.Interfaces.Navigation;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Application template is documented at http://go.microsoft.com/fwlink/?LinkId=234227

namespace DemoApp
{
    /// <summary>
    /// Provides application-specific behavior to supplement the default Application class.
    /// </summary>
    sealed partial class App : WinRTFramework.DefaultImplementations.DefaultApplication
    {
		Dictionary<Type, Type> _view2VM = new Dictionary<Type, Type>();

        /// <summary>
        /// Initializes the singleton application object.  This is the first line of authored code
        /// executed, and as such is the logical equivalent of main() or WinMain().
        /// </summary>
        public App()
        {
            this.InitializeComponent();
			_view2VM.Add(typeof(MainPage), typeof(MainPageVM));
			_view2VM.Add(typeof(DiaryPage), typeof(DiaryPageVM));
			_view2VM.Add( typeof( SettingsUC ), typeof( SettingsVM ) );
			//STEP: 8 + Manifest
			_view2VM.Add( typeof( ShareTargetAcceptance ), typeof( ShareTargetAcceptanceVM ) );
        }

	    protected override bool NavigateToInitialPage(INavigationService navigationService)
	    {
			return navigationService.Navigate<MainPageVM>();
	    }

	    protected override IIoCAdapter IoCAdapter
	    {
			get
			{
				return new WinRTFramework.DefaultImplementations.DefaultIoCAdapter(
					_view2VM.Values);
			}
	    }

	    protected override IViewViewModelMapper ViewViewModelMapper
	    {
		    get { 
			return new WinRTFramework.DefaultImplementations
				.DefaultViewViewModelMapper(_view2VM, IoCAdapter);
			}
	    }

	    protected override bool IsSearchSupported
	    {
		    get { return true; }
	    }
    }
}
