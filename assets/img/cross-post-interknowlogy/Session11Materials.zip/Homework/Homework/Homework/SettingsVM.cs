﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinRTFramework.Common;

namespace DemoApp
{
	class SettingsVM : Bindable, WinRTFramework.Interfaces.Contracts.Settings.ViewModel.ISupportSettingsFlyout
	{
		double _selectedFontSize = 12;
		public double SelectedFontSize
		{
			get
			{
				return _selectedFontSize;
			}
			set
			{
				_selectedFontSize = value;
				NotifyPropertyChanged(() => SelectedFontSize);
			}
		}

		string _selectedFontFamily = "Arial";
		public string SelectedFontFamily
		{
			get
			{
				return _selectedFontFamily;
			}
			set
			{
				_selectedFontFamily = value;
				NotifyPropertyChanged(() => SelectedFontFamily);
			}
		}

		public double[] FontSizes
		{
			get
			{
				return new double[] { 12, 24, 32, 48, 72 };
			}

		}

		public string[] FontFamilies
		{
			get
			{
				return new string[] { "Arial", "Times New Roman", "Comic Sans MS" };
			}
		}

		public int DisplayOrder
		{
			get { return 0; }
		}

		public string Label
		{
			get { return "Our awesome Settings!"; }
		}

		public DelegateCommand ReturnToSettingsCommand
		{
			get;
			set;
		}

		public WinRTFramework.Contracts.Settings.SettingsFlyoutSize Size
		{
			get { return WinRTFramework.Contracts.Settings.SettingsFlyoutSize.Small; }
		}
	}
}
