﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using WinRTFramework.Common;
using WinRTFramework.Interfaces.Contracts.Sharing;
using Windows.ApplicationModel.Activation;
using Windows.ApplicationModel.DataTransfer;
using Windows.ApplicationModel.Search;
using Windows.Storage;
using Windows.Storage.Streams;

namespace DemoApp
{
	internal class MainPageVM : Bindable, WinRTFramework.Interfaces.Navigation.ViewModel.IRequireNavigationService,
	                            WinRTFramework.Interfaces.Navigation.ViewModel.ICareAboutNavigationFlow,
	                            //STEP: 2
	                            WinRTFramework.Interfaces.Contracts.Search.ISupportSearchActivation,
	                            WinRTFramework.Interfaces.Contracts.Search.ISupportSearchContract,
								//STEP: 4.0
								WinRTFramework.Interfaces.Contracts.Sharing.ISupportSharingSourceContract
	{
		//STEP: 0
		private Dictionary<string, string> _diaryEntriesAndContent = new Dictionary<string, string>();

		private ObservableCollection<string> _diaryEntries = new ObservableCollection<string>();
		public ObservableCollection<string> DiaryEntries
		{
			get { return _diaryEntries; }
		}

		public DelegateCommand NavigateToNewCommand
		{
			get { return new DelegateCommand(CreateNewDiaryEntry); }
		}
		private DelegateCommand _navigateToSelectedCommand;
		public DelegateCommand NavigateToSelectedCommand
		{
			get
			{
				return
					_navigateToSelectedCommand =
					_navigateToSelectedCommand ?? new DelegateCommand(NavigateToSelectedDiaryEntry, () => SelectedEntry != null);
			}
		}

		private string _selectedEntry;
		public string SelectedEntry
		{
			get { return _selectedEntry; }
			set
			{
				_selectedEntry = value;
				NotifyPropertyChanged(() => SelectedEntry);
				NavigateToSelectedCommand.RaiseCanExecuteChanged();
			}
		}

		private void CreateNewDiaryEntry()
		{
			NavigationService.Navigate<DiaryPageVM>();
		}

		private void NavigateToSelectedDiaryEntry()
		{
			NavigationService.Navigate<DiaryPageVM>(SelectedEntry);
		}

		private async void LoadDiaryEntriesFromLocalStorage()
		{
			DiaryEntries.Clear();
			foreach (var diaryEntry in await Windows.Storage.ApplicationData.Current.LocalFolder.GetFilesAsync())
			{
				if (diaryEntry.FileType == ".")
				{
					DiaryEntries.Add(diaryEntry.Name);

					//STEP: 1
					StorageFile file = await Windows.Storage.ApplicationData.Current.LocalFolder.GetFileAsync(diaryEntry.Name);
					using (IRandomAccessStream stream = await file.OpenReadAsync())
					{
						Stream netStream = stream.AsStream();

						var serializer = new DataContractSerializer(typeof (DiaryPageVM.TransientState));
						_diaryEntriesAndContent.Add(diaryEntry.Name, ((DiaryPageVM.TransientState) serializer.ReadObject(netStream)).Text);
					}
				}
			}
		}

		public WinRTFramework.Interfaces.Navigation.INavigationService
			NavigationService { get; set; }

		public void OnNavigatedFrom()
		{

		}

		//STEP: 4.1
		public async void OnNavigatedTo(object navigationParameter)
		{
			LoadDiaryEntriesFromLocalStorage();

		}
		
		public void OnNavigatingFrom()
		{

		}

		//STEP: 3.0
		public void ProcessQueryText(SearchPaneQuerySubmittedEventArgs args)
		{
			ProcessActivationQueryText(args.Language, args.QueryText);
		}

		//STEP: 3.1
		public void OnSearchPaneSuggestionsRequested(SearchPaneSuggestionsRequestedEventArgs args)
		{
			foreach (KeyValuePair<string, string> entryAndContent in _diaryEntriesAndContent)
			{
				if (entryAndContent.Value.Contains(args.QueryText))
				{
					args.Request.SearchSuggestionCollection.AppendQuerySuggestion(entryAndContent.Value);
				}
			}
		}

		//STEP: 3.2
		public void ProcessActivationQueryText(string language, string queryText)
		{
			DiaryEntries.Clear();
			foreach (KeyValuePair<string, string> entryAndContent in _diaryEntriesAndContent)
			{
				if (entryAndContent.Value.Contains(queryText))
				{
					DiaryEntries.Add(entryAndContent.Key);
				}
			}
		}

		public ISharingService SharingService { set; private get; }
		public void OnShareRequested(DataRequest dataRequest)
		{
			dataRequest.Data.Properties.Title = "Diary Sharing";
			dataRequest.Data.SetText(string.Format("{0} - {1}", SelectedEntry, _diaryEntriesAndContent[SelectedEntry]));
		}
	}
}
