namespace LionHeart.Models
{
	public enum Gender
	{
		Male,
		Female,
	}
}