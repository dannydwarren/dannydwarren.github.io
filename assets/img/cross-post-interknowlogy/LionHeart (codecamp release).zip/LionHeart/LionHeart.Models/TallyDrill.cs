﻿namespace LionHeart.Models
{
	public class TallyDrill : Drill
	{
	}
}