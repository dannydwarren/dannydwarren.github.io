﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace LionHeart.Models
{
	public class Session : Bindable
	{
		public Session()
		{
			Id = Guid.NewGuid();
		}

		private Guid _id;
		public Guid Id
		{
			[DebuggerStepThrough]
			get { return _id; }
			set
			{
				if (value != _id)
				{
					_id = value;
					OnPropertyChanged("Id");
				}
			}
		}

		private Guid _clientId;
		public Guid ClientId
		{
			[DebuggerStepThrough]
			get { return _clientId; }
			set
			{
				if (value != _clientId)
				{
					_clientId = value;
					OnPropertyChanged("ClientId");
				}
			}
		}

		private Guid _sessionNotesId;
		public Guid SessionNotesId
		{
			[DebuggerStepThrough]
			get { return _sessionNotesId; }
			set
			{
				if (value != _sessionNotesId)
				{
					_sessionNotesId = value;
					OnPropertyChanged("SessionNotesId");
				}
			}
		}

		private DateTime _dateTime;
		/// <summary>
		/// NOTE: This will probably change to a Wp7 OS calendar event.
		/// </summary>
		/// <value>The date time.</value>
		public DateTime DateTime
		{
			[DebuggerStepThrough]
			get { return _dateTime; }
			set
			{
				if (value != _dateTime)
				{
					_dateTime = value;
					OnPropertyChanged("DateTime");
				}
			}
		}

		private ObservableCollection<Employee> _attendees;
		public ObservableCollection<Employee> Attendees
		{
			[DebuggerStepThrough]
			get { return _attendees; }
			set
			{
				if (value != _attendees)
				{
					_attendees = value;
					OnPropertyChanged("Attendees");
				}
			}
		}
	}
}