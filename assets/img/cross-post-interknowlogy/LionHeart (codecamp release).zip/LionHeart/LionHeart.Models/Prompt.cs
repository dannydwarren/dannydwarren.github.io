namespace LionHeart.Models
{
	public enum Prompt
	{
		Correct,//C
		Incorrect,//I
		NoResponse,//NR
		Gestural,//GP
		Positional,//POS
		PartialPhysical,//PP
		HandOverHand,//HOH
		Verbal,//VP
	}
}