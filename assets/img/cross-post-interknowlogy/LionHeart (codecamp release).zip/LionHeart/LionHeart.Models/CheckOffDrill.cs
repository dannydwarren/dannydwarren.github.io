﻿namespace LionHeart.Models
{
	public class CheckOffDrill : Drill
	{
	}
}