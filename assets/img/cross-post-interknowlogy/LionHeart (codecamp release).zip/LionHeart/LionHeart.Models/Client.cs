﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace LionHeart.Models
{
	public class Client : Person
	{
		public Client()
		{
			Id = Guid.NewGuid();
			Location = new Location();
			Programs = new ObservableCollection<ProgramDrill>();
			Tallies = new ObservableCollection<TallyDrill>();
			CheckOffs = new ObservableCollection<CheckOffDrill>();
		}

		private int _age;
		public int Age
		{
			[DebuggerStepThrough]
			get { return _age; }
			set
			{
				if (value != _age)
				{
					_age = value;
					OnPropertyChanged("Age");
				}
			}
		}

		private Location _location;
		public Location Location
		{
			[DebuggerStepThrough]
			get { return _location; }
			set
			{
				if (value != _location)
				{
					_location = value;
					OnPropertyChanged("Location");
				}
			}
		}

		private string _extraInformation;
		public string ExtraInformation
		{
			[DebuggerStepThrough]
			get { return _extraInformation; }
			set
			{
				if (value != _extraInformation)
				{
					_extraInformation = value;
					OnPropertyChanged("ExtraInformation");
				}
			}
		}

		private ObservableCollection<ProgramDrill> _programs;
		public ObservableCollection<ProgramDrill> Programs
		{
			[DebuggerStepThrough]
			get { return _programs; }
			set
			{
				if (value != _programs)
				{
					_programs = value;
					OnPropertyChanged("Programs");
				}
			}
		}

		private ObservableCollection<TallyDrill> _tallies;
		public ObservableCollection<TallyDrill> Tallies
		{
			[DebuggerStepThrough]
			get { return _tallies; }
			set
			{
				if (value != _tallies)
				{
					_tallies = value;
					OnPropertyChanged("Tallies");
				}
			}
		}

		private ObservableCollection<CheckOffDrill> _checkOffs;
		public ObservableCollection<CheckOffDrill> CheckOffs
		{
			[DebuggerStepThrough]
			get { return _checkOffs; }
			set
			{
				if (value != _checkOffs)
				{
					_checkOffs = value;
					OnPropertyChanged("CheckOffs");
				}
			}
		}
	}
}