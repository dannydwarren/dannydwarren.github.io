﻿using System.Collections.Generic;
using System.Diagnostics;

namespace LionHeart.Models
{
	public class ProgramTrial : Trial
	{
		public ProgramTrial(ProgramDrill drill)
			: base(drill)
		{
			Responses = new List<ProgramResponse>();
		}

		public ProgramDrill ProgramDrill { get { return (ProgramDrill)Drill; } }

		private List<ProgramResponse> _responses;
		public List<ProgramResponse> Responses
		{
			[DebuggerStepThrough]
			get { return _responses; }
			set
			{
				if (value != _responses)
				{
					_responses = value;
					OnPropertyChanged("Responses");
				}
			}
		}
	}
}