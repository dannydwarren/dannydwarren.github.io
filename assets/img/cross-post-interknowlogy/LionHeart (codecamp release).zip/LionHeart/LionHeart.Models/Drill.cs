﻿using System.Diagnostics;

namespace LionHeart.Models
{
	public abstract class Drill : Bindable
	{
		private string _stimuli;
		public string Stimuli
		{
			[DebuggerStepThrough]
			get { return _stimuli; }
			set
			{
				if (value != _stimuli)
				{
					_stimuli = value;
					OnPropertyChanged("Stimuli");
				}
			}
		}

		private string _action;
		public string Action
		{
			[DebuggerStepThrough]
			get { return _action; }
			set
			{
				if (value != _action)
				{
					_action = value;
					OnPropertyChanged("Action");
				}
			}
		}

		private string _comments;
		public string Comments
		{
			[DebuggerStepThrough]
			get { return _comments; }
			set
			{
				if (value != _comments)
				{
					_comments = value;
					OnPropertyChanged("Comments");
				}
			}
		}
	}
}