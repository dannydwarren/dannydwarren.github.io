﻿namespace LionHeart.Models
{
	public class Settings : Bindable
	{
		 
	}
}