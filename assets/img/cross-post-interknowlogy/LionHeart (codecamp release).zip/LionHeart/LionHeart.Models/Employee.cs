﻿using System.Diagnostics;

namespace LionHeart.Models
{
	public class Employee : Person
	{
		private string _role;
		public string Role
		{
			[DebuggerStepThrough]
			get { return _role; }
			set
			{
				if (value != _role)
				{
					_role = value;
					OnPropertyChanged("Role");
				}
			}
		}
	}
}