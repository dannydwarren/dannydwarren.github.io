﻿using System.Diagnostics;

namespace LionHeart.Models
{
	public class ComplexName : Bindable
	{
		private string _first;
		public string First
		{
			[DebuggerStepThrough]
			get { return _first; }
			set
			{
				if (value != _first)
				{
					_first = value;
					OnPropertyChanged("First");
					OnPropertyChanged("Full");
				}
			}
		}

		private string _last;
		public string Last
		{
			[DebuggerStepThrough]
			get { return _last; }
			set
			{
				if (value != _last)
				{
					_last = value;
					OnPropertyChanged("Last");
					OnPropertyChanged("Full");
				}
			}
		}

		public string Full
		{
			get { return string.Format("{0} {1}", First, Last); }
		}
	}
}