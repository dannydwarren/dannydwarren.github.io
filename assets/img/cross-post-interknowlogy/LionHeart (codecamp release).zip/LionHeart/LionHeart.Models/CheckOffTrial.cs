﻿using System.Diagnostics;

namespace LionHeart.Models
{
	public class CheckOffTrial : Trial
	{
		public CheckOffTrial(Drill drill)
			: base(drill)
		{

		}

		private bool? _isChecked;
		public bool? IsChecked
		{
			[DebuggerStepThrough]
			get { return _isChecked; }
			set
			{
				if (value != _isChecked)
				{
					_isChecked = value;
					OnPropertyChanged("IsChecked");
				}
			}
		}
	}
}