﻿using System.Diagnostics;

namespace LionHeart.Models
{
	public abstract class Trial : Bindable
	{
		/// <summary>
		/// Required public and empty for serialization
		/// </summary>
		public Trial()
		{
			
		}

		protected Trial(Drill drill)
		{
			Drill = drill;
		}

		private Drill _drill;
		public Drill Drill
		{
			[DebuggerStepThrough]
			get { return _drill; }
			set
			{
				if (value != _drill)
				{
					_drill = value;
					OnPropertyChanged("Drill");
				}
			}
		}
	}
}