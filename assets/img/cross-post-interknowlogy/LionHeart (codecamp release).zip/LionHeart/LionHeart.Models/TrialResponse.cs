﻿using System;
using System.Diagnostics;

namespace LionHeart.Models
{
	public class TrialResponse : Bindable
	{
		public TrialResponse()
		{
			DateTime = DateTime.Now;
		}

		private DateTime _dateTime;
		public DateTime DateTime
		{
			[DebuggerStepThrough]
			get { return _dateTime; }
			private set
			{
				if (value != _dateTime)
				{
					_dateTime = value;
					OnPropertyChanged("DateTime");
				}
			}
		}
	}
}