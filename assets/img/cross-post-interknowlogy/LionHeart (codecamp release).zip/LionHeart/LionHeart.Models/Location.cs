using System.Diagnostics;

namespace LionHeart.Models
{
	public class Location : Bindable
	{
		private string _street1;
		public string Street1
		{
			[DebuggerStepThrough]
			get { return _street1; }
			set
			{
				if (value != _street1)
				{
					_street1 = value;
					OnPropertyChanged("Street1");
				}
			}
		}

		private string _street2;
		public string Street2
		{
			[DebuggerStepThrough]
			get { return _street2; }
			set
			{
				if (value != _street2)
				{
					_street2 = value;
					OnPropertyChanged("Street2");
				}
			}
		}

		private string _city;
		public string City
		{
			[DebuggerStepThrough]
			get { return _city; }
			set
			{
				if (value != _city)
				{
					_city = value;
					OnPropertyChanged("City");
				}
			}
		}

		private string _state;
		public string State
		{
			[DebuggerStepThrough]
			get { return _state; }
			set
			{
				if (value != _state)
				{
					_state = value;
					OnPropertyChanged("State");
				}
			}
		}

		private string _zipCode;
		public string ZipCode
		{
			[DebuggerStepThrough]
			get { return _zipCode; }
			set
			{
				if (value != _zipCode)
				{
					_zipCode = value;
					OnPropertyChanged("ZipCode");
				}
			}
		}
	}
}