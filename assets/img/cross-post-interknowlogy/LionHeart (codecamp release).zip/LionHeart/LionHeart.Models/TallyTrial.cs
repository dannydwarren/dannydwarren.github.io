﻿using System.Diagnostics;

namespace LionHeart.Models
{
	public class TallyTrial : Trial
	{
		public TallyTrial(Drill drill)
			: base(drill)
		{

		}

		private int _count;
		public int Count
		{
			[DebuggerStepThrough]
			get { return _count; }
			set
			{
				if (value != _count)
				{
					_count = value;
					OnPropertyChanged("Count");
				}
			}
		}
	}
}