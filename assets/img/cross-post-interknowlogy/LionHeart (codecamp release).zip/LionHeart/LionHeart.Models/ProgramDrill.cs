﻿using System.Diagnostics;

namespace LionHeart.Models
{
	public class ProgramDrill : Drill
	{
		private string _name;
		public string Name
		{
			[DebuggerStepThrough]
			get { return _name; }
			set
			{
				if (value != _name)
				{
					_name = value;
					OnPropertyChanged("Name");
				}
			}
		}
	
		private string _phase;
		public string Phase
		{
			[DebuggerStepThrough]
			get { return _phase; }
			set
			{
				if (value != _phase)
				{
					_phase = value;
					OnPropertyChanged("Phase");
				}
			}
		}
	}
}