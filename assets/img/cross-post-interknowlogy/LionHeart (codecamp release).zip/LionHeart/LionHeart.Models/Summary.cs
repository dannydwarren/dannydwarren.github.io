﻿using System.Diagnostics;

namespace LionHeart.Models
{
	public class Summary : Bindable
	{
		private string _description;
		public string Description
		{
			[DebuggerStepThrough]
			get { return _description; }
			set
			{
				if (value != _description)
				{
					_description = value;
					OnPropertyChanged("Description");
				}
			}
		}

		private string _response;
		public string Response
		{
			[DebuggerStepThrough]
			get { return _response; }
			set
			{
				if (value != _response)
				{
					_response = value;
					OnPropertyChanged("Response");
				}
			}
		}
	}
}