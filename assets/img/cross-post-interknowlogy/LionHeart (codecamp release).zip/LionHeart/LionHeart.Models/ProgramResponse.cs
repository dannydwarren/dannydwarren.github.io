﻿using System.Diagnostics;

namespace LionHeart.Models
{
	public class ProgramResponse : TrialResponse
	{
		private Prompt _prompt;
		public Prompt Prompt
		{
			[DebuggerStepThrough]
			get { return _prompt; }
			set
			{
				if (value != _prompt)
				{
					_prompt = value;
					OnPropertyChanged("Prompt");
				}
			}
		}
	}
}