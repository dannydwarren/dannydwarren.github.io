﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace LionHeart.Models
{
	public class SessionNotes : Bindable
	{
		public SessionNotes()
		{
			Id = Guid.NewGuid();
			CreationDateTime = DateTime.Now;
		}

		private Guid _id;
		public Guid Id
		{
			[DebuggerStepThrough]
			get { return _id; }
			set
			{
				if (value != _id)
				{
					_id = value;
					OnPropertyChanged("Id");
				}
			}
		}

		public DateTime CreationDateTime { get; private set; }

		private DateTime? _submissionDateTime;
		public DateTime? SubmissionDateTime
		{
			[DebuggerStepThrough]
			get { return _submissionDateTime; }
			set
			{
				if (value != _submissionDateTime)
				{
					_submissionDateTime = value;
					OnPropertyChanged("SubmissionDateTime");
				}
			}
		}

		private ObservableCollection<ProgramTrial> _programs;
		public ObservableCollection<ProgramTrial> Programs
		{
			[DebuggerStepThrough]
			get { return _programs; }
			set
			{
				if (value != _programs)
				{
					_programs = value;
					OnPropertyChanged("Programs");
				}
			}
		}

		//TODO: Implement Tallies
		//private ObservableCollection<TallyTrial> _tallies;
		//public ObservableCollection<TallyTrial> Tallies
		//{
		//    [DebuggerStepThrough]
		//    get { return _tallies; }
		//    set
		//    {
		//        if (value != _tallies)
		//        {
		//            _tallies = value;
		//            OnPropertyChanged("Tallies");
		//        }
		//    }
		//}

		private Summary _summary;
		public Summary Summary
		{
			[DebuggerStepThrough]
			get { return _summary; }
			set
			{
				if (value != _summary)
				{
					_summary = value;
					OnPropertyChanged("Summary");
				}
			}
		}

		//TODO: Implement CheckOffs
		//private ObservableCollection<CheckOffTrial> _checkOffs;
		//public ObservableCollection<CheckOffTrial> CheckOffs
		//{
		//    [DebuggerStepThrough]
		//    get { return _checkOffs; }
		//    set
		//    {
		//        if (value != _checkOffs)
		//        {
		//            _checkOffs = value;
		//            OnPropertyChanged("CheckOffs");
		//        }
		//    }
		//}
	}
}