﻿using System;
using System.Diagnostics;

namespace LionHeart.Models
{
	public class Person : Bindable
	{
		public Person()
		{
			Name = new ComplexName();
		}

		private Guid _id;
		public Guid Id
		{
			[DebuggerStepThrough]
			get { return _id; }
			set
			{
				if (value != _id)
				{
					_id = value;
					OnPropertyChanged("Id");
				}
			}
		}

		private ComplexName _name;
		public ComplexName Name
		{
			[DebuggerStepThrough]
			get { return _name; }
			set
			{
				if (value != _name)
				{
					_name = value;
					OnPropertyChanged("Name");
				}
			}
		}

		private Gender _gender;
		public Gender Gender
		{
			[DebuggerStepThrough]
			get { return _gender; }
			set
			{
				if (value != _gender)
				{
					_gender = value;
					OnPropertyChanged("Gender");
				}
			}
		}

		private string _phoneNumber;
		public string PhoneNumber
		{
			[DebuggerStepThrough]
			get { return _phoneNumber; }
			set
			{
				if (value != _phoneNumber)
				{
					_phoneNumber = value;
					OnPropertyChanged("PhoneNumber");
				}
			}
		}
	}
}