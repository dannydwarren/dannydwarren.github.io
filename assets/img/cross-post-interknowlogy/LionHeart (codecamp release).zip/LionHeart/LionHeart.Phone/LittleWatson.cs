﻿using System;
using System.IO;
using System.IO.IsolatedStorage;
using System.Windows;
using Microsoft.Phone.Tasks;

namespace LionHeart.Phone
{
	public class LittleWatson
	{
		const string FILENAME = "LittleWatson.txt";

		public static void ReportException(Exception error, string extra)
		{
			try
			{
				using (var store = IsolatedStorageFile.GetUserStoreForApplication())
				{
					SafeDeleteFile(store);
					using (TextWriter output = new StreamWriter(store.OpenFile(FILENAME, FileMode.OpenOrCreate, FileAccess.ReadWrite)))
					{
						output.WriteLine(extra);
						output.WriteLine(error.Message);
						output.WriteLine(error.StackTrace);
					}
				}
			}
			catch (Exception ex)
			{
			}
		}

		public static void CheckForPreviousException()
		{
			try
			{
				string contents = null;
				using (var store = IsolatedStorageFile.GetUserStoreForApplication())
				{
					if (store.FileExists(FILENAME))
					{
						using (TextReader reader = new StreamReader(store.OpenFile(FILENAME, FileMode.Open, FileAccess.Read, FileShare.None)))
						{
							contents = reader.ReadToEnd();
						}
						SafeDeleteFile(store);
					}
				}
				if (contents != null)
				{
					if (MessageBox.Show("A problem occurred the last time you ran this application. Would you like to send an email to report it?", "Problem Report", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
					{
						var email = new EmailComposeTask
						            	{
						            		To = "dwarren@interknowlogy.com",
						            		Subject = "Associate auto-generated problem report",
						            		Body = contents
						            	};
						SafeDeleteFile(IsolatedStorageFile.GetUserStoreForApplication());
						email.Show();
					}
				}
			}
			catch (Exception)
			{
			}
			finally
			{
				SafeDeleteFile(IsolatedStorageFile.GetUserStoreForApplication());
			}
		}

		private static void SafeDeleteFile(IsolatedStorageFile store)
		{
			try
			{
				store.DeleteFile(FILENAME);
			}
			catch (Exception ex)
			{
			}
		}
	}
}
