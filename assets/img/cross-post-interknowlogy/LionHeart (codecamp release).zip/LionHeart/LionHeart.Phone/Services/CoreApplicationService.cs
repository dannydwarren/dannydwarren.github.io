﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace LionHeart.Phone.Services
{
	public class CoreApplicationService
	{
		#region Fields

		public static readonly string IS_RUNNING_KEY = "IS_RUNNING_KEY";
		public static readonly string IS_LAUNCHING_KEY = "IS_LAUNCHING_KEY";

		private int _countToRemoveFromBackStackAfterNavigation;
		private PhoneApplicationFrame _frame;

		#endregion

		#region Construction

		private CoreApplicationService()
		{
			Mappings = new Dictionary<object, string>();
		}

		#endregion

		#region Events

		public event EventHandler Deactivated;
		public void OnDeactivated(DeactivatedEventArgs e)
		{
			var handler = Deactivated;
			if (handler != null) handler(this, e);
		}

		public event EventHandler Closing;
		public void OnClosing(ClosingEventArgs e)
		{
			var handler = Closing;
			if (handler != null) handler(this, e);
		}

		public event EventHandler<ObscuredEventArgs> Obscured;
		public void OnObscured(ObscuredEventArgs e)
		{
			var handler = Obscured;
			if (handler != null) handler(this, e);
		}

		public event EventHandler Unobscured;
		public void OnUnobscured(EventArgs e)
		{
			var handler = Unobscured;
			if (handler != null) handler(this, e);
		}

		public event EventHandler<NavigationFailedEventArgs> NavigationFailed;
		public void OnNavigationFailed(NavigationFailedEventArgs e)
		{
			var handler = NavigationFailed;
			if (handler != null) handler(this, e);

			if (!e.Handled)
			{
				LittleWatson.ReportException(e.Exception, "RootFrame_NavigationFailed");
			}
		}

		public event EventHandler<ApplicationUnhandledExceptionEventArgs> UnhandledException;
		public void OnUnhandledException(ApplicationUnhandledExceptionEventArgs e)
		{
			var handler = UnhandledException;
			if (handler != null) handler(this, e);

			if (!e.Handled)
			{
				LittleWatson.ReportException(e.ExceptionObject, "Application_UnhandledException");
			}
		}

		public event EventHandler<NavigatingCancelEventArgs> Navigating;
		private void OnNavigating(NavigatingCancelEventArgs e)
		{
			var handler = Navigating;
			if (handler != null) handler(this, e);
		}

		public event EventHandler<NavigationEventArgs> Navigated;
		private void OnNavigated(NavigationEventArgs e)
		{
			var handler = Navigated;
			if (handler != null) handler(this, e);
		}

		#endregion

		#region Properties

		private static CoreApplicationService _instance;
		public static CoreApplicationService Instance
		{
			get { return _instance ?? (_instance = new CoreApplicationService()); }
		}

		public Dictionary<object, string> Mappings { get; private set; }

		#endregion

		#region Public Methods

		public void Initialize(PhoneApplicationFrame frame, bool isLaunching)
		{
			LittleWatson.CheckForPreviousException();

			_frame = frame;
			_frame.Navigated += FrameNavigatedHandler;
			_frame.Navigating += FrameNavigatingHandler;

			StoreTombstoningValue(IS_LAUNCHING_KEY, isLaunching);
		}

		/// <summary>
		/// Navigates the specified viewKey.
		/// </summary>
		/// <param name="viewKey">The viewKey.</param>
		/// <param name="parameters">The parameters.</param>
		/// <param name="countToRemoveFromBackStackAfterNavigation">The count to remove from back stack. (ignored if clearBackStack == <c>true</c>)</param>
		/// <param name="clearBackStack">if set to <c>true</c> [clear back stack].</param>
		public void Navigate(object viewKey, Dictionary<string, string> parameters = null, int countToRemoveFromBackStackAfterNavigation = 0, bool clearBackStack = false)
		{
			string target;
			if (viewKey != null && Mappings.TryGetValue(viewKey, out target))
			{
				var queryParameters = new Dictionary<string, string> { { IS_RUNNING_KEY, true.ToString() } };
				if (parameters != null)
				{
					foreach (var key in parameters.Keys)
					{
						queryParameters.Add(key, parameters[key]);
					}
				}

				ICollection<string> parameterKeyValueStrings =
					queryParameters.Keys.Select(key => string.Format("{0}={1}", key, queryParameters[key])).ToArray();

				target += string.Format("?{0}", string.Join("&", parameterKeyValueStrings));

				if (clearBackStack)
				{
					_frame.Navigated += NavigationReadyToClearBackStackHandler;
				}
				else if (countToRemoveFromBackStackAfterNavigation > 0)
				{
					_countToRemoveFromBackStackAfterNavigation = countToRemoveFromBackStackAfterNavigation;
					_frame.Navigated += NavigationReadyToRemoveCountFromBackStack;
				}

				_frame.Navigate(new Uri(target, UriKind.RelativeOrAbsolute));
			}
			else
			{
				throw new ArgumentException(string.Format("Cannot navigate to target view. Driver={0}", viewKey));
			}
		}

		public Uri PreviousPageUri
		{
			get
			{
				var lastPage = _frame.BackStack.FirstOrDefault();
				if (lastPage == null)
				{
					return null;
				}
				return lastPage.Source;
			}
		}

		public bool GoBack(Uri targetPage = null)
		{
			bool success = true;
			try
			{
				if (targetPage == null)
				{
					if (_frame.BackStack.Any())
					{
						_frame.GoBack();
					}
					else
					{
						success = false;
					}
				}
				else
				{
					while (PreviousPageUri != null && targetPage != PreviousPageUri)
					{
						_frame.RemoveBackEntry();
					}
					if (_frame.BackStack.Any())
					{
						_frame.GoBack();
					}
					else
					{
						success = false;
					}
				}
			}
			catch (InvalidOperationException e)
			{
				success = false;
			}

			return success;
		}

		public void RemoveFromBackStack(int countToRemove)
		{
			while (countToRemove > 0)
			{
				_frame.RemoveBackEntry();
				countToRemove--;
			}
		}

		public void ClearBackStack()
		{
			var backStackCount = _frame.BackStack.Count();
			while (backStackCount > 0)
			{
				_frame.RemoveBackEntry();
				backStackCount--;
			}
		}

		public void StoreTombstoningValue(string key, object value)
		{
			PhoneApplicationService.Current.State[key] = value;
		}

		public bool TryRetrieveTombstoningValue<T>(string key, out T value, bool clearKey = true)
		{
			object tempObj;
			var exists = PhoneApplicationService.Current.State.TryGetValue(key, out tempObj) && tempObj is T;
			value = exists ? (T)tempObj : default(T);

			if (clearKey)
			{
				RemoveTombstoningValue(key);
			}

			return exists;
		}

		public void RemoveTombstoningValue(string key)
		{
			PhoneApplicationService.Current.State.Remove(key);
		}

		#endregion

		#region Private Methods

		private void FrameNavigatedHandler(object sender, NavigationEventArgs e)
		{
			OnNavigated(e);
		}

		private void FrameNavigatingHandler(object sender, NavigatingCancelEventArgs e)
		{
			OnNavigating(e);
		}

		private void NavigationReadyToClearBackStackHandler(object sender, NavigationEventArgs e)
		{
			_frame.Navigated -= NavigationReadyToClearBackStackHandler;
			ClearBackStack();
		}

		private void NavigationReadyToRemoveCountFromBackStack(object sender, NavigationEventArgs e)
		{
			_frame.Navigated -= NavigationReadyToRemoveCountFromBackStack;

			RemoveFromBackStack(_countToRemoveFromBackStackAfterNavigation);
			_countToRemoveFromBackStackAfterNavigation = 0;
		}

		#endregion
	}
}