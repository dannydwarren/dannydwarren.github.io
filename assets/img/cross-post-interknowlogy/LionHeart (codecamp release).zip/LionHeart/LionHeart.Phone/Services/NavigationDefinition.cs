﻿using System.Collections.Generic;

namespace LionHeart.Phone.Services
{
	public class NavigationDefinition
	{
		public NavigationDefinition(string name, object key, Dictionary<string, string> parameters = null)
		{
			Name = name;
			Key = key;
			Parameters = parameters;
		}

		public string Name { get; private set; }
		public object Key { get; private set; }
		public Dictionary<string, string> Parameters { get; private set; }
	}
}