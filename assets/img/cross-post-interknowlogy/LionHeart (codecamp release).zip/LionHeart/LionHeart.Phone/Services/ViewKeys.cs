﻿namespace LionHeart.Phone.Services
{
	public struct ViewKeys
	{
		public static readonly string HOME_VIEW_KEY = "HOME_VIEW_KEY";
		public static readonly string MY_VIEW_KEY = "MY_VIEW_KEY";
		public static readonly string ALL_CLIENTS_VIEW_KEY = "ALL_CLIENTS_VIEW_KEY";
		public static readonly string CLIENT_VIEW_KEY = "CLIENT_VIEW_KEY";
		public static readonly string SESSION_NOTES_VIEW_KEY = "SESSION_NOTES_VIEW_KEY";
		public static readonly string ALL_SESSIONS_VIEW_KEY = "ALL_SESSIONS_VIEW_KEY";
		public static readonly string MY_SESSIONS_VIEW_KEY = "MY_SESSIONS_VIEW_KEY";
		public static readonly string SESSION_VIEW_KEY = "SESSION_VIEW_KEY";
		public static readonly string SETTINGS_VIEW_KEY = "SETTINGS_VIEW_KEY";
	}
}