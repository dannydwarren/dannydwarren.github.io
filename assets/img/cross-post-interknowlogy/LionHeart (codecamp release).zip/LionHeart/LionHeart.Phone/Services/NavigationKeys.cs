﻿namespace LionHeart.Phone.Services
{
	public struct NavigationKeys
	{
		public static readonly string CLIENT_ID_KEY = "CLIENT_ID_KEY";
		public static readonly string SESSION_ID_KEY = "SESSION_ID_KEY";
		public static readonly string SESSION_NOTES_ID_KEY = "SESSION_NOTES_ID_KEY";
		public static readonly string PIVOT_ITEM_KEY = "PIVOT_ITEM_KEY";
	}
}
