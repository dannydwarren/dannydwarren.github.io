using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using LionHeart.Models;

namespace LionHeart.DataProviders
{
	public interface IDataProvider
	{
		void Initialize();
		void SaveChanges();
		void AddClient(Client newClient);
		void AddSessionNotes(SessionNotes newSessionNotes);
		void AddSession(Session newSession);
		Client GetClient(Guid clientId);
		Session GetSession(Guid sessionId);
		SessionNotes GetSessionNotes(Guid sessionNotesId);
		ReadOnlyObservableCollection<Client> GetClients();
		ReadOnlyObservableCollection<SessionNotes> GetSessionNotes();
		ReadOnlyObservableCollection<Session> GetSessions();
		Session GetSessionForSessionNotes(Guid sessionNotesId);
	}
}