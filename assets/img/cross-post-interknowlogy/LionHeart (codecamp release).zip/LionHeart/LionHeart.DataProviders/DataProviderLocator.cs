﻿using System.ComponentModel;

namespace LionHeart.DataProviders
{
	public class DataProviderLocator
	{
		private static IDataProvider _dataProvider;
		public static IDataProvider DataProvider
		{
			get
			{
				if (_dataProvider == null)
				{
					if (DesignerProperties.IsInDesignTool)
					{
						_dataProvider = MockDataProvider.Instance;
					}
					else
					{
						_dataProvider = PhoneDataProvider.Instance;
					}
					_dataProvider.Initialize();
					MockDataGenerator.GenerateMockData(_dataProvider);
				}
				return _dataProvider;
			}
		}
	}
}