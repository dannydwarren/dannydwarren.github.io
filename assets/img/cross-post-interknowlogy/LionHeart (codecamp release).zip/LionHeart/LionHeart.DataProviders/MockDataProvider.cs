using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using LionHeart.Models;

namespace LionHeart.DataProviders
{
	public class MockDataProvider : IDataProvider
	{
		#region Fields

		private static readonly Dictionary<string, object> MOCK_APP_SETTINGS = new Dictionary<string, object>();
		private static readonly string CLIENTS_KEY = "CLIENTS_KEY";
		private static readonly string SESSION_NOTES_KEY = "SESSION_NOTES_KEY";
		private static readonly string SESSIONS_KEY = "SESSIONS_KEY";

		private bool _isInitialized;
		private ObservableCollection<Client> _clients;
		private ObservableCollection<SessionNotes> _sessionNotes;
		private ObservableCollection<Session> _sessions;
		private ReadOnlyObservableCollection<Client> _clientsReadOnly;
		private ReadOnlyObservableCollection<SessionNotes> _sesssionNotesReadOnly;
		private ReadOnlyObservableCollection<Session> _sessionsReadOnly;

		#endregion

		#region Construction

		private MockDataProvider()
		{

		}

		#endregion

		#region Properties

		private static MockDataProvider _instance;
		public static MockDataProvider Instance
		{
			get
			{
				if (_instance == null)
					_instance = new MockDataProvider();
				return _instance;
			}
		}

		#endregion

		#region Public Methods

		public void Initialize()
		{
			if (_isInitialized)
			{
				return;
			}

			if (!RetrieveValue(CLIENTS_KEY, out _clients))
			{
				_clients = new ObservableCollection<Client>();
			}
			if (!RetrieveValue(SESSION_NOTES_KEY, out _sessionNotes))
			{
				_sessionNotes = new ObservableCollection<SessionNotes>();
			}
			if (!RetrieveValue(SESSIONS_KEY, out _sessions))
			{
				_sessions = new ObservableCollection<Session>();
			}

			SaveChanges();
			_isInitialized = true;
		}

		public void SaveChanges()
		{
			SaveValue(CLIENTS_KEY, _clients);
			SaveValue(SESSION_NOTES_KEY, _sessionNotes);
			SaveValue(SESSIONS_KEY, _sessions);

			Save();
		}

		public void AddClient(Client newClient)
		{
			if (newClient != null)
			{
				_clients.Add(newClient);
			}
		}

		public void AddSessionNotes(SessionNotes newSessionNotes)
		{
			if (newSessionNotes != null)
			{
				_sessionNotes.Add(newSessionNotes);
			}
		}

		public void AddSession(Session newSession)
		{
			if (newSession != null)
			{
				_sessions.Add(newSession);
			}
		}

		public Client GetClient(Guid clientId)
		{
			return _clients.FirstOrDefault(x => x.Id == clientId);
		}

		public Session GetSession(Guid sessionId)
		{
			return _sessions.FirstOrDefault(x => x.Id == sessionId);
		}

		public SessionNotes GetSessionNotes(Guid sessionNotesId)
		{
			return _sessionNotes.FirstOrDefault(x => x.Id == sessionNotesId);
		}

		public ReadOnlyObservableCollection<Client> GetClients()
		{
			if (_clientsReadOnly == null)
			{
				_clientsReadOnly = new ReadOnlyObservableCollection<Client>(_clients);
			}
			return _clientsReadOnly;
		}

		public ReadOnlyObservableCollection<SessionNotes> GetSessionNotes()
		{
			if (_sesssionNotesReadOnly == null)
			{
				_sesssionNotesReadOnly = new ReadOnlyObservableCollection<SessionNotes>(_sessionNotes);
			}
			return _sesssionNotesReadOnly;
		}

		public ReadOnlyObservableCollection<Session> GetSessions()
		{
			if (_sessionsReadOnly == null)
			{
				_sessionsReadOnly = new ReadOnlyObservableCollection<Session>(_sessions);
			}
			return _sessionsReadOnly;
		}

		public Session GetSessionForSessionNotes(Guid sessionNotesId)
		{
			return _sessions.First(s => s.SessionNotesId == sessionNotesId);
		}

		public IEnumerable<Session> GetSessions(Guid clientId)
		{
			return _sessions.Where(x => x.ClientId == clientId);
		}

		#endregion

		#region Private Methods

		private void SaveValue<T>(string key, T value)
		{
			MOCK_APP_SETTINGS[key] = value;
		}

		private bool RetrieveValue<T>(string key, out T value)
		{
			object tempObj;
			if (MOCK_APP_SETTINGS.TryGetValue(key, out tempObj))
			{
				value = (T)tempObj;
				return true;
			}
			value = default(T);
			return false;
		}

		private void Save()
		{
		}

		#endregion
	}
}