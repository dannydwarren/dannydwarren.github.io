﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using LionHeart.Models;

namespace LionHeart.DataProviders
{
	public class MockDataGenerator
	{
		private static readonly Random RANDOM = new Random();
		private static readonly string INTERVENTIONIST_STRING = "Interventionist";
		private static readonly string SUPERVISOR_STRING = "Supervisor";
		private static readonly string DEFAULT_PHONE_NUMBER = "(985) 655-2500";

		public static void GenerateMockData(IDataProvider dp)
		{
			Client client1 = GenerateMockClient("John", "Doe", "This client likes trains.", Gender.Male);
			Client client2 = GenerateMockClient("Sally", "June", "This client likes the ocean.", Gender.Female);
			Client client3 = GenerateMockClient("Richard", "Hampton", "This client likes history.", Gender.Male);
			Client client4 = GenerateMockClient("Mary", "Funnel", "This client likes baking.", Gender.Female);

			dp.AddClient(client1);
			dp.AddClient(client2);
			dp.AddClient(client3);
			dp.AddClient(client4);

			SessionNotes sessionNotes1 = GenerateMockSessionNotes(client1);
			SessionNotes sessionNotes2 = GenerateMockSessionNotes(client1);
			SessionNotes sessionNotes3 = GenerateMockSessionNotes(client1);
			SessionNotes sessionNotes4 = GenerateMockSessionNotes(client1);

			dp.AddSessionNotes(sessionNotes1);
			dp.AddSessionNotes(sessionNotes2);
			dp.AddSessionNotes(sessionNotes3);
			dp.AddSessionNotes(sessionNotes4);

			Session session1B = GenerateMockSession(client1, sessionNotes1);
			Session session2B = GenerateMockSession(client2, sessionNotes2);
			Session session3B = GenerateMockSession(client3, sessionNotes3);
			Session session4B = GenerateMockSession(client4, sessionNotes4);

			dp.AddSession(session1B);
			dp.AddSession(session2B);
			dp.AddSession(session3B);
			dp.AddSession(session4B);

			Session session1A = GenerateMockSession(client1);
			Session session2A = GenerateMockSession(client2);
			Session session3A = GenerateMockSession(client3);
			Session session4A = GenerateMockSession(client4);

			dp.AddSession(session1A);
			dp.AddSession(session2A);
			dp.AddSession(session3A);
			dp.AddSession(session4A);
		}

		private static Employee GenerateMockEmployee(string first, string last, string role, Gender gender)
		{
			return new Employee
					{
						Id = Guid.NewGuid(),
						Name = { First = first, Last = last },
						Role = role,
						Gender = gender,
					};
		}

		private static Session GenerateMockSession(Client client, SessionNotes sessionNotes = null)
		{
			return new Session
			{
				Id = Guid.NewGuid(),
				ClientId = client.Id,
				SessionNotesId = sessionNotes == null ? Guid.Empty : sessionNotes.Id,
				Attendees = GenerateMockEmployees(),
				DateTime = DateTime.Now,
			};
		}

		private static ObservableCollection<Employee> GenerateMockEmployees()
		{
			var employees = new[]
			                	{
			                		GenerateMockEmployee("Holly", "Warren", SUPERVISOR_STRING, Gender.Female),
			                		GenerateMockEmployee("Rachel", "Pickels", INTERVENTIONIST_STRING, Gender.Female),
			                	};
			return new ObservableCollection<Employee>(employees);
		}

		private static SessionNotes GenerateMockSessionNotes(Client client)
		{
			return new SessionNotes
					{
						Id = Guid.NewGuid(),
						Programs = GenerateMockProgramTrials(client),
						Summary = new Summary
								   {
									   Description = "General Summary",
									   Response = "The session went according to plan."
								   },
					};
		}

		private static ObservableCollection<ProgramTrial> GenerateMockProgramTrials(Client client)
		{
			var programTrials = new ObservableCollection<ProgramTrial>();
			foreach (var programDrill in client.Programs)
			{
				programTrials.Add(new ProgramTrial(programDrill)
									{
										Responses = GenerateMockProgramResponses(),
									});
			}
			return programTrials;
		}

		private static List<ProgramResponse> GenerateMockProgramResponses()
		{
			var programResponses = new List<ProgramResponse>();
			for (int i = 0; i < RANDOM.Next(0, 21); i++)
			{
				programResponses.Add(new ProgramResponse
										{
											Prompt = (Prompt)RANDOM.Next(0, 9), //TODO: allow for dynamic enum values (or handle when adding/removing enum values)
										});
			}
			return programResponses;
		}

		private static Client GenerateMockClient(string first, string last, string extraInfo, Gender gender)
		{
			return new Client
							{
								Id = Guid.NewGuid(),
								Name =
									{
										First = first,
										Last = last
									},
								Age = RANDOM.Next(2, 19),
								Gender = gender,
								PhoneNumber = DEFAULT_PHONE_NUMBER,
								ExtraInformation = extraInfo,
								Location = GenerateMockLocation(),
								Programs = GenerateMockProgramDrills(),
							};
		}

		private static ObservableCollection<ProgramDrill> GenerateMockProgramDrills()
		{
			var programs =
				new[]
					{
						new ProgramDrill
							{
								Name = "Compliance",
								Action = "Sit Down",
							},
						new ProgramDrill
							{
								Name = "Compliance",
								Action = "Stand Up",
							},
						new ProgramDrill
							{
								Name = "Compliance",
								Action = "Quiet Hands",
							},
						new ProgramDrill
							{
								Name = "Nonverbal Imitations",
								Action = "Object Manipulation",
								Phase = "1",
							},
						new ProgramDrill
							{
								Name = "Nonverbal Imitations",
								Action = "Gross Motor",
								Phase = "2",
							},
						new ProgramDrill
							{
								Name = "Pre-Academic",
								Action = "Matching",
								Phase = "1",
								Comments = "Object To Object",
							},
						new ProgramDrill
							{
								Name = "Communication",
								Action = "Making Choices",
								Stimuli = "What do you want?",
								Comments = "Between 2 objects",
							},
						new ProgramDrill
							{
								Name = "Communication",
								Action = "Yes/No",
								Phase = "1",
								Comments = "Desires",
							},
						new ProgramDrill
							{
								Name = "Engagement",
								Action = "Joint Attention",
								Phase = "1",
								Comments = "C=Over there + point or Point",
							},
						new ProgramDrill
							{
								Name = "Engagement",
								Action = "Response to Name",
							},
						new ProgramDrill
							{
								Name = "Community Safety",
								Action = "Stop",
							},
						new ProgramDrill
							{
								Name = "Community Safety",
								Action = "Wait",
								Comments = "C=30 Seconds",
							},
						new ProgramDrill
							{
								Name = "Pre-Academic",
								Action = "Receptive Labeling",
								Phase = "2",
								Comments = "Body Parts",
							},
					};

			return new ObservableCollection<ProgramDrill>(programs.Take(RANDOM.Next(programs.Length, programs.Length + 1)));
		}

		private static Location GenerateMockLocation()
		{
			var locations = new[]
			                	{
			                		new Location
			                			{
			                				Street1 = "1525 Faraday Ave.",
			                				City = "Carlsbad",
			                				State = "CA",
			                				ZipCode = "92008"
			                			},
			                		new Location
			                			{
			                				Street1 = "123 Cool Street",
			                				City = "Oceanside",
			                				State = "CA",
			                				ZipCode = "92054"
			                			},
			                	};

			return locations.Skip(RANDOM.Next(0, locations.Length)).First();
		}
	}
}