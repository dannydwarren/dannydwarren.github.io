﻿using System;
using System.Collections.Generic;

namespace LionHeart.Extensions
{
	public static class IDictionaryExtensions
	{
		public static bool TryGetEnum<T, U>(this IDictionary<T, string> dictionary, T key, out U value)
		{
			string boxedValue;
			if (dictionary.TryGetValue(key, out boxedValue))
			{
				return boxedValue.TryParse(out value);
			}

			value = default(U);
			return false;
		}
	}
}