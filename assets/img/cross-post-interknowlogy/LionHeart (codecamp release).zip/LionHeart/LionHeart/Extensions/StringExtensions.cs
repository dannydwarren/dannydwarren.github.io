﻿using System;

namespace LionHeart.Extensions
{
	public static class StringExtensions
	{
		public static bool TryParse<T>(this string enumString, out T enumValue, bool ignoreCase = false)
		{
			try
			{
				enumValue = enumString.Parse<T>();
			}
			catch (Exception)
			{
				enumValue = default(T);
				return false;
			}
			return true;
		}

		public static T Parse<T>(this string enumString, bool ignoreCase = false)
		{
			return (T)Enum.Parse(typeof(T), enumString, ignoreCase);
		}
	}
}