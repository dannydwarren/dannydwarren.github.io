﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace LionHeart.Extensions
{
	public static class IEnumerableExtensions
	{
		 public static void ForEach<T>(this IEnumerable<T> collection, Action<T> action)
		 {
		 	foreach (var item in collection)
		 	{
		 		action(item);
		 	}
		 }

		public static ObservableCollection<T> ToObservable<T>(this IEnumerable<T> collection)
		{
			return new ObservableCollection<T>(collection);
		}
	}
}