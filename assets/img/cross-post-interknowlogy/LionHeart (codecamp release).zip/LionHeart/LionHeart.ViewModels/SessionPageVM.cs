﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using LionHeart.DataProviders;
using LionHeart.Extensions;
using LionHeart.Models;
using LionHeart.Phone.Services;

namespace LionHeart.ViewModels
{
	public class SessionPageVM : PageViewModel
	{
		public SessionPageVM()
		{
			if (DesignerProperties.IsInDesignTool)
			{
				InitializeData(DataProviderLocator.DataProvider.GetSessions().First().Id);
			}
		}

		private ClientVM _client;
		public ClientVM Client
		{
			[DebuggerStepThrough]
			get { return _client; }
			set
			{
				if (value != _client)
				{
					_client = value;
					OnPropertyChanged("Client");
				}
			}
		}

		private SessionVM _session;
		public SessionVM Session
		{
			[DebuggerStepThrough]
			get { return _session; }
			set
			{
				if (value != _session)
				{
					_session = value;
					OnPropertyChanged("Session");
				}
			}
		}

		private SessionNotesVM _sessionNotes;
		public SessionNotesVM SessionNotes
		{
			[DebuggerStepThrough]
			get { return _sessionNotes; }
			set
			{
				if (value != _sessionNotes)
				{
					_sessionNotes = value;
					OnPropertyChanged("SessionNotes");
				}
			}
		}

		protected override void InitializeFromNavigation(IDictionary<string, string> parameters)
		{
			Guid sessionId;
			string sessionIdString;
			if (!parameters.TryGetValue(NavigationKeys.SESSION_ID_KEY, out sessionIdString)
				|| !Guid.TryParse(sessionIdString, out sessionId))
			{
				//TODO: session id is missing
				return;
			}

			InitializeData(sessionId);

			base.InitializeFromNavigation(parameters);
		}

		protected override void InitializeFromActivation()
		{
			Guid sessionId;
			if (!CoreApplicationService.TryRetrieveTombstoningValue(NavigationKeys.SESSION_ID_KEY, out sessionId))
			{
				//TODO: session id is missing
				return;
			}

			InitializeData(sessionId);

			base.InitializeFromActivation();
		}

		private void InitializeData(Guid sessionId)
		{
			Session = ViewModelFactory.CreateSessionVM(DataProviderLocator.DataProvider.GetSession(sessionId));
			Client = ViewModelFactory.CreateClientVM(Session.Client);
			
			if (Session.SessionNotes != null)
			{
				SessionNotes = ViewModelFactory.CreateSessionNotesVM(Session.SessionNotes);
			}
		}
	}
}