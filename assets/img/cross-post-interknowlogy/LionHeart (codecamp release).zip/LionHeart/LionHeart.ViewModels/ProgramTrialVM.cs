﻿using System;
using System.Diagnostics;
using System.Linq;
using LionHeart.Extensions;
using LionHeart.Models;

namespace LionHeart.ViewModels
{
	public class ProgramTrialVM : PageViewModel
	{
		public ProgramTrialVM()
		{
			RecordPromptCommand = new DelegateCommand<string>(RecordPromptExecutedHandler);
		}

		private ProgramTrial _trial;
		public ProgramTrial Trial
		{
			[DebuggerStepThrough]
			get { return _trial; }
			set
			{
				if (value != _trial)
				{
					_trial = value;
					OnPropertyChanged("Trial");
				}
			}
		}

		public double PercentCorrect
		{
			[DebuggerStepThrough]
			get
			{
				double percentDecimal =
					Math.Round((double)Trial.Responses.Count(r => r.Prompt == Prompt.Correct) / Trial.Responses.Count, 3);
				return (double.IsNaN(percentDecimal) ? 0 : percentDecimal) * 100;
			}
		}

		public DelegateCommand<string> RecordPromptCommand { get; private set; }
		private void RecordPromptExecutedHandler(string promptName)
		{
			Prompt prompt;
			if (promptName.TryParse(out prompt))
			{
				var response = new ProgramResponse { Prompt = prompt };
				Trial.Responses.Add(response);
				OnPropertyChanged("PercentCorrect");
			}
			else
			{
				throw new ArgumentException("Developer Error: Invalid Prompt enum value.");
			}
		}
	}
}