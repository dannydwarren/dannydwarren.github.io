﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using LionHeart.DataProviders;
using LionHeart.Extensions;
using LionHeart.Phone.Services;

namespace LionHeart.ViewModels
{
	public class SessionNotesPageVM : PageViewModel
	{
		public SessionNotesPageVM()
		{
			if (DesignerProperties.IsInDesignTool)
			{
				InitializeData(DataProviderLocator.DataProvider.GetClients().First().Id);
			}
		}

		private ClientVM _client;
		public ClientVM Client
		{
			[DebuggerStepThrough]
			get { return _client; }
			set
			{
				if (value != _client)
				{
					_client = value;
					OnPropertyChanged("Client");
				}
			}
		}

		private SessionVM _session;
		public SessionVM Session
		{
			[DebuggerStepThrough]
			get { return _session; }
			set
			{
				if (value != _session)
				{
					_session = value;
					OnPropertyChanged("Session");
				}
			}
		}

		private SessionNotesVM _sessionNotes;
		public SessionNotesVM SessionNotes
		{
			[DebuggerStepThrough]
			get { return _sessionNotes; }
			set
			{
				if (value != _sessionNotes)
				{
					_sessionNotes = value;
					OnPropertyChanged("SessionNotes");
				}
			}
		}

		private ObservableCollection<ProgramTrialVM> _programs;
		public ObservableCollection<ProgramTrialVM> Programs
		{
			[DebuggerStepThrough]
			get { return _programs; }
			set
			{
				if (value != _programs)
				{
					_programs = value;
					OnPropertyChanged("Programs");
				}
			}
		}

		//private ObservableCollection<TallyTrialVM> _tallies;
		//public ObservableCollection<TallyTrialVM> Tallies
		//{
		//    [DebuggerStepThrough]
		//    get { return _tallies; }
		//    set
		//    {
		//        if (value != _tallies)
		//        {
		//            _tallies = value;
		//            OnPropertyChanged("Tallies");
		//        }
		//    }
		//}

		//private ObservableCollection<CheckOffTrialVM> _checkOffs;
		//public ObservableCollection<CheckOffTrialVM> CheckOffs
		//{
		//    [DebuggerStepThrough]
		//    get { return _checkOffs; }
		//    set
		//    {
		//        if (value != _checkOffs)
		//        {
		//            _checkOffs = value;
		//            OnPropertyChanged("CheckOffs");
		//        }
		//    }
		//}

		protected override void InitializeFromNavigation(IDictionary<string, string> parameters)
		{
			Guid sessionNotesId;
			string sessionNotesIdString;
			if (!parameters.TryGetValue(NavigationKeys.SESSION_NOTES_ID_KEY, out sessionNotesIdString)
				|| !Guid.TryParse(sessionNotesIdString, out sessionNotesId))
			{
				//TODO: SessionNotes id is missing
				return;
			}

			InitializeData(sessionNotesId);

			base.InitializeFromNavigation(parameters);
		}

		protected override void InitializeFromActivation()
		{
			Guid sessionNotesId;
			if (!CoreApplicationService.TryRetrieveTombstoningValue(NavigationKeys.SESSION_NOTES_ID_KEY, out sessionNotesId))
			{
				//TODO: SessionNotes id is missing
				return;
			}

			InitializeData(sessionNotesId);

			base.InitializeFromActivation();
		}

		private void InitializeData(Guid sessionNotesId)
		{
			SessionNotes = ViewModelFactory.CreateSessionNotesVM(DataProviderLocator.DataProvider.GetSessionNotes(sessionNotesId));
			Session = ViewModelFactory.CreateSessionVM(DataProviderLocator.DataProvider.GetSessionForSessionNotes(sessionNotesId));
			Client = ViewModelFactory.CreateClientVM(DataProviderLocator.DataProvider.GetClient(Session.Client.Id));

			Programs = Client.Client.Programs.Select(ViewModelFactory.CreateProgramTrialVM).ToObservable();
		}
	}
}