﻿using System.Diagnostics;
using LionHeart.Models;

namespace LionHeart.ViewModels
{
	public class CheckOffTrialVM : PageViewModel
	{
		private CheckOffTrial _trial;
		public CheckOffTrial Trial
		{
			[DebuggerStepThrough]
			get { return _trial; }
			set
			{
				if (value != _trial)
				{
					_trial = value;
					OnPropertyChanged("Trial");
				}
			}
		}
	}
}