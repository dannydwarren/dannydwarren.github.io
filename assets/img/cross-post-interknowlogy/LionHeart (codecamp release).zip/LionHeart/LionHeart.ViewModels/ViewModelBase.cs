﻿namespace LionHeart.ViewModels
{
	public class ViewModelBase : Bindable
	{
		 
	}
}