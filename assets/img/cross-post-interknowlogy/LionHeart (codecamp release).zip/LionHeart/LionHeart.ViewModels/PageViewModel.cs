﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Windows.Navigation;
using LionHeart.Phone.Services;

namespace LionHeart.ViewModels
{
	public abstract class PageViewModel : ViewModelBase
	{
		#region Properties

		public CoreApplicationService CoreApplicationService
		{
			[DebuggerStepThrough]
			get { return CoreApplicationService.Instance; }
		}

		protected bool HasState { get; set; }
		protected bool IsInitialized { get; set; }
		protected bool IsSubscribed { get; set; }

		#endregion

		#region Public Methods

		/// <summary>
		/// Call this in the Page.NavigatedTo handler.
		/// </summary>
		/// <param name="parameters">The parameters.</param>
		public void Initialize(IDictionary<string, string> parameters = null)
		{
			InitilizeAlways();
			if (!IsInitialized)
			{
				bool isLaunching;
				CoreApplicationService.TryRetrieveTombstoningValue(
					CoreApplicationService.IS_LAUNCHING_KEY, out isLaunching);
				if (parameters != null &&
					(parameters.ContainsKey(CoreApplicationService.IS_RUNNING_KEY) || isLaunching))
				{
					InitializeFromNavigation(parameters);
				}
				else if (!HasState)
				{
					InitializeFromActivation();
				}
				HasState = true;
				IsInitialized = true;
			}
		}

		/// <summary>
		/// Call this in the Page.NavigatedFrom handler.
		/// </summary>
		public void Uninitialize(bool isTearDown = false)
		{
			if (IsInitialized || isTearDown)
			{
				UninitializeAlways();
				if (isTearDown)
				{
					UninitializeTearDown();
				}
				IsInitialized = false;
			}
		}

		#endregion

		#region Private Methods

		protected virtual void InitilizeAlways()
		{
			SubscribeGlobalHandlers();
		}

		protected virtual void InitializeFromNavigation(IDictionary<string, string> parameters)
		{
		}

		protected virtual void InitializeFromActivation()
		{
		}

		protected virtual void UninitializeAlways()
		{

		}

		protected virtual void UninitializeTearDown()
		{
			UnsubscribeGlobalHandlers();
		}

		protected virtual void SubscribeGlobalHandlers()
		{
			if (!IsSubscribed)
			{
				CoreApplicationService.Deactivated += DeactivatedHandler;
				CoreApplicationService.Closing += ClosingHandler;
				CoreApplicationService.NavigationFailed += NavigationFailedHandler;
				CoreApplicationService.UnhandledException += UnhandledExceptionHandler;
				IsSubscribed = true;
			}

		}

		protected virtual void UnsubscribeGlobalHandlers()
		{
			if (IsSubscribed)
			{
				CoreApplicationService.Deactivated -= DeactivatedHandler;
				CoreApplicationService.Closing -= ClosingHandler;
				CoreApplicationService.NavigationFailed -= NavigationFailedHandler;
				CoreApplicationService.UnhandledException -= UnhandledExceptionHandler;
				IsSubscribed = false;
			}
		}

		protected virtual void Deactivate()
		{
		}

		protected virtual void Close()
		{
		}

		protected virtual void NavigationFailed(NavigationFailedEventArgs args)
		{
		}

		protected virtual void UnhandledException(ApplicationUnhandledExceptionEventArgs args)
		{
		}

		private void DeactivatedHandler(object sender, EventArgs e)
		{
			Deactivate();
		}

		private void ClosingHandler(object sender, EventArgs e)
		{
			Close();
		}

		private void NavigationFailedHandler(object sender, NavigationFailedEventArgs e)
		{
			if (!e.Handled)
			{
				NavigationFailed(e);
			}
		}

		private void UnhandledExceptionHandler(object sender, ApplicationUnhandledExceptionEventArgs e)
		{
			if (!e.Handled)
			{
				UnhandledException(e);
			}
		}

		#endregion
	}
}
