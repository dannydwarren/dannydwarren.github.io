﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using LionHeart.Phone;
using LionHeart.Phone.Services;

namespace LionHeart.ViewModels
{
	public class HomeVM : PageViewModel
	{
		private static readonly string MY_SESSIONS_MENU_ITEM_NAME = "my sessions";
		private static readonly string MY_CLIENTS_MENU_ITEM_NAME = "my clients";
		private static readonly string MY_SESSIONS_NOTES_MENU_ITEM_NAME = "my notes";
		private static readonly string CREATE_SESSION_NOTES_MENU_ITEM_NAME = "new notes";
		private static readonly string SETTINGS_MENU_ITEM_NAME = "settings";

		public HomeVM()
		{
			if (DesignerProperties.IsInDesignTool)
			{
				InitializeMenu();
			}
		}

		private List<NavigationDefinition> _navigationOptions;
		public List<NavigationDefinition> NavigationOptions
		{
			[DebuggerStepThrough]
			get { return _navigationOptions; }
			set
			{
				if (value != _navigationOptions)
				{
					_navigationOptions = value;
					OnPropertyChanged("NavigationOptions");
				}
			}
		}

		private NavigationDefinition _navigationTarget;
		public NavigationDefinition NavigationTarget
		{
			[DebuggerStepThrough]
			get { return _navigationTarget; }
			set
			{
				if (value != _navigationTarget)
				{
					_navigationTarget = value;
					OnPropertyChanged("NavigationTarget");
					Navigate(_navigationTarget);
				}
			}
		}

		protected override void InitializeFromNavigation(IDictionary<string, string> parameters)
		{
			InitializeMenu();
			base.InitializeFromNavigation(parameters);
		}

		protected override void InitializeFromActivation()
		{
			InitializeMenu();
			base.InitializeFromActivation();
		}

		protected override void UninitializeTearDown()
		{
			NavigationOptions = null;
			base.UninitializeTearDown();
		}

		private void InitializeMenu()
		{
			if (NavigationOptions == null)
			{
				NavigationOptions = new List<NavigationDefinition>(new[]
				                                               	{
				                                               		new NavigationDefinition(MY_SESSIONS_MENU_ITEM_NAME,
				                                               		                     ViewKeys.MY_VIEW_KEY,
																						 new Dictionary<string,string>{{NavigationKeys.PIVOT_ITEM_KEY, MyPivotItem.Sessions.ToString()}}),
				                                               		new NavigationDefinition(MY_CLIENTS_MENU_ITEM_NAME,
				                                               		                     ViewKeys.MY_VIEW_KEY,
																						 new Dictionary<string,string>{{NavigationKeys.PIVOT_ITEM_KEY, MyPivotItem.Clients.ToString()}}),
				                                               		new NavigationDefinition(MY_SESSIONS_NOTES_MENU_ITEM_NAME,
				                                               		                     ViewKeys.MY_VIEW_KEY,
																						 new Dictionary<string,string>{{NavigationKeys.PIVOT_ITEM_KEY, MyPivotItem.SessionNotes.ToString()}}),
				                                               		new NavigationDefinition(CREATE_SESSION_NOTES_MENU_ITEM_NAME,
				                                               		                     ViewKeys.SESSION_NOTES_VIEW_KEY),
				                                               		new NavigationDefinition(SETTINGS_MENU_ITEM_NAME,
				                                               		                     ViewKeys.SETTINGS_VIEW_KEY),
				                                               	});
			}
		}

		private void Navigate(NavigationDefinition definition)
		{
			if (definition != null)
			{
				NavigationTarget = null; // reset selection
				CoreApplicationService.Navigate(definition.Key, definition.Parameters);
			}
		}
	}
}