using System.Diagnostics;
using LionHeart.DataProviders;
using LionHeart.Models;

namespace LionHeart.ViewModels
{
	public class SessionNotesVM : ViewModelBase
	{
		public SessionNotesVM(SessionNotes sessionNotes)
		{
			SessionNotes = sessionNotes;
			Session = DataProviderLocator.DataProvider.GetSessionForSessionNotes(sessionNotes.Id);
			Client = DataProviderLocator.DataProvider.GetClient(Session.ClientId);
		}

		private Client _client;
		public Client Client
		{
			[DebuggerStepThrough]
			get { return _client; }
			set
			{
				if (value != _client)
				{
					_client = value;
					OnPropertyChanged("Client");
				}
			}
		}

		private Session _session;
		public Session Session
		{
			[DebuggerStepThrough]
			get { return _session; }
			set
			{
				if (value != _session)
				{
					_session = value;
					OnPropertyChanged("Session");
				}
			}
		}

		private SessionNotes _sessionNotes;
		public SessionNotes SessionNotes
		{
			[DebuggerStepThrough]
			get { return _sessionNotes; }
			set
			{
				if (value != _sessionNotes)
				{
					_sessionNotes = value;
					OnPropertyChanged("SessionNotes");
				}
			}
		}
	}
}