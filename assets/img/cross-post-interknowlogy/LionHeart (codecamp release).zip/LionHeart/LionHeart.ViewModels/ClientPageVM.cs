﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using LionHeart.DataProviders;
using LionHeart.Extensions;
using LionHeart.Models;
using LionHeart.Phone.Services;

namespace LionHeart.ViewModels
{
	public class ClientPageVM : PageViewModel
	{
		private ReadOnlyObservableCollection<Session> _sessionModels;
		private ReadOnlyObservableCollection<SessionNotes> _sessionNotesModels;

		public ClientPageVM()
		{
			if (DesignerProperties.IsInDesignTool)
			{
				InitializeData(DataProviderLocator.DataProvider.GetClients().First().Id);
			}
		}

		private ClientVM _client;
		public ClientVM Client
		{
			[DebuggerStepThrough]
			get { return _client; }
			set
			{
				if (value != _client)
				{
					_client = value;
					OnPropertyChanged("Client");
				}
			}
		}

		private ObservableCollection<SessionVM> _sessions;
		public ObservableCollection<SessionVM> Sessions
		{
			[DebuggerStepThrough]
			get { return _sessions; }
			set
			{
				if (value != _sessions)
				{
					_sessions = value;
					OnPropertyChanged("Sessions");
				}
			}
		}

		private ObservableCollection<SessionNotesVM> _sessionsNotes;
		public ObservableCollection<SessionNotesVM> SessionsNotes
		{
			[DebuggerStepThrough]
			get { return _sessionsNotes; }
			set
			{
				if (value != _sessionsNotes)
				{
					_sessionsNotes = value;
					OnPropertyChanged("SessionsNotes");
				}
			}
		}

		private IEnumerable<IGrouping<ProgramDrill, ProgramTrial>> _programs;
		public IEnumerable<IGrouping<ProgramDrill, ProgramTrial>> Programs
		{
			[DebuggerStepThrough]
			get { return _programs; }
			set
			{
				if (value != _programs)
				{
					_programs = value;
					OnPropertyChanged("Programs");
				}
			}
		}

		private IEnumerable<TallyTrial> _tallies;
		public IEnumerable<TallyTrial> Tallies
		{
			[DebuggerStepThrough]
			get { return _tallies; }
			set
			{
				if (value != _tallies)
				{
					_tallies = value;
					OnPropertyChanged("Tallies");
				}
			}
		}

		private IEnumerable<CheckOffTrial> _checkOffs;
		public IEnumerable<CheckOffTrial> CheckOffs
		{
			[DebuggerStepThrough]
			get { return _checkOffs; }
			set
			{
				if (value != _checkOffs)
				{
					_checkOffs = value;
					OnPropertyChanged("CheckOffs");
				}
			}
		}

		private IEnumerable<Summary> _summaries;
		public IEnumerable<Summary> Summaries
		{
			[DebuggerStepThrough]
			get { return _summaries; }
			set
			{
				if (value != _summaries)
				{
					_summaries = value;
					OnPropertyChanged("Summaries");
				}
			}
		}

		protected override void InitializeFromNavigation(IDictionary<string, string> parameters)
		{
			Guid clientId;
			string clientIdString;
			if (!parameters.TryGetValue(NavigationKeys.CLIENT_ID_KEY, out clientIdString)
				|| !Guid.TryParse(clientIdString, out clientId))
			{
				//TODO: client id is missing
				return;
			}

			InitializeData(clientId);

			base.InitializeFromNavigation(parameters);
		}

		protected override void InitializeFromActivation()
		{
			Guid clientId;
			if (!CoreApplicationService.TryRetrieveTombstoningValue(NavigationKeys.CLIENT_ID_KEY, out clientId))
			{
				//TODO: client id is missing
				return;
			}

			InitializeData(clientId);

			base.InitializeFromActivation();
		}

		protected override void Deactivate()
		{
			CoreApplicationService.StoreTombstoningValue(NavigationKeys.CLIENT_ID_KEY, Client.Client.Id);
			base.Deactivate();
		}

		private void InitializeData(Guid clientId)
		{
			Client = ViewModelFactory.CreateClientVM(DataProviderLocator.DataProvider.GetClient(clientId));

			_sessionModels = DataProviderLocator.DataProvider.GetSessions();
			Sessions = new ObservableCollection<SessionVM>(_sessionModels.Where(s => s.ClientId == clientId).Select(ViewModelFactory.CreateSessionVM));
			((INotifyCollectionChanged)_sessionModels).CollectionChanged += SessionsCollectionChanged;

			_sessionNotesModels = DataProviderLocator.DataProvider.GetSessionNotes();
			
			//TODO: Refactor into the DP
			ICollection<SessionNotesVM> sessionsNotesForSelectedClient =
				_sessionNotesModels.Where(r => Sessions.Where(s => s.SessionNotes != null).Any(s => s.SessionNotes.Id == r.Id)).
					Select(ViewModelFactory.CreateSessionNotesVM).ToArray();

			SessionsNotes = new ObservableCollection<SessionNotesVM>(sessionsNotesForSelectedClient);
			((INotifyCollectionChanged)_sessionNotesModels).CollectionChanged += SessionsNotesCollectionChanged;

			//TODO: Should Programs, Tallies, CheckOffs, and Summaries be VMs?
			Programs = SessionsNotes.SelectMany(sessionNotesVM => sessionNotesVM.SessionNotes.Programs).GroupBy(p => p.ProgramDrill);
			//Tallies = SessionsNotes.SelectMany(x => x.SessionNotes.Tallies);
			//CheckOffs = SessionsNotes.SelectMany(x => x.SessionNotes.CheckOffs);
			Summaries = SessionsNotes.Select(x => x.SessionNotes.Summary); // TODO: Do we want to inlcude the date for summaries? Or any other list for that matter?
		}

		protected override void UninitializeTearDown()
		{
			((INotifyCollectionChanged)_sessionModels).CollectionChanged -= SessionsCollectionChanged;
			((INotifyCollectionChanged)_sessionNotesModels).CollectionChanged -= SessionsNotesCollectionChanged;

			base.UninitializeTearDown();
		}

		private void SessionsCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
		{
			var newSessions = e.NewItems.OfType<Session>().Where(s => s.ClientId == Client.Client.Id);
			var oldSessions = e.OldItems.OfType<Session>().Where(s => s.ClientId == Client.Client.Id);

			switch (e.Action)
			{
				case NotifyCollectionChangedAction.Add:
					newSessions.Select(ViewModelFactory.CreateSessionVM).ForEach(Sessions.Add);
					break;
				case NotifyCollectionChangedAction.Remove:
					oldSessions.Select(ViewModelFactory.CreateSessionVM).ForEach(vm => Sessions.Remove(vm));
					break;
				case NotifyCollectionChangedAction.Replace:
					oldSessions.Select(ViewModelFactory.CreateSessionVM).ForEach(vm => Sessions.Remove(vm));
					newSessions.Select(ViewModelFactory.CreateSessionVM).ForEach(Sessions.Add);
					break;
				case NotifyCollectionChangedAction.Reset:
					Sessions.Clear();
					break;
			}
		}

		private void SessionsNotesCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
		{
			var newSessionsNotes = e.NewItems.OfType<SessionNotes>().Where(r => Sessions.Any(s => s.SessionNotes.Id == r.Id));
			var oldSessionsNotes = e.OldItems.OfType<SessionNotes>().Where(r => Sessions.Any(s => s.SessionNotes.Id == r.Id));

			switch (e.Action)
			{
				case NotifyCollectionChangedAction.Add:
					newSessionsNotes.Select(ViewModelFactory.CreateSessionNotesVM).ForEach(SessionsNotes.Add);
					break;
				case NotifyCollectionChangedAction.Remove:
					oldSessionsNotes.Select(ViewModelFactory.CreateSessionNotesVM).ForEach(vm => SessionsNotes.Remove(vm));
					break;
				case NotifyCollectionChangedAction.Replace:
					oldSessionsNotes.Select(ViewModelFactory.CreateSessionNotesVM).ForEach(vm => SessionsNotes.Remove(vm));
					newSessionsNotes.Select(ViewModelFactory.CreateSessionNotesVM).ForEach(SessionsNotes.Add);
					break;
				case NotifyCollectionChangedAction.Reset:
					SessionsNotes.Clear();
					break;
			}
		}
	}
}