﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using LionHeart.DataProviders;
using LionHeart.Extensions;
using LionHeart.Models;
using LionHeart.Phone.Services;

namespace LionHeart.ViewModels
{
	public class MyVM : PageViewModel
	{
		private ReadOnlyObservableCollection<Client> _clientModels;
		private ReadOnlyObservableCollection<Session> _sessionModels;
		private ReadOnlyObservableCollection<SessionNotes> _sessionsNotesModels;
		
		public MyVM()
		{
			if (DesignerProperties.IsInDesignTool)
			{
				InitializeData();
			}
		}

		private ObservableCollection<ClientVM> _clients;
		public ObservableCollection<ClientVM> Clients
		{
			[DebuggerStepThrough]
			get { return _clients; }
			set
			{
				if (value != _clients)
				{
					_clients = value;
					OnPropertyChanged("Clients");
				}
			}
		}

		private ObservableCollection<SessionVM> _sessions;
		public ObservableCollection<SessionVM> Sessions
		{
			[DebuggerStepThrough]
			get { return _sessions; }
			set
			{
				if (value != _sessions)
				{
					_sessions = value;
					OnPropertyChanged("Sessions");
				}
			}
		}

		private ObservableCollection<SessionNotesVM> _sessionsNotes;
		public ObservableCollection<SessionNotesVM> SessionsNotes
		{
			[DebuggerStepThrough]
			get { return _sessionsNotes; }
			set
			{
				if (value != _sessionsNotes)
				{
					_sessionsNotes = value;
					OnPropertyChanged("SessionsNotes");
				}
			}
		}

		private ClientVM _selectedClient;
		public ClientVM SelectedClient
		{
			[DebuggerStepThrough]
			get { return _selectedClient; }
			set
			{
				if (value != _selectedClient)
				{
					_selectedClient = value;
					OnPropertyChanged("SelectedClient");
					Navigate(_selectedClient);
				}
			}
		}

		private SessionVM _selectedSession;
		public SessionVM SelectedSession
		{
			[DebuggerStepThrough]
			get { return _selectedSession; }
			set
			{
				if (value != _selectedSession)
				{
					_selectedSession = value;
					OnPropertyChanged("SelectedSession");
					Navigate(_selectedSession);
				}
			}
		}

		private SessionNotesVM _selectedSessionNotes;
		public SessionNotesVM SelectedSessionNotes
		{
			[DebuggerStepThrough]
			get { return _selectedSessionNotes; }
			set
			{
				if (value != _selectedSessionNotes)
				{
					_selectedSessionNotes = value;
					OnPropertyChanged("SelectedSessionNotes");
					Navigate(_selectedSessionNotes);
				}
			}
		}

		private MyPivotItem _selectedPivotItem;
		public MyPivotItem SelectedPivotItem
		{
			[DebuggerStepThrough]
			get { return _selectedPivotItem; }
			set
			{
				if (value != _selectedPivotItem)
				{
					_selectedPivotItem = value;
					OnPropertyChanged("SelectedPivotItem");
				}
			}
		}
		
		protected override void InitializeFromNavigation(IDictionary<string, string> parameters)
		{
			MyPivotItem selectedPivotItem;
			parameters.TryGetEnum(NavigationKeys.PIVOT_ITEM_KEY, out selectedPivotItem);
			SelectedPivotItem = selectedPivotItem;

			InitializeData();

			base.InitializeFromNavigation(parameters);
		}

		protected override void InitializeFromActivation()
		{
			MyPivotItem selectedPivotItem;
			CoreApplicationService.TryRetrieveTombstoningValue(NavigationKeys.PIVOT_ITEM_KEY, out selectedPivotItem);
			SelectedPivotItem = selectedPivotItem;
			
			InitializeData();

			base.InitializeFromActivation();
		}

		protected override void Deactivate()
		{
			CoreApplicationService.StoreTombstoningValue(NavigationKeys.PIVOT_ITEM_KEY, SelectedPivotItem);
			
			base.Deactivate();
		}
		
		protected override void UninitializeTearDown()
		{
			((INotifyCollectionChanged)_clientModels).CollectionChanged -= ClientsCollectionChanged;
			((INotifyCollectionChanged)_sessionModels).CollectionChanged -= SessionsCollectionChanged;
			((INotifyCollectionChanged)_sessionsNotesModels).CollectionChanged -= SessionsNotesCollectionChanged;

			base.UninitializeTearDown();
		}

		private void InitializeData()
		{
			_clientModels = DataProviderLocator.DataProvider.GetClients();
			Clients = new ObservableCollection<ClientVM>(_clientModels.Select(ViewModelFactory.CreateClientVM));
			((INotifyCollectionChanged)_clientModels).CollectionChanged += ClientsCollectionChanged;

			_sessionModels = DataProviderLocator.DataProvider.GetSessions();
			Sessions = new ObservableCollection<SessionVM>(_sessionModels.Select(ViewModelFactory.CreateSessionVM));
			((INotifyCollectionChanged)_sessionModels).CollectionChanged += SessionsCollectionChanged;

			_sessionsNotesModels = DataProviderLocator.DataProvider.GetSessionNotes();
			SessionsNotes = new ObservableCollection<SessionNotesVM>(_sessionsNotesModels.Select(ViewModelFactory.CreateSessionNotesVM));
			((INotifyCollectionChanged)_sessionsNotesModels).CollectionChanged += SessionsNotesCollectionChanged;
		}

		private void ClientsCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
		{
			var newClients = e.NewItems.OfType<Client>();
			var oldClient = e.OldItems.OfType<Client>();

			switch (e.Action)
			{
				case NotifyCollectionChangedAction.Add:
					newClients.Select(ViewModelFactory.CreateClientVM).ForEach(Clients.Add);
					break;
				case NotifyCollectionChangedAction.Remove:
					oldClient.Select(ViewModelFactory.CreateClientVM).ForEach(vm => Clients.Remove(vm));
					break;
				case NotifyCollectionChangedAction.Replace:
					oldClient.Select(ViewModelFactory.CreateClientVM).ForEach(vm => Clients.Remove(vm));
					newClients.Select(ViewModelFactory.CreateClientVM).ForEach(Clients.Add);
					break;
				case NotifyCollectionChangedAction.Reset:
					Clients.Clear();
					break;
			}
		}

		private void SessionsCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
		{
			var newSessions = e.NewItems.OfType<Session>();
			var oldSessions = e.OldItems.OfType<Session>();

			switch (e.Action)
			{
				case NotifyCollectionChangedAction.Add:
					newSessions.Select(ViewModelFactory.CreateSessionVM).ForEach(Sessions.Add);
					break;
				case NotifyCollectionChangedAction.Remove:
					oldSessions.Select(ViewModelFactory.CreateSessionVM).ForEach(vm => Sessions.Remove(vm));
					break;
				case NotifyCollectionChangedAction.Replace:
					oldSessions.Select(ViewModelFactory.CreateSessionVM).ForEach(vm => Sessions.Remove(vm));
					newSessions.Select(ViewModelFactory.CreateSessionVM).ForEach(Sessions.Add);
					break;
				case NotifyCollectionChangedAction.Reset:
					Sessions.Clear();
					break;
			}
		}

		private void SessionsNotesCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
		{
			var newSessionsNotes = e.NewItems.OfType<SessionNotes>();
			var oldSessionsNotes = e.OldItems.OfType<SessionNotes>();

			switch (e.Action)
			{
				case NotifyCollectionChangedAction.Add:
					newSessionsNotes.Select(ViewModelFactory.CreateSessionNotesVM).ForEach(SessionsNotes.Add);
					break;
				case NotifyCollectionChangedAction.Remove:
					oldSessionsNotes.Select(ViewModelFactory.CreateSessionNotesVM).ForEach(vm => SessionsNotes.Remove(vm));
					break;
				case NotifyCollectionChangedAction.Replace:
					oldSessionsNotes.Select(ViewModelFactory.CreateSessionNotesVM).ForEach(vm => SessionsNotes.Remove(vm));
					newSessionsNotes.Select(ViewModelFactory.CreateSessionNotesVM).ForEach(SessionsNotes.Add);
					break;
				case NotifyCollectionChangedAction.Reset:
					SessionsNotes.Clear();
					break;
			}
		}

		private void Navigate(ClientVM clientVM)
		{
			if (clientVM != null)
			{
				SelectedClient = null;
				CoreApplicationService.Navigate(ViewKeys.CLIENT_VIEW_KEY,
												new Dictionary<string, string> { { NavigationKeys.CLIENT_ID_KEY, clientVM.Client.Id.ToString() } });
			}
		}

		private void Navigate(SessionVM sessionVM)
		{
			if (sessionVM != null)
			{
				SelectedSession = null;
				CoreApplicationService.Navigate(ViewKeys.SESSION_VIEW_KEY,
												new Dictionary<string, string> { { NavigationKeys.SESSION_ID_KEY, sessionVM.Session.Id.ToString() } });
			}
		}

		private void Navigate(SessionNotesVM sessionNotesVM)
		{
			if (sessionNotesVM != null)
			{
				SelectedSessionNotes = null;
				CoreApplicationService.Navigate(ViewKeys.SESSION_NOTES_VIEW_KEY,
												new Dictionary<string, string> { { NavigationKeys.SESSION_NOTES_ID_KEY, sessionNotesVM.SessionNotes.Id.ToString() } });
			}
		}
	}
}