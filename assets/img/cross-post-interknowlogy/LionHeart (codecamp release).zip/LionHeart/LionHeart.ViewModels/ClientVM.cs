using System;
using System.Diagnostics;
using LionHeart.Models;

namespace LionHeart.ViewModels
{
	public class ClientVM : ViewModelBase
	{
		public ClientVM(Client client)
		{
			Client = client;
		}

		private Client _client;
		public Client Client
		{
			[DebuggerStepThrough]
			get { return _client; }
			set
			{
				if (value != _client)
				{
					_client = value;
					OnPropertyChanged("Client");
				}
			}
		}

		public string FormatedLocation
		{
			get
			{
				if (string.IsNullOrEmpty(Client.Location.Street2))
				{
					return string.Format("{1}{0}{2}, {3} {4}",
						Environment.NewLine,
						Client.Location.Street1,
						Client.Location.City,
						Client.Location.State,
						Client.Location.ZipCode);
				}
				return string.Format("{1}{0}{2}{0}{3}, {4} {5}", 
					Environment.NewLine,
					Client.Location.Street1,
					Client.Location.Street2,
					Client.Location.City, 
					Client.Location.State,
					Client.Location.ZipCode);
			}
		}
	}
}