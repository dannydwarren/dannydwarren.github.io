﻿namespace LionHeart.ViewModels
{
	//WARNING: The value of each item is tightly coupled to the order of Pivot Items in MyView. Do not change!
	public enum MyPivotItem
	{
		Sessions = 0,
		Clients,
		SessionNotes
	}
}