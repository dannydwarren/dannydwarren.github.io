﻿using LionHeart.Models;

namespace LionHeart.ViewModels
{
	public class ViewModelFactory
	{
		public static SessionVM CreateSessionVM(Session session)
		{
			return new SessionVM(session);
		}

		public static ClientVM CreateClientVM(Client client)
		{
			return new ClientVM(client);
		}

		public static SessionNotesVM CreateSessionNotesVM(SessionNotes sessionNotes)
		{
			return new SessionNotesVM(sessionNotes);
		}

		public static ProgramTrialVM CreateProgramTrialVM(ProgramDrill programDrill)
		{
			return new ProgramTrialVM
					{
						Trial = new ProgramTrial(programDrill),
					};
		}
	}
}