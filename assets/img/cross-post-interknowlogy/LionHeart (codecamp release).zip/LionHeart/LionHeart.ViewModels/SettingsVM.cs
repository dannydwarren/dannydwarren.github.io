﻿namespace LionHeart.ViewModels
{
	public class SettingsVM : PageViewModel
	{
		 
	}
}