﻿using System.Diagnostics;
using LionHeart.Models;

namespace LionHeart.ViewModels
{
	public class TallyTrialVM : PageViewModel
	{
		private TallyTrial _trial;
		public TallyTrial Trial
		{
			[DebuggerStepThrough]
			get { return _trial; }
			set
			{
				if (value != _trial)
				{
					_trial = value;
					OnPropertyChanged("Trial");
				}
			}
		}
	}
}