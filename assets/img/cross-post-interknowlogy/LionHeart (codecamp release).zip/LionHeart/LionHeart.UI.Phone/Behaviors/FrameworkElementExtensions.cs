﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Data;

namespace ConventionExplorerWindows8.Extensions
{
    public static class FrameworkElementExtensions
    {
        #region Public Methods
        public static void RegisterDataContextChanged(this FrameworkElement element, Action<DependencyPropertyChangedEventArgs> changedCallback)
        {
            RegisterDependencyPropertyBinding(element, "DataContext", FrameworkElementAttachedProperties.DataContextExProperty, changedCallback);
        }
        public static void UnregisterDataContextChanged(this FrameworkElement element)
        {
            UnregisterDependencyPropertyBinding(element, FrameworkElementAttachedProperties.DataContextExProperty);
        }

        public static void RegisterVisibilityChanged(this FrameworkElement element, Action<DependencyPropertyChangedEventArgs> changedCallback)
        {
            RegisterDependencyPropertyBinding(element, "Visibility", FrameworkElementAttachedProperties.VisibilityExProperty, changedCallback);
        }
        public static void UnregisterVisibilityChanged(this FrameworkElement element)
        {
            UnregisterDependencyPropertyBinding(element, FrameworkElementAttachedProperties.VisibilityExProperty);
        }
        #endregion

        #region Private Methods
        private static void RegisterDependencyPropertyBinding(FrameworkElement element, string sourceDpPath, DependencyProperty attachedDp, Action<DependencyPropertyChangedEventArgs> changedCallback)
        {
            FrameworkElementAttachedProperties.RegisterDependencyPropertyCallback(element, attachedDp, changedCallback);

            var dependencyPropertyExtensionBinding = new Binding
            {
                Path = new PropertyPath(sourceDpPath),
                RelativeSource = new RelativeSource
                {
                    Mode = RelativeSourceMode.Self
                },
            };
            element.SetBinding(attachedDp, dependencyPropertyExtensionBinding);
        }

        private static void UnregisterDependencyPropertyBinding(FrameworkElement element, DependencyProperty attachedDp)
        {
            FrameworkElementAttachedProperties.UnregisterDependencyPropertyCallback(element, attachedDp);
            element.SetValue(attachedDp, DependencyProperty.UnsetValue);
        }
        #endregion
    }

    public class FrameworkElementAttachedProperties : DependencyObject
    {
        #region Fields
        private static Dictionary<KeyValuePair<FrameworkElement, DependencyProperty>, Action<DependencyPropertyChangedEventArgs>> _registeredChangeCallbacks =
                       new Dictionary<KeyValuePair<FrameworkElement, DependencyProperty>, Action<DependencyPropertyChangedEventArgs>>();
        #endregion

        #region Properties
        #region DataContextEx (Attached Property)
        public static readonly DependencyProperty DataContextExProperty =
          DependencyProperty.RegisterAttached("DataContextEx", typeof(object), typeof(FrameworkElementAttachedProperties),
                                              new PropertyMetadata(null, DataContextExPropertyChanged));

        public static void SetDataContextEx(DependencyObject d, object value)
        {
            d.SetValue(DataContextExProperty, value);
        }

        public static object GetDataContextEx(DependencyObject d)
        {
            return (object)d.GetValue(DataContextExProperty);
        }

        private static void DataContextExPropertyChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            TryFireChangeCallback((FrameworkElement)sender, e.Property, e);
        }
        #endregion

        #region VisibilityEx (Attached Property)
        public static readonly DependencyProperty VisibilityExProperty =
          DependencyProperty.RegisterAttached("VisibilityEx", typeof(Visibility), typeof(FrameworkElementAttachedProperties),
                                              new PropertyMetadata(Visibility.Visible, VisibilityExPropertyChanged));

        public static void SetVisibilityEx(DependencyObject d, Visibility value)
        {
            d.SetValue(VisibilityExProperty, value);
        }

        public static Visibility GetVisibilityEx(DependencyObject d)
        {
            return (Visibility)d.GetValue(VisibilityExProperty);
        }

        private static void VisibilityExPropertyChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            TryFireChangeCallback((FrameworkElement)sender, e.Property, e);
        }
        #endregion
        #endregion

        #region Public Methods
        public static void RegisterDependencyPropertyCallback(FrameworkElement element, DependencyProperty attachedDp, Action<DependencyPropertyChangedEventArgs> changedCallback)
        {
            _registeredChangeCallbacks.Add(new KeyValuePair<FrameworkElement, DependencyProperty>(element, attachedDp), changedCallback);
        }

        public static void UnregisterDependencyPropertyCallback(FrameworkElement element, DependencyProperty attachedDp)
        {
            _registeredChangeCallbacks.Remove(new KeyValuePair<FrameworkElement, DependencyProperty>(element, attachedDp));
        }
        #endregion

        #region Private Methods
        private static void TryFireChangeCallback(FrameworkElement element, DependencyProperty dp, DependencyPropertyChangedEventArgs e)
        {
            var registeredCallbackKey = new KeyValuePair<FrameworkElement, DependencyProperty>(element, dp);
            Action<DependencyPropertyChangedEventArgs> changedCallback;
            if (_registeredChangeCallbacks.TryGetValue(registeredCallbackKey, out changedCallback))
            {
                changedCallback(e);
            }
        }
        #endregion

        #region Private Class
        private class RegisteredCallbackKey
        {
            public RegisteredCallbackKey(FrameworkElement element, DependencyProperty dp)
            {
                if (element == null || dp == null)
                {
                    throw new ArgumentNullException("Both element and dp must have values");
                }

                FrameworkElement = element;
                DependencyProperty = dp;
            }
            public FrameworkElement FrameworkElement { get; private set; }
            public DependencyProperty DependencyProperty { get; private set; }

            // override object.Equals
            public override bool Equals(object obj)
            {
                if (obj == null || GetType() != obj.GetType())
                {
                    return false;
                }


                var registeredCallbackKey = (RegisteredCallbackKey)obj;
                return FrameworkElement == registeredCallbackKey.FrameworkElement
                       && DependencyProperty == registeredCallbackKey.DependencyProperty;
            }

            // override object.GetHashCode
            public override int GetHashCode()
            {
                return FrameworkElement.GetHashCode() + DependencyProperty.GetHashCode();
            }
        }
        #endregion
    }
}