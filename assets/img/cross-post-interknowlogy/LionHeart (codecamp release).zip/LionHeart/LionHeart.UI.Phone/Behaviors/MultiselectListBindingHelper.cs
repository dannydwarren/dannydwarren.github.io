﻿using System.Collections;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Phone.Controls;

namespace LionHeart.UI.Phone.Behaviors
{
	public class MultiselectListBindingHelper
	{	
		#region SelectedItems (Attached Property)
		public static readonly DependencyProperty SelectedItemsProperty =
		  DependencyProperty.RegisterAttached("SelectedItems", typeof(IList), typeof(MultiselectList),
		                                      new PropertyMetadata(null, SelectedItemsPropertyChanged));

		public static void SetSelectedItems(DependencyObject d, IList value)
		{
		    d.SetValue(SelectedItemsProperty, value);
		}

		public static IList GetSelectedItems(DependencyObject d)
		{
		    return (IList)d.GetValue(SelectedItemsProperty);
		}

		private static void SelectedItemsPropertyChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
		    var multiselectList = sender as MultiselectList;
		    if (multiselectList == null)
		    {
		        return;
		    }

			multiselectList.SelectionChanged += SelectionChangedHandler;


			//if (!GetIsRegistered(multiselectList))
			//{
			//    //TODO: Did we ever find a way to unscubscribe to an AttachedBehavior? 
			//    //	Seems like this lives as long as the UI (in general not just the control it's bound to) lives.
			//    multiselectList.SelectionChanged += SelectionChangedHandler;
			//    SetIsRegistered(multiselectList, true);
			//}

			//var selectedItems = e.NewValue as IList;
			//if (selectedItems != null)
			//{
			//    multiselectList.SelectedItems.Clear();
			//    foreach (var selectedItem in selectedItems)
			//    {
			//        multiselectList.SelectedItems.Add(selectedItem);
			//    }
			//}
		}

		private static void SelectionChangedHandler(object sender, SelectionChangedEventArgs e)
		{
		    var multiselectList = sender as MultiselectList;
		    if (multiselectList == null)
		    {
		        return;
		    }

			var selectedItems = GetSelectedItems(multiselectList);
			if (selectedItems != null)
			{
				selectedItems.Clear();
				foreach (var selectedItem in multiselectList.SelectedItems)
				{
					selectedItems.Add(selectedItem);
				}
			}
		}

		#endregion
	}
}