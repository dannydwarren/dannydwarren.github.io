﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace LionHeart.UI.Phone.Behaviors
{
	public class RelativeSourceHelper : DependencyObject
	{
		#region Fields
		private static readonly Dictionary<object, IEnumerable<ParamState>> PARAM_STATES;
		#endregion

		#region Construction
		static RelativeSourceHelper()
		{
			PARAM_STATES = new Dictionary<object, IEnumerable<ParamState>>();
		}
		#endregion

		#region Properties
		#region RelativeSourceBinding (Attached Property)

		/// <summary>
		/// Property is a string made up of 1 or more sections (one for each 
		/// relative property to set - delimited with |),  
		/// each section of which is a multi-part string delimited with ;
		///   TargetProperty
		///   Path (for source property)
		///   Type of ancestor to find
		///   BindingMode (optional.  one of OneWay or TwoWay.  default is OneWay [TwoWay for Wp7])
		/// ex:  Content;ContentPanel;SlidePanel|Width;SlideoutWidth;SlidePanel
		///		Bind the Content of the target object to the ContentPanel property of the SlidePanel ancestor
		///		...and ...
		///		Bind the Width of the target object to the SlideoutWidth property of the SlidePanel ancestor
		/// </summary>
		public static readonly DependencyProperty RelativeSourceBindingProperty =
			DependencyProperty.RegisterAttached( "RelativeSourceBinding", typeof( string ), typeof( RelativeSourceHelper ), new PropertyMetadata( String.Empty, RelativeSourceBindingPropertyChanged ) );

		public static void SetRelativeSourceBinding( DependencyObject d, string value )
		{
			d.SetValue( RelativeSourceBindingProperty, value );
		}

		public static string GetRelativeSourceBinding( DependencyObject d )
		{
			return (string)d.GetValue( RelativeSourceBindingProperty );
		}

		private static void RelativeSourceBindingPropertyChanged( object sender, DependencyPropertyChangedEventArgs e )
		{
			var targetElement = sender as FrameworkElement;
			if ( targetElement == null || IsDesignMode(targetElement) )
			{
				return;
			}

			if ( e.NewValue != null )
			{
				string[] sections = e.NewValue.ToString().Split( '|' );
				var states = new List<ParamState>();

				foreach ( string section in sections )
				{
					string[] parts = section.Split( ';' );
					string targetPropertyName = parts[0];
					string path = parts[1];
					string desiredTypeName = parts[2];
					//Customizing for WinPhone7
					//BindingMode mode = BindingMode.OneWay;
					BindingMode mode = BindingMode.TwoWay;

					if ( parts.Length == 4 )
					{
						mode = (BindingMode)Enum.Parse( typeof(BindingMode), parts[3], true );
					}

					var state = new ParamState
					{
						TargetElement = targetElement,
						TargetProperty = targetPropertyName,
						Path = path,
						DesiredTypeName = desiredTypeName,
						Mode = mode
					};

					states.Add( state );
				}

				PARAM_STATES.Add( sender, states );
			}

			targetElement.Loaded += TargetElementLoadedHandler;

		}

		static void TargetElementLoadedHandler( object sender, RoutedEventArgs e )
		{
			// pull params out of state object
			if ( !PARAM_STATES.ContainsKey( sender ) )
			{
				return;
			}
			var targetElement = sender as FrameworkElement;
			if ( targetElement == null )
			{
				return;
			}

			var states = PARAM_STATES[sender];

			foreach ( ParamState state in states )
			{
				string targetPropertyPath = state.TargetProperty;
				string path = state.Path;
				string desiredTypeName = state.DesiredTypeName;

				DependencyObject sourceElement = FindAncestor( targetElement, desiredTypeName );
				DependencyProperty targetDP = FindDependencyProperty( targetElement, targetPropertyPath );

				if ( targetDP != null && sourceElement != null )
				{
					var bind = new Binding(path)
					           	{
					           		Source = sourceElement, 
									Mode = state.Mode
					           	};
					targetElement.SetBinding( targetDP, bind );
				}
				else
				{
					Debug.Assert( false, String.Format( "WARNING: Failed to set Relative Binding TargetProperty: {0}, Path: {1}, TargetType: {2}", targetPropertyPath, path, desiredTypeName ) );
				}

			}

			targetElement.Loaded -= TargetElementLoadedHandler;
			PARAM_STATES.Remove( sender );
			
		}

		#endregion

		#endregion

		#region Private
		private static DependencyObject FindAncestor( DependencyObject startingObject, string typeName )
		{
			var current = VisualTreeHelper.GetParent( startingObject );
			while ( current != null )
			{
				// we dont have a full Type object (only the short string typeName), so use the helper 
				// to traverse the object hierarchy
				if ( IsTypeOrBase( current.GetType(), typeName ) )
				{
					return current;
				}
				current = VisualTreeHelper.GetParent( current );
			}

			return null;
		}


		/// <summary>
		/// Return whether the given type or one of its base classes has the given typeName
		/// </summary>
		private static bool IsTypeOrBase( Type type, string typeName )
		{
			if ( type.Name == typeName )
			{
				return true;
			}

			// stop recursion with Object
			if ( type.Name == "Object" )
			{
				return false;
			}

			return IsTypeOrBase( type.BaseType, typeName );
		}


		private static readonly BindingFlags DP_FLAGS = BindingFlags.Public | BindingFlags.Static | BindingFlags.FlattenHierarchy;

		private static DependencyProperty FindDependencyProperty( DependencyObject sourceElement, string basePropertyName )
		{
			string dpName = basePropertyName;
			if ( !dpName.EndsWith( "Property") )
			{
				dpName = dpName + "Property";
			}

			FieldInfo[] targetFields = sourceElement.GetType().GetFields( DP_FLAGS );
			FieldInfo targetField = targetFields.FirstOrDefault( p => p.Name == dpName );
			if ( targetField == null )
			{
				return null;
			}

			var dp = targetField.GetValue( null ) as DependencyProperty;
			return dp;

		}

		/// <summary>
		/// Determines if the application is being run by a design tool
		/// </summary>
		private static bool IsDesignMode(FrameworkElement frameworkElement)
		{
			// VisualStudio sometimes returns false for DesignMode, DesignTool is our backup
			return DesignerProperties.GetIsInDesignMode(frameworkElement) || DesignerProperties.IsInDesignTool;
		}

		#endregion
	}

	internal class ParamState
	{
		public FrameworkElement TargetElement { get; set; }
		public string DesiredTypeName { get; set; }
		public string Path { get; set; }
		public string TargetProperty { get; set; }
		public BindingMode Mode { get; set; }
	};
}