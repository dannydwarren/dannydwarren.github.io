using System;
using System.Windows;
using System.Windows.Input;
using Microsoft.Phone.Shell;

namespace LionHeart.UI.Phone.Behaviors
{
	public class ApplicationBarMenuItemDelegate : FrameworkElement
	{
		#region Construction

		public ApplicationBarMenuItemDelegate()
		{
			MenuItem = new ApplicationBarMenuItem();
			MenuItem.Click += ClickHandler;
		}

		#endregion

		#region Events

		public event EventHandler IsVisibleChanged;
		private void OnIsVisibleChanged()
		{
			var handler = IsVisibleChanged;
			if (handler != null) handler(this, EventArgs.Empty);
		}

		public event EventHandler Click;
		private void OnClick(EventArgs e)
		{
			var handler = Click;
			if (handler != null) handler(this, e);
		}

		#endregion

		#region Properties

		#region Text (Dependency Property)
		public static readonly DependencyProperty TextProperty =
			DependencyProperty.Register("Text", typeof(string), typeof(ApplicationBarMenuItemDelegate),
										new PropertyMetadata("temp", OnTextChanged));

		public string Text
		{
			get { return (string)GetValue(TextProperty); }
			set { SetValue(TextProperty, value); }
		}

		private static void OnTextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((ApplicationBarMenuItemDelegate)d).OnTextChanged(e);
		}

		private void OnTextChanged(DependencyPropertyChangedEventArgs e)
		{
			MenuItem.Text = Text;
		}
		#endregion

		#region IsVisible (Dependency Property)
		public static readonly DependencyProperty IsVisibleProperty =
			DependencyProperty.Register("IsVisible", typeof(bool), typeof(ApplicationBarMenuItemDelegate),
										new PropertyMetadata(true, OnIsVisibleChanged));

		public bool IsVisible
		{
			get { return (bool)GetValue(IsVisibleProperty); }
			set { SetValue(IsVisibleProperty, value); }
		}

		private static void OnIsVisibleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((ApplicationBarMenuItemDelegate)d).OnIsVisibleChanged(e);
		}

		private void OnIsVisibleChanged(DependencyPropertyChangedEventArgs e)
		{
			OnIsVisibleChanged();
		}
		#endregion

		#region IsEnabled (Dependency Property)
		public static readonly DependencyProperty IsEnabledProperty =
			DependencyProperty.Register("IsEnabled", typeof(bool), typeof(ApplicationBarMenuItemDelegate),
										new PropertyMetadata(true, OnIsEnabledChanged));

		public bool IsEnabled
		{
			get { return (bool)GetValue(IsEnabledProperty); }
			set { SetValue(IsEnabledProperty, value); }
		}

		private static void OnIsEnabledChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((ApplicationBarMenuItemDelegate)d).OnIsEnabledChanged(e);
		}

		private void OnIsEnabledChanged(DependencyPropertyChangedEventArgs e)
		{
			MenuItem.IsEnabled = IsEnabled;
		}
		#endregion

		#region Command (Dependency Property)
		public static readonly DependencyProperty CommandProperty =
			DependencyProperty.Register("Command", typeof(ICommand), typeof(ApplicationBarMenuItemDelegate),
										new PropertyMetadata(null, OnCommandChanged));

		public ICommand Command
		{
			get { return (ICommand)GetValue(CommandProperty); }
			set { SetValue(CommandProperty, value); }
		}

		private static void OnCommandChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((ApplicationBarMenuItemDelegate)d).OnCommandChanged(e);
		}

		private void OnCommandChanged(DependencyPropertyChangedEventArgs e)
		{
			if (Command != null)
			{
				Command.CanExecuteChanged += CanExecuteChangedHandler;
			}

			var oldCommand = e.OldValue as ICommand;
			if (oldCommand != null)
			{
				oldCommand.CanExecuteChanged -= CanExecuteChangedHandler;
			}
		}

		#endregion

		#region CommandParameter (Dependency Property)
		public static readonly DependencyProperty CommandParameterProperty =
		  DependencyProperty.Register("CommandParameter", typeof(object), typeof(ApplicationBarMenuItemDelegate),
			new PropertyMetadata(null, OnCommandParameterChanged));

		public object CommandParameter
		{
			get { return (object)GetValue(CommandParameterProperty); }
			set { SetValue(CommandParameterProperty, value); }
		}

		private static void OnCommandParameterChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((ApplicationBarMenuItemDelegate)d).OnCommandParameterChanged(e);
		}

		private void OnCommandParameterChanged(DependencyPropertyChangedEventArgs e)
		{
			if (Command != null)
			{
				IsEnabled = Command.CanExecute(CommandParameter);
			}
		}
		#endregion

		public ApplicationBarMenuItem MenuItem { get; private set; }

		#endregion

		#region Private Methods

		private void CanExecuteChangedHandler(object sender, EventArgs e)
		{
			IsEnabled = Command.CanExecute(CommandParameter);
		}

		private void ClickHandler(object sender, EventArgs e)
		{
			if (Command != null && Command.CanExecute(CommandParameter))
			{
				Command.Execute(CommandParameter);
			}
			OnClick(e);
		}

		#endregion
	}
}