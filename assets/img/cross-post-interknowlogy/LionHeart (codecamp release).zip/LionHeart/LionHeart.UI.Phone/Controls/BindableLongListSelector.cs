﻿using System.Windows;
using System.Windows.Controls;
using Microsoft.Phone.Controls;

namespace LionHeart.UI.Phone.Controls
{
	public class BindableLongListSelector : LongListSelector
	{
		public BindableLongListSelector()
		{
			DefaultStyleKey = typeof (BindableLongListSelector);
			IsFlatList = true;

			SelectionChanged += LongListSelectorSelectionChanged;
		}

		#region BindableSelectedItem (Dependency Property)
		public static readonly DependencyProperty BindableSelectedItemProperty =
		  DependencyProperty.Register("BindableSelectedItem", typeof(object), typeof(BindableLongListSelector),
			new PropertyMetadata(null, OnBindableSelectedItemChanged));

		public object BindableSelectedItem
		{
			get { return (object)GetValue(BindableSelectedItemProperty); }
			set { SetValue(BindableSelectedItemProperty, value); }
		}

		private static void OnBindableSelectedItemChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((BindableLongListSelector)d).OnBindableSelectedItemChanged(e);
		}

		private void OnBindableSelectedItemChanged(DependencyPropertyChangedEventArgs e)
		{
			SelectedItem = e.NewValue;
		}
		#endregion

		#region ItemContainerStyle (Dependency Property)
		public static readonly DependencyProperty ItemContainerStyleProperty =
		  DependencyProperty.Register("ItemContainerStyle", typeof(Style), typeof(BindableLongListSelector),
			new PropertyMetadata(new Style()));

		public Style ItemContainerStyle
		{
			get { return (Style)GetValue(ItemContainerStyleProperty); }
			set { SetValue(ItemContainerStyleProperty, value); }
		}

		#endregion 

		private void LongListSelectorSelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			BindableSelectedItem = SelectedItem;
		}
	}
}