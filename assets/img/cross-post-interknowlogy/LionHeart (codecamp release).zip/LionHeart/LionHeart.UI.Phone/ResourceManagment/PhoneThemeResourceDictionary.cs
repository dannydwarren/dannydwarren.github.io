﻿using System.ComponentModel;
using System.Windows;

namespace LionHeart.UI.Phone.ResourceManagment
{
	public class PhoneThemeResourceDictionary : ResourceDictionary
	{
        /// <summary>
        /// Gets or sets the <see cref="ResourceDictioary"/> to use when in the "light" theme
        /// </summary>
        public ResourceDictionary LightResources
        {
            get { return _lightResources; }
            set
            {
                _lightResources = value;
                if (!IsDarkTheme && value != null)
                {
                    MergedDictionaries.Add(value);
                }
            }
        }
		private ResourceDictionary _lightResources;

		/// <summary>
		/// Gets or sets the <see cref="ResourceDictioary"/> to use when in the "dark" theme
		/// </summary>
		public ResourceDictionary DarkResources
		{
			get { return _darkResources; }
			set
			{
				_darkResources = value;
				if (IsDarkTheme && value != null)
				{
					MergedDictionaries.Add(value);
				}
			}
		}
		private ResourceDictionary _darkResources;

		/// <summary>
        /// Determines if the application is running in the dark theme
        /// </summary>
        private bool IsDarkTheme
        {
            get
            {
                if (IsDesignMode)
                {
                    return true;
                }
                else
                {
                    return (Visibility)Application.Current.Resources["PhoneDarkThemeVisibility"] == Visibility.Visible;
                }
            }
        }

        /// <summary>
        /// Determines if the application is being run by a design tool
        /// </summary>
        private bool IsDesignMode
        {
            get
            {
                // VisualStudio sometimes returns false for DesignMode, DesignTool is our backup
                return DesignerProperties.GetIsInDesignMode(this) || DesignerProperties.IsInDesignTool;
            }
        }
	}
}