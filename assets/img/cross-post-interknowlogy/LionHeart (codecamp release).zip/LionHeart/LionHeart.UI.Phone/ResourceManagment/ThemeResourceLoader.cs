﻿using System.IO;
using System.Windows;

namespace LionHeart.UI.Phone.ResourceManagment
{
	public static class ThemeResourceLoader
	{
		/// &lt;summary&gt; 
		/// Extends the Theme class 
		/// &lt;/summary&gt; 
		/// &lt;remarks&gt; 
		/// Uses the base implementation to load Dictionaries that may contain references to types not available. 
		/// &lt;/remarks&gt; 
		private class InternalTheme : Theme
		{
			private readonly ResourceDictionary _themeResourceDictionary;

			public InternalTheme(Stream themeResourceStream)
				: base(themeResourceStream)
			{
				// get the loaded dictionary 
				_themeResourceDictionary = Resources.MergedDictionaries[0];
				// remove the dictionary from our resources so it can be re-used. 
				Resources.MergedDictionaries.Clear();
			}

			public ResourceDictionary ThemeResourceDictionary
			{
				get
				{
					return _themeResourceDictionary;
				}
			}
		}

		public static ResourceDictionary Load(Stream stream)
		{
			var theme = new InternalTheme(stream);
			return theme.ThemeResourceDictionary;
		}

		public static ResourceDictionary LoadAndMerge(Stream stream, ResourceDictionary target)
		{
			var themeResourceDictionary = Load(stream);
			target.MergedDictionaries.Clear();
			target.MergedDictionaries.Add(themeResourceDictionary);
			return themeResourceDictionary;
		}
	}
}
