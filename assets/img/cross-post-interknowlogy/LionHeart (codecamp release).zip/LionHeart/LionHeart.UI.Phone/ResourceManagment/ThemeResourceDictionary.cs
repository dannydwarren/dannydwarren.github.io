﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Windows;

namespace LionHeart.UI.Phone.ResourceManagment
{
	public class ThemeResourceDictionary : ResourceDictionary
	{
		public static readonly DependencyProperty ThemeSourceProperty = DependencyProperty.Register(
		   "ThemeSource", typeof(Uri), typeof(ThemeResourceDictionary), new PropertyMetadata(null, ThemeSourceChanged));

		private ResourceDictionary _themeDictionary;

		public ThemeResourceDictionary()
		{
			if (DesignerProperties.IsInDesignTool)
			{
				var themeUri = Application.Current.Resources["DefaultDesignThemeUri"] as string ?? "DefaultDesignTheme.xaml";
				var themeDictionary = LoadThemeDictionary(new Uri(themeUri, UriKind.Relative));
				if (themeDictionary != null)
					MergeThemeDictionary(themeDictionary);
			}
		}

		public Uri ThemeSource
		{
			get
			{
				return (Uri)GetValue(ThemeSourceProperty);
			}
			set
			{
				SetValue(ThemeSourceProperty, value);
			}
		}

		private static void ThemeSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			var newValue = (Uri)e.NewValue;
			var oldValue = (Uri)e.OldValue;
			if (newValue != oldValue)
				((ThemeResourceDictionary)d).ThemeSourceChanged(oldValue, newValue);
		}

		private void ThemeSourceChanged(Uri oldValue, Uri newValue)
		{
			RemoveCurrentThemeDictionary();
			if (newValue != null)
			{
				var themeDictionary = LoadThemeDictionary(newValue);
				if (themeDictionary != null)
					MergeThemeDictionary(themeDictionary);
			}
		}

		private void MergeThemeDictionary(ResourceDictionary themeDictionary)
		{
			MergedDictionaries.Add(themeDictionary);
			// add a string entry for every "default" style matching the FullName of the type 
			foreach (var item in themeDictionary.Where(entry => entry.Key is Type && entry.Value is Style).ToList())
				this.Add(((Type)item.Key).FullName, item.Value);
			_themeDictionary = themeDictionary;
		}

		private static ResourceDictionary LoadThemeDictionary(Uri source)
		{
			var streamResourceInfo = Application.GetResourceStream(source);
			if (streamResourceInfo == null)
				return null;
			return ThemeResourceLoader.Load(streamResourceInfo.Stream);
		}

		private void RemoveCurrentThemeDictionary()
		{
			if (_themeDictionary != null)
			{
				MergedDictionaries.Remove(_themeDictionary);
				_themeDictionary = null;
			}
		}
	}
}
