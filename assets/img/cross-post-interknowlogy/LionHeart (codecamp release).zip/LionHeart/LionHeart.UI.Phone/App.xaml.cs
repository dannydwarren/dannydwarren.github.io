﻿using System;
using System.Windows;
using System.Windows.Navigation;
using LionHeart.Phone;
using LionHeart.Phone.Services;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace LionHeart.UI.Phone
{
	public partial class App : Application
	{
		/// <summary>
		/// Provides easy access to the root frame of the Phone Application.
		/// </summary>
		/// <returns>The root frame of the Phone Application.</returns>
		public PhoneApplicationFrame RootFrame { get; private set; }

		/// <summary>
		/// Constructor for the Application object.
		/// </summary>
		public App()
		{
			// Global handler for uncaught exceptions. 
			UnhandledException += Application_UnhandledException;

			// Standard Silverlight initialization
			InitializeComponent();

			// Phone-specific initialization
			InitializePhoneApplication();

			RootFrame.Obscured += AppObscured;
			RootFrame.Unobscured += AppUnobscured;

			// Show graphics profiling information while debugging.
			if (System.Diagnostics.Debugger.IsAttached)
			{
				// Display the current frame rate counters.
				//Application.Current.Host.Settings.EnableFrameRateCounter = true;

				// Show the areas of the app that are being redrawn in each frame.
				//Application.Current.Host.Settings.EnableRedrawRegions = true;

				// Enable non-production analysis visualization mode, 
				// which shows areas of a page that are handed off to GPU with a colored overlay.
				//Application.Current.Host.Settings.EnableCacheVisualization = true;

				// Disable the application idle detection by setting the UserIdleDetectionMode property of the
				// application's PhoneApplicationService object to Disabled.
				// Caution:- Use this under debug mode only. Application that disables user idle detection will continue to run
				// and consume battery power when the user is not using the phone.
				//PhoneApplicationService.Current.UserIdleDetectionMode = IdleDetectionMode.Disabled;
			}

		}

		private void Initialize(bool isLaunching)
		{
			CoreApplicationService.Instance.Initialize(RootFrame, isLaunching);
			InitializeNavigationMappings();
		}

		private void InitializeNavigationMappings()
		{
			CoreApplicationService.Instance.Mappings.Add(ViewKeys.HOME_VIEW_KEY, "/Views/HomeView.xaml");
			CoreApplicationService.Instance.Mappings.Add(ViewKeys.MY_VIEW_KEY, "/Views/MyView.xaml");
			CoreApplicationService.Instance.Mappings.Add(ViewKeys.ALL_CLIENTS_VIEW_KEY, "/Views/AllClientsView.xaml");
			CoreApplicationService.Instance.Mappings.Add(ViewKeys.CLIENT_VIEW_KEY, "/Views/ClientView.xaml");
			CoreApplicationService.Instance.Mappings.Add(ViewKeys.SESSION_NOTES_VIEW_KEY, "/Views/SessionNotesView.xaml");
			CoreApplicationService.Instance.Mappings.Add(ViewKeys.ALL_SESSIONS_VIEW_KEY, "/Views/AllSessionsView.xaml");
			CoreApplicationService.Instance.Mappings.Add(ViewKeys.MY_SESSIONS_VIEW_KEY, "/Views/MySessionsView.xaml");
			CoreApplicationService.Instance.Mappings.Add(ViewKeys.SESSION_VIEW_KEY, "/Views/SessionView.xaml");
			CoreApplicationService.Instance.Mappings.Add(ViewKeys.SETTINGS_VIEW_KEY, "/Views/SettingsView.xaml");
		}

		#region EventHandlers

		private void ApplicationLaunching(object sender, LaunchingEventArgs e)
		{
			Initialize(true);
		}

		private void ApplicationActivated(object sender, ActivatedEventArgs e)
		{
			if (!e.IsApplicationInstancePreserved)
			{
				Initialize(false);
			}
		}

		private void ApplicationDeactivated(object sender, DeactivatedEventArgs e)
		{
			CoreApplicationService.Instance.OnDeactivated(e);
		}

		private void ApplicationClosing(object sender, ClosingEventArgs e)
		{
			CoreApplicationService.Instance.OnClosing(e);
		}

		private void AppObscured(object sender, ObscuredEventArgs e)
		{
			CoreApplicationService.Instance.OnObscured(e);
		}

		private void AppUnobscured(object sender, EventArgs e)
		{
			CoreApplicationService.Instance.OnUnobscured(e);
		}

		private void RootFrame_NavigationFailed(object sender, NavigationFailedEventArgs e)
		{
			if (System.Diagnostics.Debugger.IsAttached)
			{
				// A navigation has failed; break into the debugger
				System.Diagnostics.Debugger.Break();
			}
			if (CoreApplicationService.Instance != null)
			{
				CoreApplicationService.Instance.OnNavigationFailed(e);
			}
		}

		private void Application_UnhandledException(object sender, ApplicationUnhandledExceptionEventArgs e)
		{
			if (System.Diagnostics.Debugger.IsAttached)
			{
				// An unhandled exception has occurred; break into the debugger
				System.Diagnostics.Debugger.Break();
			}
			if (CoreApplicationService.Instance != null)
			{
				CoreApplicationService.Instance.OnUnhandledException(e);
			}
		}

		#endregion

		#region Phone application initialization

		// Avoid double-initialization
		private bool _phoneApplicationInitialized;

		// Do not add any additional code to this method
		private void InitializePhoneApplication()
		{
			if (_phoneApplicationInitialized)
				return;

			// Create the frame but don't set it as RootVisual yet; this allows the splash
			// screen to remain active until the application is ready to render.
			RootFrame = new PhoneApplicationFrame();
			RootFrame.Navigated += CompleteInitializePhoneApplication;

			// Handle navigation failures
			RootFrame.NavigationFailed += RootFrame_NavigationFailed;

			// Ensure we don't initialize again
			_phoneApplicationInitialized = true;
		}

		// Do not add any additional code to this method
		private void CompleteInitializePhoneApplication(object sender, NavigationEventArgs e)
		{
			// Set the root visual to allow the application to render
			if (RootVisual != RootFrame)
				RootVisual = RootFrame;

			// Remove this handler since it is no longer needed
			RootFrame.Navigated -= CompleteInitializePhoneApplication;
		}

		#endregion
	}
}