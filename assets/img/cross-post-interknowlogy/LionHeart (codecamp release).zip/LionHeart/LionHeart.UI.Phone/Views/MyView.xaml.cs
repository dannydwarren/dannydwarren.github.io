﻿namespace LionHeart.UI.Phone.Views
{
	public partial class MyView : ViewBase
	{
		public MyView()
		{
			InitializeComponent();
		}
	}
}