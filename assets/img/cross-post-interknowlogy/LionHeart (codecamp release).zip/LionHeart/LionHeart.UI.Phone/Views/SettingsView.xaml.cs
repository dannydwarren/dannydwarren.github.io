﻿namespace LionHeart.UI.Phone.Views
{
	public partial class SettingsView : ViewBase
	{
		public SettingsView()
		{
			InitializeComponent();
		}
	}
}