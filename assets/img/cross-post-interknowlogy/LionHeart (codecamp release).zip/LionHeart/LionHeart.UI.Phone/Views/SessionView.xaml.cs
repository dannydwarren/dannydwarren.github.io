﻿namespace LionHeart.UI.Phone.Views
{
	public partial class SessionView : ViewBase
	{
		public SessionView()
		{
			InitializeComponent();
		}
	}
}