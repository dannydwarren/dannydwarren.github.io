﻿using System.Windows.Navigation;
using LionHeart.ViewModels;
using Microsoft.Phone.Controls;

namespace LionHeart.UI.Phone.Views
{
	public class ViewBase : PhoneApplicationPage
	{
		public PageViewModel PageViewModel { get { return DataContext as PageViewModel; } }

		protected override void OnNavigatedTo(NavigationEventArgs e)
		{
			if (PageViewModel != null)
			{
				var parameters = e.NavigationMode == NavigationMode.Back ? null : NavigationContext.QueryString;
				PageViewModel.Initialize(parameters);
			}
			base.OnNavigatedTo(e);
		}

		protected override void OnNavigatedFrom(NavigationEventArgs e)
		{
			if (PageViewModel != null)
			{
				PageViewModel.Uninitialize(e.NavigationMode == NavigationMode.Back);
			}
			base.OnNavigatedFrom(e);
		}

		protected override void OnRemovedFromJournal(JournalEntryRemovedEventArgs e)
		{
			if (PageViewModel != null)
			{
				PageViewModel.Uninitialize(true);
			}
			base.OnRemovedFromJournal(e);
		}
	}
}