﻿namespace LionHeart.UI.Phone.Views
{
	public partial class HomeView : ViewBase
	{
		public HomeView()
		{
			InitializeComponent();
		}
	}
}