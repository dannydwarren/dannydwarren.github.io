﻿namespace LionHeart.UI.Phone.Views
{
	public partial class ClientView : ViewBase
	{
		public ClientView()
		{
			InitializeComponent();
		}
	}
}