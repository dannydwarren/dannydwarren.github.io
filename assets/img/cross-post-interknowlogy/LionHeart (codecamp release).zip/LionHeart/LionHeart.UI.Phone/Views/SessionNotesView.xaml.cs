﻿namespace LionHeart.UI.Phone.Views
{
	public partial class SessionNotesView : ViewBase
	{
		public SessionNotesView()
		{
			InitializeComponent();
		}
	}
}