﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Windows.ApplicationModel.DataTransfer;
using Windows.ApplicationModel.Search;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using WinRTSearchSample.ViewModels;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace WinRTSearchSample
{
	/// <summary>
	/// An empty page that can be used on its own or navigated to within a Frame.
	/// </summary>
	public sealed partial class MainPage : Page
	{
		private SearchPane _searchPane;
		private DataTransferManager _datatransferManager;

		public MainPage()
		{
			this.InitializeComponent();

			_searchPane = SearchPane.GetForCurrentView();
			_searchPane.QuerySubmitted += QuerySubmitted;
			_searchPane.SuggestionsRequested += SuggestionsRequested;
		}

		public VehicleManagementVM ViewModel { get { return DataContext as VehicleManagementVM; } }

		#region Searching

		private void QuerySubmitted(SearchPane sender, SearchPaneQuerySubmittedEventArgs args)
		{
			WinRTSearchSample.SearchResultsPage.Activate(args.QueryText, Windows.ApplicationModel.Activation.ApplicationExecutionState.Running);
		}

		private void SuggestionsRequested(SearchPane sender, SearchPaneSuggestionsRequestedEventArgs args)
		{
			//string[] suggestions = { "AAA", "AAABBB", "AAACCC", "AAADDD", "EEE", "FFF", "GGG", "HHH", "III", "JJJ", "KKK", "LLL", "MMM", "NNN", "OOO", "PPP", "QQQ", "Toyota", "TTT1", "TTT2", "TTT3", "TTT4", "TTT5", "TTT6" };

			string[] suggestions = App.AllVehicles.Select(v=>v.Title).ToArray();

			foreach (string suggestion in suggestions)
			{
				if (suggestion.StartsWith(args.QueryText, StringComparison.CurrentCultureIgnoreCase))
				{
					args.Request.SearchSuggestionCollection.AppendQuerySuggestion(suggestion);
				}
				if (args.Request.SearchSuggestionCollection.Size >= 5)
				{
					break;
				}
			}
		}

		private void LogEntryButtonClick(object sender, RoutedEventArgs e)
		{
			if (ViewModel != null)
			{
				ViewModel.LogEntry();
			}
		}

		#endregion

		#region SharingSource

		protected override void OnNavigatedTo(NavigationEventArgs e)
		{
			RegisterForSharing();
			base.OnNavigatedTo(e);
		}

		protected override void OnNavigatedFrom(NavigationEventArgs e)
		{
			UnregisterForSharing();
			base.OnNavigatedFrom(e);
		}

		private void RegisterForSharing()
		{
			if (_datatransferManager == null)
			{
				_datatransferManager = DataTransferManager.GetForCurrentView();
			}
			_datatransferManager.DataRequested += DataRequested;
		}

		private void UnregisterForSharing()
		{
			_datatransferManager.DataRequested -= DataRequested;
		}

		void DataRequested(DataTransferManager sender, DataRequestedEventArgs e)
		{
			if (ViewModel != null && ViewModel.SelectedVehicle != null)
			{
				e.Request.Data.Properties.Title = "Vehicle To Share";
				e.Request.Data.Properties.Description = ViewModel.SelectedVehicle.SharingMessage;
				e.Request.Data.SetText(ViewModel.SelectedVehicle.SharingMessage);
			}
			else
			{
				e.Request.FailWithDisplayText("No selected vehicle to share.");
			}
		}

		private void GridViewItemClick(object sender, ItemClickEventArgs e)
		{
			if (ViewModel != null)
			{
				ViewModel.SelectedVehicle = e.ClickedItem as SearchResult;
			}
		}

		#endregion
	}
}
