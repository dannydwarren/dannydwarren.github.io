﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;
using WinRTSearchSample.Common;

namespace WinRTSearchSample.ViewModels
{
	public class VehicleManagementVM : BindableBase
	{
		public VehicleManagementVM()
		{
			AllVehicles = App.AllVehicles;
		}

		private string _vehicleName;
		public string VehicleName
		{
			[DebuggerStepThrough]
			get { return _vehicleName; }
			set
			{
				if (value == _vehicleName)
					return;

				_vehicleName = value;
				OnPropertyChanged("VehicleName");
			}
		}

		private string _make;
		public string Make
		{
			[DebuggerStepThrough]
			get { return _make; }
			set
			{
				if (value == _make)
					return;

				_make = value;
				OnPropertyChanged("Make");
			}
		}

		private string _modelYear;
		public string ModelYear
		{
			[DebuggerStepThrough]
			get { return _modelYear; }
			set
			{
				if (value == _modelYear)
					return;

				_modelYear = value;
				OnPropertyChanged("ModelYear");
			}
		}

		private ObservableCollection<SearchResult> _allVehicles;
		public ObservableCollection<SearchResult> AllVehicles
		{
			[DebuggerStepThrough]
			get { return _allVehicles; }
			set
			{
				if (value == _allVehicles)
					return;

				_allVehicles = value;
				OnPropertyChanged("AllVehicles");
			}
		}

		private SearchResult _selectedVehicle;
		public SearchResult SelectedVehicle
		{
			[DebuggerStepThrough]
			get { return _selectedVehicle; }
			set
			{
				if (value == _selectedVehicle)
					return;

				_selectedVehicle = value;
				OnPropertyChanged("SelectedVehicle");
			}
		}

		public void LogEntry()
		{
			var newVehicleEntry = new SearchResult
			{
				Title = VehicleName,
				Subtitle = Make,
				Description = ModelYear,
			};

			AllVehicles.Add(newVehicleEntry);

			VehicleName = string.Empty;
			Make = string.Empty;
			ModelYear = string.Empty;
		}
	}
}
