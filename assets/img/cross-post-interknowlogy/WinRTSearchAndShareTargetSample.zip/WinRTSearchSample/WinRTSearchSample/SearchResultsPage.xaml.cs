﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using Windows.ApplicationModel.Activation;
using Windows.ApplicationModel.DataTransfer;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Search Contract item template is documented at http://go.microsoft.com/fwlink/?LinkId=234240

namespace WinRTSearchSample
{
	/// <summary>
	/// This page displays search results when a global search is directed to this application.
	/// </summary>
	public sealed partial class SearchResultsPage : WinRTSearchSample.Common.LayoutAwarePage
	{
		private UIElement _previousContent;
		private ApplicationExecutionState _previousExecutionState;
		private DataTransferManager _datatransferManager;

		public SearchResultsPage()
		{
			this.InitializeComponent();
		}

		#region Search

		/// <summary>
		/// Determines how best to support navigation back to the previous application state.
		/// </summary>
		public static void Activate(String queryText, ApplicationExecutionState previousExecutionState)
		{
			var previousContent = Window.Current.Content;
			var frame = previousContent as Frame;

			if (frame != null)
			{
				// If the app is already running and uses top-level frame navigation we can just
				// navigate to the search results
				frame.Navigate(typeof(SearchResultsPage), queryText);
			}
			else
			{
				// Otherwise bypass navigation and provide the tools needed to emulate the back stack
				SearchResultsPage page = new SearchResultsPage();
				page._previousContent = previousContent;
				page._previousExecutionState = previousExecutionState;
				page.LoadState(queryText, null);
				Window.Current.Content = page;
			}

			// Either way, active the window
			Window.Current.Activate();
		}

		List<SearchResult> _foundVehicles;
		IEnumerable<IGrouping<string, SearchResult>> _groupVehiclesByMake;
		/// <summary>
		/// Populates the page with content passed during navigation.  Any saved state is also
		/// provided when recreating a page from a prior session.
		/// </summary>
		/// <param name="navigationParameter">The parameter value passed to
		/// <see cref="Frame.Navigate(Type, Object)"/> when this page was initially requested.
		/// </param>
		/// <param name="pageState">A dictionary of state preserved by this page during an earlier
		/// session.  This will be null the first time a page is visited.</param>
		protected override void LoadState(Object navigationParameter, Dictionary<String, Object> pageState)
		{
			var queryText = navigationParameter as String;

			ObservableCollection<SearchResult> allVehicles = App.AllVehicles;

			_foundVehicles = allVehicles.Where(vehicle => vehicle.Title.Contains(queryText)).ToList(); // case sesitive approach

			IEnumerable<string> foundMakes = _foundVehicles.Select(vehicle => vehicle.Subtitle).Distinct();

			List<Filter> makeFilters = foundMakes.Select(make => new Filter(make, _foundVehicles.Count(vehicle => vehicle.Subtitle == make))).ToList();

			_groupVehiclesByMake = _foundVehicles.GroupBy(vehicle => vehicle.Subtitle);

			var filterList = new List<Filter>();
			filterList.Add(new Filter("All", _foundVehicles.Count, true));
			filterList.AddRange(makeFilters);

			// Communicate results through the view model
			this.DefaultViewModel["Results"] = _foundVehicles;
			this.DefaultViewModel["QueryText"] = '\u201c' + queryText + '\u201d';
			this.DefaultViewModel["CanGoBack"] = this._previousContent != null;
			this.DefaultViewModel["Filters"] = filterList;
			this.DefaultViewModel["ShowFilters"] = filterList.Count > 1;
		}

		/// <summary>
		/// Invoked when the back button is pressed.
		/// </summary>
		/// <param name="sender">The Button instance representing the back button.</param>
		/// <param name="e">Event data describing how the button was clicked.</param>
		protected override void GoBack(object sender, RoutedEventArgs e)
		{
			// Return the application to the state it was in before search results were requested
			try
			{
				if (this.Frame != null && this.Frame.CanGoBack)
				{
					this.Frame.GoBack();
				}
				else if (this._previousContent != null)
				{
					Window.Current.Content = this._previousContent;
				}
				else
				{
					// TODO: invoke the app's normal launch behavior, using this._previousExecutionState
					//       as appropriate.  Exact details can vary from app to app, which is why an
					//       implementation isn't included in the Search Contract template.  Typically
					//       this method and OnLaunched in App.xaml.cs can call a common method.
				}

			}
			catch (Exception)
			{
			}
		}

		/// <summary>
		/// Invoked when a filter is selected using the ComboBox in snapped view state.
		/// </summary>
		/// <param name="sender">The ComboBox instance.</param>
		/// <param name="e">Event data describing how the selected filter was changed.</param>
		void Filter_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			// Determine what filter was selected
			var selectedFilter = e.AddedItems.FirstOrDefault() as Filter;
			if (selectedFilter != null)
			{
				// Mirror the results into the corresponding Filter object to allow the
				// RadioButton representation used when not snapped to reflect the change
				selectedFilter.Active = true;

				if (selectedFilter.Name == "All")
				{
					if (_foundVehicles != null && _foundVehicles.Any())
					{
						this.DefaultViewModel["Results"] = _foundVehicles;
					}
				}
				else
				{
					if (_groupVehiclesByMake != null && _groupVehiclesByMake.Any())
					{
						this.DefaultViewModel["Results"] = _groupVehiclesByMake.FirstOrDefault(grouping => grouping.Key == selectedFilter.Name).ToList();
					}
				}

				// Ensure results are found
				object results;
				ICollection foundVehicles;
				if (this.DefaultViewModel.TryGetValue("Results", out results) &&
					(foundVehicles = results as ICollection) != null &&
					foundVehicles.Count != 0)
				{
					VisualStateManager.GoToState(this, "ResultsFound", true);
					return;
				}
			}

			// Display informational text when there are no search results.
			VisualStateManager.GoToState(this, "NoResultsFound", true);
		}

		/// <summary>
		/// Invoked when a filter is selected using a RadioButton when not snapped.
		/// </summary>
		/// <param name="sender">The selected RadioButton instance.</param>
		/// <param name="e">Event data describing how the RadioButton was selected.</param>
		void Filter_Checked(object sender, RoutedEventArgs e)
		{
			// Mirror the change into the CollectionViewSource used by the corresponding ComboBox
			// to ensure that the change is reflected when snapped
			if (filtersViewSource.View != null)
			{
				var filter = (sender as FrameworkElement).DataContext;
				filtersViewSource.View.MoveCurrentTo(filter);
			}
		}

		/// <summary>
		/// View model describing one of the filters available for viewing search results.
		/// </summary>
		private sealed class Filter : WinRTSearchSample.Common.BindableBase
		{
			private String _name;
			private int _count;
			private bool _active;

			public Filter(String name, int count, bool active = false)
			{
				this.Name = name;
				this.Count = count;
				this.Active = active;
			}

			public override String ToString()
			{
				return Description;
			}

			public String Name
			{
				get { return _name; }
				set { if (this.SetProperty(ref _name, value)) this.OnPropertyChanged("Description"); }
			}

			public int Count
			{
				get { return _count; }
				set { if (this.SetProperty(ref _count, value)) this.OnPropertyChanged("Description"); }
			}

			public bool Active
			{
				get { return _active; }
				set { this.SetProperty(ref _active, value); }
			}

			public String Description
			{
				get { return String.Format("{0} ({1})", _name, _count); }
			}
		}

		#endregion

		#region SharingSource

		protected override void OnNavigatedTo(NavigationEventArgs e)
		{
			RegisterForSharing();
			base.OnNavigatedTo(e);
		}

		protected override void OnNavigatedFrom(NavigationEventArgs e)
		{
			UnregisterForSharing();
			base.OnNavigatedFrom(e);
		}

		private void UnregisterForSharing()
		{
			_datatransferManager.DataRequested -= DataRequested;
		}

		private void RegisterForSharing()
		{
			if (_datatransferManager == null)
			{
				_datatransferManager = DataTransferManager.GetForCurrentView();
			}
			_datatransferManager.DataRequested += DataRequested;
		}

		void DataRequested(DataTransferManager sender, DataRequestedEventArgs e)
		{
			if (_foundVehicles != null)// DefaultViewModel != null && DefaultViewModel["SelectedVehicle"] != null)
			{
				var selectedVehicle = ((SearchResult)DefaultViewModel["SelectedVehicle"]);

				e.Request.Data.Properties.Title = "Vehicle To Share";
				e.Request.Data.Properties.Description = selectedVehicle.SharingMessage;

				var a = _foundVehicles.Select(v=>v.SharingMessage);

				var b = string.Concat(a);

				e.Request.Data.SetText( b);
			}
			else
			{
				e.Request.FailWithDisplayText("No selected vehicle to share.");
			}
		}

		private void resultsGridView_ItemClick_1(object sender, ItemClickEventArgs e)
		{
			DefaultViewModel["SelectedVehicle"] = e.ClickedItem;
		}

		#endregion
	}
}
