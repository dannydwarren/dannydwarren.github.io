﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace NavigationPoC
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
			//TODO: 20 Page Cache vs Restore Data
	        NavigationCacheMode = Windows.UI.Xaml.Navigation.NavigationCacheMode.Enabled;
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
			//TODO: 5 - Different format
			Debug.WriteLine( string.Format( "MainPage: OnNavigatedTo - ({0})", e.Parameter ) );
			//Debug.WriteLine( String.Format( "MainPage: GetNavigationState: {0}", Frame.GetNavigationState() ) ); 
		}

		protected override void OnNavigatingFrom( NavigatingCancelEventArgs e )
		{
			//TODO: 8
			Debug.WriteLine( "MainPage: OnNavigatingFrom" );
			base.OnNavigatingFrom( e );
		}

		protected override void OnNavigatedFrom( NavigationEventArgs e )
		{
			//TODO: 10
			//TODO: 17
			Debug.WriteLine( "MainPage: OnNavigatedFrom" );
			base.OnNavigatedFrom( e );
		}

	    private void NextPageButtonClick(object sender, RoutedEventArgs e)
	    {
			//TODO: 6
			Debug.WriteLine( "MainPage: NextPageButtonClick*******************************************" );
			Frame.Navigate( typeof( SecondPage ), "FUN" );
	    }

	    private void ForwardButtonClick(object sender, RoutedEventArgs e)
	    {
			Debug.WriteLine( "MainPage: ForwardButtonClick*******************************************" );
			Frame.GoForward();
	    }
    }
}
