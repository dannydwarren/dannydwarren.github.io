﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;
using Windows.Phone.Speech.Recognition;

namespace SpeechTest
{
	public partial class MainPage : PhoneApplicationPage
	{
		public MainPage()
		{
			InitializeComponent();
		}

		private async void ActivateSpeechRecognitionButtonClickHandler(object sender, RoutedEventArgs e)
		{
			var speechRecognizerUI = new SpeechRecognizerUI();

			SpeechRecognitionUIResult result = await speechRecognizerUI.RecognizeWithUIAsync();

			MessageBox.Show(result.RecognitionResult.Text);
		}
	}
}