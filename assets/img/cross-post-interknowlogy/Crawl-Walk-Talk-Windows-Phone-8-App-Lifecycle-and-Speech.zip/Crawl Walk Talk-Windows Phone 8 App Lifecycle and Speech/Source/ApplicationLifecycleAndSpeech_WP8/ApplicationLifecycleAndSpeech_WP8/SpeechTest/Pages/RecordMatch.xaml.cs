﻿using System;
using System.Windows;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Windows.Phone.Speech.Recognition;
using Windows.Phone.Speech.Synthesis;

namespace SpeechTest.Pages
{
	public partial class RecordMatch : PhoneApplicationPage
	{
		private const string VOICE_COMMAND_NAME_KEY = "voiceCommandName";
		private const string RECORD_MATCH_WITH_PLAYER_NAMES_KEY = "RecordMatchWithPlayerNames";
		private const string RECORD_MATCH_WITH_TEAM_NAMES_KEY = "RecordMatchWithTeamNames";

		private const string POINT_PLAYER_FORMAT = "Point {0}";
		private const string ADD_ONE_PLAYER_FORMAT = "Add One {0}";

		public RecordMatch()
		{
			InitializeComponent();
		}

		protected override void OnNavigatedTo( NavigationEventArgs e )
		{
			base.OnNavigatedTo( e );

			string voiceCommandName;
			if ( NavigationContext.QueryString.TryGetValue( VOICE_COMMAND_NAME_KEY, out voiceCommandName ) )
			{
				string player1Name = "Player One";
				string player2Name = "Player Two";
				if ( voiceCommandName == RECORD_MATCH_WITH_PLAYER_NAMES_KEY )
				{
					PageName.Text = "record singles match";
					player1Name = NavigationContext.QueryString["Player1Name"];
					player2Name = NavigationContext.QueryString["Player2Name"];
				}
				else if ( voiceCommandName == RECORD_MATCH_WITH_TEAM_NAMES_KEY )
				{
					PageName.Text = "record doubles match";
					player1Name = NavigationContext.QueryString["Team1Name"];
					player2Name = NavigationContext.QueryString["Team2Name"];
				}

				InitializeMatch( player1Name, player2Name );
			}
		}

		private SpeechSynthesizer _speechSynth = new SpeechSynthesizer();
		private SpeechRecognizer _speechReco = new SpeechRecognizer();
		private async void InitializeMatch( string player1Name, string player2Name )
		{
			Player1Name.Text = player1Name;
			Player2Name.Text = player2Name;

			await _speechSynth.SpeakTextAsync( string.Format( "Match. {0} verses {1}. Ready? Fight!", player1Name, player2Name ) );

			string[] pointGrammar = new[]
				                        {
											string.Format(POINT_PLAYER_FORMAT, player1Name),
											string.Format(POINT_PLAYER_FORMAT, player2Name),
											string.Format(ADD_ONE_PLAYER_FORMAT, player1Name),
											string.Format(ADD_ONE_PLAYER_FORMAT, player2Name),
				                        };

			_speechReco.Grammars.AddGrammarFromList( "PointGrammarKey", pointGrammar );
			_speechReco.AudioCaptureStateChanged += AudioCaptureStateChanged;

			int player1Points = 0;
			int player2Points = 0;
			while ( player1Points < 21 && player2Points < 21
				   && ( player1Points > player2Points - 2 || player2Points > player1Points - 2 ) )
			{
				SpeechRecognitionResult result = await _speechReco.RecognizeAsync();
				if ( result.Text == pointGrammar[0] || result.Text == pointGrammar[2] )
				{
					player1Points++;
				}
				else if ( result.Text == pointGrammar[1] || result.Text == pointGrammar[3] )
				{
					player2Points++;
				}

				Player1Points.Text = player1Points.ToString();
				Player2Points.Text = player2Points.ToString();
			}

			string winnerName = player1Points > player2Points ? player1Name : player2Name;
			Winner.Text = string.Format("Winner: {0}!!!!", winnerName);
			SpeechStatus.Text = "Stopped";
		}

		private void AudioCaptureStateChanged( SpeechRecognizer sender, SpeechRecognizerAudioCaptureStateChangedEventArgs args )
		{
			Deployment.Current.Dispatcher.BeginInvoke( () =>
														  {
															  switch ( args.State )
															  {
																  case SpeechRecognizerAudioCaptureState.Inactive:
																	  SpeechStatus.Text = "Processing...";
																	  break;
																  case SpeechRecognizerAudioCaptureState.Capturing:
																	  SpeechStatus.Text = "Listening...";
																	  break;
																  default:
																	  throw new ArgumentOutOfRangeException();
															  }
														  } );
		}
	}
}