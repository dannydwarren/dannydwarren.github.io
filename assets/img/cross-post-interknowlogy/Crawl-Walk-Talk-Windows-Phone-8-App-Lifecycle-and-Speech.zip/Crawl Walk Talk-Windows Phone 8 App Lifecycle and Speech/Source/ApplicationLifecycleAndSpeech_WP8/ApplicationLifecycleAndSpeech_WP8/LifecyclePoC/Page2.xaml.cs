﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace LifecyclePoC
{
	public partial class Page2 : PhoneApplicationPage
	{
		private bool _hasState;

		public Page2()
		{
			InitializeComponent();
		}

		protected override void OnNavigatedTo( NavigationEventArgs e )
		{
			//TODO: 4.2 - Page2-OnNavigatedTo
			Debug.WriteLine( "Page2-OnNavigatedTo - HasState: {0}", _hasState );
			//TODO: 4.4 - Initialize, Set _hasState & Value.Text
			Initialize();
			base.OnNavigatedTo( e );
		}

		private void Initialize()
		{
			if (_hasState)
			{
				return;
			}
			Debug.WriteLine( "Page2-Initialize-NoState" ); 

			Value.Text = NavigationContext.QueryString["value"];

			_hasState = true;
		}


		protected override void OnNavigatedFrom( NavigationEventArgs e )
		{
			//TODO: 4.3 - Page2-OnNavigatedFrom
			Debug.WriteLine( "Page2-OnNavigatedFrom" ); 
			base.OnNavigatedFrom( e );
		}
	}
}