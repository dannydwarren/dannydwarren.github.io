﻿using Microsoft.Phone.Controls;

namespace SpeechTest.Pages
{
	public partial class MatchResults : PhoneApplicationPage
	{
		public MatchResults()
		{
			InitializeComponent();
		}
	}
}