﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Windows.Phone.Speech.Recognition;
using Windows.Phone.Speech.Synthesis;

namespace DAPPr_PoC
{
	public partial class RecordMatch : PhoneApplicationPage
	{

		public RecordMatch()
		{
			InitializeComponent();
		}

		private const string VOICE_COMMAND_NAME_KEY = "voiceCommandName";
		private const string RECORD_MATCH_WITH_PLAYER_NAMES_KEY = "RecordMatchWithPlayerNames";
		private const string RECORD_MATCH_WITH_TEAM_NAMES_KEY = "RecordMatchWithTeamNames";
		private const string RECORD_MATCH_UNKNOWN_KEY = "RecordMatchUnknown";

		protected override void OnNavigatedTo( NavigationEventArgs e )
		{
			base.OnNavigatedTo( e );

			string player1Name = "Player One";
			string player2Name = "Player Two";

			string voiceCommandName;
			if ( NavigationContext.QueryString.TryGetValue( VOICE_COMMAND_NAME_KEY, out voiceCommandName ) )
			{
				if ( voiceCommandName == RECORD_MATCH_WITH_PLAYER_NAMES_KEY )
				{
					PageTitle.Text = "record singles match";
					player1Name = NavigationContext.QueryString["Player1Name"];
					player2Name = NavigationContext.QueryString["Player2Name"];
				}
				else if ( voiceCommandName == RECORD_MATCH_WITH_TEAM_NAMES_KEY )
				{
					PageTitle.Text = "record doubles match";
					player1Name = NavigationContext.QueryString["Team1Name"];
					player2Name = NavigationContext.QueryString["Team2Name"];
				}
				else if ( voiceCommandName == RECORD_MATCH_UNKNOWN_KEY )
				{
					PageTitle.Text = "record unknown match";
				}
			}

			InitializeMatch( player1Name, player2Name );
		}

		private async void InitializeMatch( string player1Name, string player2Name )
		{
			Player1NameTextBox.Text = player1Name;
			Player2NameTextBox.Text = player2Name;

			//TODO: TTS Example
			await AnnounceMatch( player1Name, player2Name );

			//TODO: Speech Recognition Example
			await UseVoiceToRecordPoints( player1Name, player2Name );
		}

		//****************************************************************************************************
		//****************************************************************************************************
		//****************************************************************************************************
		//****************************************************************************************************
		//****************************************************************************************************
		//****************************************************************************************************
		//****************************************************************************************************
		//****************************************************************************************************
		//****************************************************************************************************
		//****************************************************************************************************

		private readonly SpeechSynthesizer _speechSynth = new SpeechSynthesizer();
		private async Task AnnounceMatch( string player1Name, string player2Name )
		{
			await _speechSynth.SpeakTextAsync( string.Format( "Match. {0} verses {1}. Ready? Fight!", player1Name, player2Name ) );
		}

		//****************************************************************************************************
		//****************************************************************************************************
		//****************************************************************************************************
		//****************************************************************************************************
		//****************************************************************************************************
		//****************************************************************************************************
		//****************************************************************************************************
		//****************************************************************************************************
		//****************************************************************************************************
		//****************************************************************************************************

		private const string POINT_PLAYER_FORMAT = "Point {0}";
		private const string ADD_ONE_PLAYER_FORMAT = "Add One {0}";
		private const int WINNING_SCORE = 3;
		private const int WIN_BY_FACTOR = 1;

		private readonly SpeechRecognizer _speechReco = new SpeechRecognizer();

		private async Task UseVoiceToRecordPoints( string player1Name, string player2Name )
		{
			//Using Programmatic List Grammar
			string[] pointGrammar = new[]
				                        {
					                        string.Format(POINT_PLAYER_FORMAT, player1Name),
					                        string.Format(POINT_PLAYER_FORMAT, player2Name),
					                        string.Format(ADD_ONE_PLAYER_FORMAT, player1Name),
					                        string.Format(ADD_ONE_PLAYER_FORMAT, player2Name),
				                        };

			_speechReco.Grammars.AddGrammarFromList( "PointGrammarKey", pointGrammar );
			_speechReco.AudioCaptureStateChanged += AudioCaptureStateChanged;

			int player1Points = 0;
			int player2Points = 0;
			while ( player1Points < WINNING_SCORE && player2Points < WINNING_SCORE
				   && ( player1Points > player2Points - WIN_BY_FACTOR || player2Points > player1Points - WIN_BY_FACTOR ) )
			{
				SpeechRecognitionResult result = await _speechReco.RecognizeAsync();
				if ( result.Text == pointGrammar[0] || result.Text == pointGrammar[2] )
				{
					player1Points++;
				}
				else if ( result.Text == pointGrammar[1] || result.Text == pointGrammar[3] )
				{
					player2Points++;
				}

				Player1PointsTextBox.Text = player1Points.ToString();
				Player2PointsTextBox.Text = player2Points.ToString();
			}

			string winnerName = player1Points > player2Points ? player1Name : player2Name;
			Winner.Text = string.Format( "Winner: {0}!!!!", winnerName );
			SpeechStatus.Text = "Stopped";
		}

		private void AudioCaptureStateChanged( SpeechRecognizer sender, SpeechRecognizerAudioCaptureStateChangedEventArgs args )
		{
			Deployment.Current.Dispatcher.BeginInvoke( () =>
			{
				switch ( args.State )
				{
					case SpeechRecognizerAudioCaptureState.Inactive:
						SpeechStatus.Text = "Processing...";
						break;
					case SpeechRecognizerAudioCaptureState.Capturing:
						SpeechStatus.Text = "Listening...";
						break;
					default:
						throw new ArgumentOutOfRangeException();
				}
			} );
		}
	}
}