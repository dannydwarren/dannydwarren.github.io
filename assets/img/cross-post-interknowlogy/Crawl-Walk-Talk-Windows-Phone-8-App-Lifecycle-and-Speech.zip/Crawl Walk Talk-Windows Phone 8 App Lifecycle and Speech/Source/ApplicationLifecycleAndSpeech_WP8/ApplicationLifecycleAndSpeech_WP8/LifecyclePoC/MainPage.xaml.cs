﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using LifecyclePoC.Resources;

namespace LifecyclePoC
{
	public partial class MainPage : PhoneApplicationPage
	{
		private bool _hasState;

		// Constructor
		public MainPage()
		{
			InitializeComponent();

			// Sample code to localize the ApplicationBar
			//BuildLocalizedApplicationBar();
		}

		protected override void OnNavigatedTo( NavigationEventArgs e )
		{
			//TODO: 2.0 - OnNavigatedTo
			Debug.WriteLine( "MainPage-OnNavigatedTo - HasState: {0}", _hasState );
			//TODO: 3.0 - Initialize and set _hasState
			Initialize();
			base.OnNavigatedTo( e );
		}

		protected override void OnNavigatedFrom( NavigationEventArgs e )
		{
			//TODO: 2.1 - OnNavigatedFrom
			Debug.WriteLine( "MainPage-OnNavigatedFrom" );

			State["DataStored"] = true;

			base.OnNavigatedFrom( e );
		}

		private void Initialize()
		{
			if ( _hasState )
				return;

			//Page Specific State
			if ( State.Keys.Contains( "DataStored" ) )
			{
				Debug.WriteLine( "MainPage-Activated from being Tombstoned" ); 
			}

			_hasState = true;
		}

		private void NavigateTo2_Click( object sender, RoutedEventArgs e )
		{
			//TODO: 5.1 - Navigate to Page2
			Debug.WriteLine( "MainPage-NaviateTo2_Click" );
			NavigationService.Navigate( new Uri( @"/Page2.xaml?value=DevLink", UriKind.Relative ) );
		}


		// Sample code for building a localized ApplicationBar
		//private void BuildLocalizedApplicationBar()
		//{
		//    // Set the page's ApplicationBar to a new instance of ApplicationBar.
		//    ApplicationBar = new ApplicationBar();

		//    // Create a new button and set the text value to the localized string from AppResources.
		//    ApplicationBarIconButton appBarButton = new ApplicationBarIconButton(new Uri("/Assets/AppBar/appbar.add.rest.png", UriKind.Relative));
		//    appBarButton.Text = AppResources.AppBarButtonText;
		//    ApplicationBar.Buttons.Add(appBarButton);

		//    // Create a new menu item with the localized string from AppResources.
		//    ApplicationBarMenuItem appBarMenuItem = new ApplicationBarMenuItem(AppResources.AppBarMenuItemText);
		//    ApplicationBar.MenuItems.Add(appBarMenuItem);
		//}
	}
}