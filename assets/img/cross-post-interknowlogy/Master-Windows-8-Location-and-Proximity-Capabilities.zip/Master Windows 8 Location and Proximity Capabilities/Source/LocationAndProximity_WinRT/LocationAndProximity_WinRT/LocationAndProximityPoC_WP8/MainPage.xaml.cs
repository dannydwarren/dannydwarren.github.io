﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using LocationAndProximityPoC_WP8.FeatureWrappers;
using LocationPoC.FeatureWrappers;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using LocationAndProximityPoC_WP8.Resources;
using Windows.Devices.Geolocation;
using Windows.Networking.Proximity;
using Windows.Networking.Sockets;
using Windows.Storage.Streams;

namespace LocationAndProximityPoC_WP8
{
	public partial class MainPage : PhoneApplicationPage
	{
		// Constructor
		public MainPage()
		{
			InitializeComponent();

		}

		#region Location

		/// <summary>
		/// Invoked when this page is about to be displayed in a Frame.
		/// </summary>
		/// <param name="e">Event data that describes how this page was reached.  The Parameter
		/// property is typically used to configure the page.</param>
		protected override void OnNavigatedTo( NavigationEventArgs e )
		{
			ActivateLocationTracking();

		}

		private async void ActivateLocationTracking()
		{
			var position = await LocationWrapper.Instance.GetSingleShotLocationAsync();
			LogLocation( position );

			//LocationWrapper.Instance.LocationChanged += LocationChangedHandler;
			//LocationWrapper.Instance.ActivateContinousLocationTracking();
		}

		private void LocationChangedHandler( object sender, Geoposition e )
		{
			LogLocation( e );
		}

		private void LogLocation( Geoposition position )
		{
			if ( position == null )
			{
				return;
			}

			LocationPositions.Items.Add(
				string.Format(
					"Latitude: {1},{0}Longitude: {2},{0}Accuracy: {3},{0}Altitude: {4},{0}AltitudeAccuracy: {5},{0}Heading: {6},{0}Speed: {7}",
					Environment.NewLine,
					position.Coordinate.Latitude,
					position.Coordinate.Longitude,
				//position.CivicAddress.Country,	//CivicAddress not supported in WindowsPhone
					position.Coordinate.Accuracy,
					position.Coordinate.Altitude,
					position.Coordinate.AltitudeAccuracy,
					position.Coordinate.Heading,
					position.Coordinate.Speed ) );

			if ( LocationPositions.Items.Count == 11 )
				LocationPositions.Items.RemoveAt( 0 );
		}

		#endregion

		#region Proximity

		private static readonly string MESSAGE_TYPE = NfcWrapper.MESSAGE_TYPE_PREFIX + "LocationPoC.Message";
		private void PublishMessage_Click( object sender, RoutedEventArgs e )
		{
			NfcWrapper.Instance.StartPublishing( MESSAGE_TYPE, MessageToSend.Text );
		}

		private void StopPublishingMessage_Click( object sender, RoutedEventArgs e )
		{
			NfcWrapper.Instance.StopPublishing();
		}

		private void ReceiveMessage_Click( object sender, RoutedEventArgs e )
		{
			NfcWrapper.Instance.SubscribeForMessage( MESSAGE_TYPE,
														  value => Deployment.Current.Dispatcher.BeginInvoke(
															  () => MessageReceived.Text = value ) );
			MessageReceived.Text = "Waiting...";
		}

		private void StopRecievingMessage_Click( object sender, RoutedEventArgs e )
		{
			NfcWrapper.Instance.StopSubscribingForMessage();
		}

		#endregion

		#region PeerFinding

		private async void Peers_SelectionChanged( object sender, SelectionChangedEventArgs e )
		{
			PeerInformation peerInformation = e.AddedItems.OfType<object>().FirstOrDefault() as PeerInformation;
			if ( peerInformation != null )
			{
				await NfcWrapper.Instance.ConnectToPeer( peerInformation );
			}
		}


		private void SendSocketMessage_Click( object sender, RoutedEventArgs e )
		{
			if ( NfcWrapper.Instance.PeerSocket != null )
			{
				NfcWrapper.Instance.PeerSocket.SendMessage( SocketMessageToSend.Text );
			}
		}

		private Dictionary<string, string> _alternateIdentities = new Dictionary<string, string>
				                                                 {
					                                                 {
						                                                 "Windows",
						                                                 "439aa8f1-3234-42bb-93e7-8c0215cd6941_4c5b9g29w27se!LocationAndProximityPoC_WinRT"
					                                                 }
				                                                 };
		private void AdvertiseForPeers_Click( object sender, RoutedEventArgs e )
		{
			NfcWrapper.Instance.StateChanged -= NfcStateChanged;
			NfcWrapper.Instance.StateChanged += NfcStateChanged;
			NfcWrapper.Instance.PeersFound -= NfcPeersFound;
			NfcWrapper.Instance.PeersFound += NfcPeersFound;
			NfcWrapper.Instance.AdvertiseForPeers( "Windows Phone", true, _alternateIdentities );
		}

		private void NfcPeersFound( object sender, EventArgs<IReadOnlyList<PeerInformation>> e )
		{
			if ( e.Payload != null )
			{
				var selectedPeer = Peers.SelectedItem as PeerInformation;
				Peers.Items.Clear();
				foreach ( PeerInformation peerInfo in e.Payload )
				{
					Peers.Items.Add( peerInfo );
				}
				if ( selectedPeer != null && Peers.Items.OfType<PeerInformation>().Any( pi => pi.DisplayName == selectedPeer.DisplayName ) )
				{
					Peers.SelectedItem = Peers.Items.OfType<PeerInformation>().First( pi => pi.DisplayName == selectedPeer.DisplayName );
				}
			}
		}

		private void ListenForPeers_Click( object sender, RoutedEventArgs e )
		{
			NfcWrapper.Instance.StateChanged -= NfcStateChanged;
			NfcWrapper.Instance.StateChanged += NfcStateChanged;
			NfcWrapper.Instance.AdvertiseForPeers( "Windows Phone", false, _alternateIdentities );
		}

		private void Disconnect_Click( object sender, RoutedEventArgs e )
		{
			NfcWrapper.Instance.DisconnectAndClosePeerConnections();
		}

		private void ConnectToPeer_Click( object sender, RoutedEventArgs e )
		{
			NfcWrapper.Instance.ConnectToPeer( (PeerInformation)Peers.SelectedItem );
		}

		private void NfcStateChanged( object sender, EventArgs e )
		{
			if ( NfcWrapper.Instance.State == PeerFindingState.Connected )
			{
				WaitForMessages();
			}

			Deployment.Current.Dispatcher.BeginInvoke( () =>
														  {
															  StateTextBlock.Text = NfcWrapper.Instance.State.ToString();
														  } );
		}

		private async void WaitForMessages()
		{
			while ( NfcWrapper.Instance.State == PeerFindingState.Connected
				&& NfcWrapper.Instance.PeerSocket != null )
			{
				string message = await NfcWrapper.Instance.PeerSocket.ReceiveMessage();
				Deployment.Current.Dispatcher.BeginInvoke( () =>
												  {
													  SocketMessageReceived.Text = string.IsNullOrEmpty(message) ? string.Empty : message;
												  } );
			}
		}

		#endregion
	}
}