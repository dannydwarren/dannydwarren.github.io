using Windows.Storage;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using DAGGr.ViewModels;

namespace DAGGr.UI.WindowsStore.Helpers
{
    public static class NavigationProcessor
    {
        public static void ProcessNavigatedTo<T>(Page pageNavigatedTo, NavigationEventArgs e)
            where T : PageViewModel
        {
            bool shouldRestoreState;
            switch (e.NavigationMode)
            {
                case NavigationMode.Back:
                case NavigationMode.Forward:
                    shouldRestoreState = true;
                    break;
                case NavigationMode.New:
                case NavigationMode.Refresh:
                default:
                shouldRestoreState = false;
                    break;
                
            }

            T pageViewModel = pageNavigatedTo.DataContext as T;
            if (pageViewModel == null)
            {
                pageViewModel = ViewModelFactory.Create<T>(e.Parameter);
            }
           
            if (shouldRestoreState)
            {
                string stateKey = pageNavigatedTo.GetType().Name;
                object stateValue;
                if (ApplicationData.Current.LocalSettings.Values.TryGetValue(stateKey, out stateValue)
                    && stateValue != null)
                {
                    pageViewModel.ApplyState(stateValue.ToString());
                }
            }

            pageNavigatedTo.DataContext = pageViewModel;
        }

        public static void ProcessNavigatedFrom(Page pageNavigatedFrom)
        {
            var pageStateProvider = pageNavigatedFrom.DataContext as PageViewModel;

            if (pageStateProvider != null)
            {
                ApplicationData.Current.LocalSettings.Values[pageNavigatedFrom.GetType().Name] 
                    = pageStateProvider.GetState();
            }
        }
    }
}