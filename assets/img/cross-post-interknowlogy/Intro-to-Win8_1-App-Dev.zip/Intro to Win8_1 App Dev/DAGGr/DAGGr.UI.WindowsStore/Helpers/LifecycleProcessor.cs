﻿using System;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.Storage;
using Windows.UI.Xaml.Controls;

namespace DAGGr.UI.WindowsStore.Helpers
{
    public static class LifecycleProcessor
    {
        private static readonly string NAVIGATION_STATE_KEY = "NAVIGATION_STATE_KEY";
        private static readonly string TIME_OF_LAST_USE_STATE_KEY = "TIME_OF_LAST_USE_STATE_KEY";

        public static void ProcessLaunched(Frame frame, LaunchActivatedEventArgs e)
        {
            if (e.PreviousExecutionState == ApplicationExecutionState.Terminated)
            {
                //TODO: 4.1 - Load state from previously suspended application
                //  Restore TIME_OF_LAST_USE_STATE_KEY
                //  if lastUse + 10 seconds > DateTime.Now then restore NAVIGATION_STATE_KEY to Frame.SetNavigationState()
                bool shouldDataBeRestored = false;
                object timeOfLastUseStateObject;
                if (ApplicationData.Current.LocalSettings.Values.TryGetValue(TIME_OF_LAST_USE_STATE_KEY, out timeOfLastUseStateObject)
                    && timeOfLastUseStateObject != null)
                {
                    DateTime lastUse = DateTime.Parse(timeOfLastUseStateObject.ToString());
#if DEBUG
                    if (lastUse.AddSeconds(10) > DateTime.Now)
#else
                    if (lastUse.AddHours(12) > DateTime.Now)
#endif
                    {
                        shouldDataBeRestored = true;
                    }
                }

                if (shouldDataBeRestored)
                {
                    object navigationStateObject;
                    if (ApplicationData.Current.LocalSettings.Values.TryGetValue(NAVIGATION_STATE_KEY,
                        out navigationStateObject)
                        && navigationStateObject != null)
                    {
                        frame.SetNavigationState(navigationStateObject.ToString());
                    }
                }
            }
        }

        public static void ProcessSuspended(Frame frame, SuspendingEventArgs e)
        {
            ApplicationData.Current.LocalSettings.Values[TIME_OF_LAST_USE_STATE_KEY] = DateTime.Now.ToString();//Remember only primitive objects can be used here
            ApplicationData.Current.LocalSettings.Values[NAVIGATION_STATE_KEY] = frame.GetNavigationState();
        }
    }
}