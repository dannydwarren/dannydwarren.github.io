﻿using Windows.UI.Xaml.Controls;

// The User Control item template is documented at http://go.microsoft.com/fwlink/?LinkId=234236

namespace DAGGr.UI.WindowsStore.Controls
{
    public sealed partial class GameSelector : UserControl
    {
        public GameSelector()
        {
            this.InitializeComponent();
        }
    }
}
