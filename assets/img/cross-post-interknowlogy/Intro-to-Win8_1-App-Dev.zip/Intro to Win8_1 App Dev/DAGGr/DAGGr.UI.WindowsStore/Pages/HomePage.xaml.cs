﻿using System;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238
using Windows.UI.Xaml.Navigation;
using DAGGr.UI.WindowsStore.Helpers;
using DAGGr.ViewModels;

namespace DAGGr.UI.WindowsStore.Pages
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class HomePage : Page
    {
        public HomePage()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            NavigationProcessor.ProcessNavigatedTo<HomeVM>(this, e);

            base.OnNavigatedTo(e);
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            NavigationProcessor.ProcessNavigatedFrom(this);

            base.OnNavigatedFrom(e);
        }

        private void SinglesMatchClick(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(SinglesMatchPage));
        }
       
        private void DoublesMatchClick(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(DoublesMatchPage));
        }

        private void HistoryClick(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(HistoryPage));
        }

        private void PlayerStatisticsClick(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(PlayerStatisticsPage));
        }
    }
}
