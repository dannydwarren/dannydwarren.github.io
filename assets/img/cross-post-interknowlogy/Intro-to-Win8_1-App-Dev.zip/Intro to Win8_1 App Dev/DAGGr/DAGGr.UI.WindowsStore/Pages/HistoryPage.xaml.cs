﻿using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238
using Windows.UI.Xaml.Navigation;
using DAGGr.UI.WindowsStore.Helpers;
using DAGGr.ViewModels;

namespace DAGGr.UI.WindowsStore.Pages
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class HistoryPage : Page
    {
        public HistoryPage()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            NavigationProcessor.ProcessNavigatedTo<HistoryVM>(this, e);

            base.OnNavigatedTo(e);
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            NavigationProcessor.ProcessNavigatedFrom(this);

            base.OnNavigatedFrom(e);
        }

        private void BackClick(object sender, RoutedEventArgs e)
        {
            Frame.GoBack();
        }
    }
}
