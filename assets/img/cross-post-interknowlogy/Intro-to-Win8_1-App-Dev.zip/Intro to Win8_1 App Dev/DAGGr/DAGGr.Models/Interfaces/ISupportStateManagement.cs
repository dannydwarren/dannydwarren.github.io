﻿namespace DAGGr.Models.Interfaces
{
    public interface ISupportStateManagement
    {
        string GetState();
        void ApplyState(string state);
    }
}