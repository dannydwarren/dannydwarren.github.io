﻿using Newtonsoft.Json;

namespace DAGGr.ViewModels
{
    public class HistoryVM : PageViewModel
    {
        public override void Initialize(object parameter)
        {

        }

        public override string GetState()
        {
            var state = new HistoryVMState
            {

            };

            return JsonConvert.SerializeObject(state);
        }

        public override void ApplyState(string state)
        {
            ApplyState(JsonConvert.DeserializeObject<HistoryVMState>(state));
        }

        private void ApplyState(HistoryVMState state)
        {

        }
    }

    public class HistoryVMState
    {
    }
}