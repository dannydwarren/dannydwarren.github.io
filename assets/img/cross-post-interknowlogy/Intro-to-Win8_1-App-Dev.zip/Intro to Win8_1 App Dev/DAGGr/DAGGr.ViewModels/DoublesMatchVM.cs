﻿using Newtonsoft.Json;

namespace DAGGr.ViewModels
{
    public class DoublesMatchVM : PageViewModel
    {
        public override void Initialize(object parameter)
        {

        }

        public override string GetState()
        {
            var state = new DoublesMatchVMState
            {
                
            };

            return JsonConvert.SerializeObject(state);
        }

        public override void ApplyState(string state)
        {
            ApplyState(JsonConvert.DeserializeObject<DoublesMatchVMState>(state));
        }

        private void ApplyState(DoublesMatchVMState state)
        {

        }
    }

    public class DoublesMatchVMState
    {

    }
}