﻿using Newtonsoft.Json;

namespace DAGGr.ViewModels
{
    public class PlayerStatisticsVM : PageViewModel
    {
        public override void Initialize(object parameter)
        {

        }

        public override string GetState()
        {
            var state = new PlayerStatisticsVMState
            {

            };

            return JsonConvert.SerializeObject(state);
        }

        public override void ApplyState(string state)
        {
            ApplyState(JsonConvert.DeserializeObject<PlayerStatisticsVMState>(state));
        }

        private void ApplyState(PlayerStatisticsVMState state)
        {

        }
    }

    public class PlayerStatisticsVMState
    {
    }
}