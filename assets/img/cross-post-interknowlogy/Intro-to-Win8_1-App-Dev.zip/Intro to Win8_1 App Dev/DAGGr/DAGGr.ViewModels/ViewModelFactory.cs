﻿using System;

namespace DAGGr.ViewModels
{
    public static class ViewModelFactory
    {
        public static T Create<T>(object parameter)
            where T : PageViewModel
        {
            T vmInstance = Activator.CreateInstance<T>();
            vmInstance.Initialize(parameter);
            return vmInstance;
        }
    }
}