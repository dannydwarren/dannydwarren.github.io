﻿using Newtonsoft.Json;

namespace DAGGr.ViewModels
{
    public class SinglesMatchVM : PageViewModel
    {
        public override void Initialize(object parameter)
        {

        }

        public override string GetState()
        {
            var state = new SinglesMatchVMState
            {

            };

            return JsonConvert.SerializeObject(state);
        }

        public override void ApplyState(string state)
        {
            ApplyState(JsonConvert.DeserializeObject<SinglesMatchVMState>(state));
        }

        private void ApplyState(SinglesMatchVMState state)
        {

        }
    }

    public class SinglesMatchVMState
    {
    }
}