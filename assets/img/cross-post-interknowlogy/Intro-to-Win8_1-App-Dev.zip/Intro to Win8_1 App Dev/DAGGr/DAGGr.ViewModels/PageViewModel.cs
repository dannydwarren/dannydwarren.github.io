﻿using DAGGr.Models.Interfaces;

namespace DAGGr.ViewModels
{
    public abstract class PageViewModel : ISupportStateManagement
    {
        public abstract void Initialize(object parameter);
        public abstract string GetState();
        public abstract void ApplyState(string state);
    }
}