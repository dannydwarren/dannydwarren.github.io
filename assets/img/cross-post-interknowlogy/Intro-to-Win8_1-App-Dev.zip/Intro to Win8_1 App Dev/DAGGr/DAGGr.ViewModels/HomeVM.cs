﻿using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace DAGGr.ViewModels
{
    public class HomeVM : PageViewModel
    {
        public override void Initialize(object parameter)
        {

        }

        public override string GetState()
        {
            var state = new HomeVMState
            {

            };

            return JsonConvert.SerializeObject(state);
        }

        public override void ApplyState(string state)
        {
            ApplyState(JsonConvert.DeserializeObject<HomeVMState>(state));
        }

        private void ApplyState(HomeVMState state)
        {

        }
    }

    public class HomeVMState
    {
    }
}