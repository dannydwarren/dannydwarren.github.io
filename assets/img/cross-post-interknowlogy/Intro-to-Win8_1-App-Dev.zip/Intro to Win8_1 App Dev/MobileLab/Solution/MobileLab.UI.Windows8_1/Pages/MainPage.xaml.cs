﻿using Windows.UI.Xaml.Controls;

namespace MobileLab.UI.Windows8_1.Pages
{

    //TODO: 1.0 - Set Properties/Debug/"Do not launch, but debug my code when it starts"
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void SimpleNavigationAndAppLifecycleSampleClick(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            //TODO: 1.1 - Navigate To TextPage
            Frame.Navigate(typeof (TextPage));
        }
    }
}
