﻿using Microsoft.Phone.Controls;

namespace MobileLab.UI.WindowsPhone8.Pages
{
    public partial class MainPage : PhoneApplicationPage
    {
        //NOTE: Update the Navigation Page value in Properties/WMAppManifest.xml to Pages\MainPage.xaml where Pages is the folder containing MainPage.xaml.

        public MainPage()
        {
            InitializeComponent();
        }
    }
}