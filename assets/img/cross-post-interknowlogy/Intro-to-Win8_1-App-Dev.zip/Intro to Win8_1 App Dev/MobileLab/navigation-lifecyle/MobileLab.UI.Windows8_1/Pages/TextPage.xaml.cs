﻿using System;
using Windows.Storage;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

namespace MobileLab.UI.Windows8_1.Pages
{
    public sealed partial class TextPage : Page
    {
        public TextPage()
        {
            this.InitializeComponent();
        }

        string PAGE_STATE_KEY = "TEXT_PAGE_STATE_KEY";
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            //TODO: 2.0 - Override OnNavigatedTo
            //  if new or refresh then don't restore state
            //  else if back or forward restore state
            //  if restoring state set DesiredTextBox.Text with saved text

            #region Solution
            //bool pageShouldRestoreState;
            //switch (e.NavigationMode)
            //{
            //    case NavigationMode.New:
            //     case NavigationMode.Refresh:
            //        pageShouldRestoreState = false;
            //        break;
            //    case NavigationMode.Back:
            //    case NavigationMode.Forward:
            //        pageShouldRestoreState = true;
            //        break;
            //    default:
            //        pageShouldRestoreState = false;
            //        break;
            //}

            //if (pageShouldRestoreState)
            //{
            //    object stateValue;
            //    if (ApplicationData.Current.LocalSettings.Values.TryGetValue(PAGE_STATE_KEY, out stateValue)
            //        && stateValue != null)
            //    {
            //        DesiredTextBox.Text = stateValue.ToString();
            //    }
            //} 
            #endregion

            base.OnNavigatedTo(e);
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            //TODO: 2.1 - Override OnNavigatingFrom
            //  if DesiredTextBox.Text has a value then persist that value
            
            #region Solution
            //if (!string.IsNullOrEmpty(DesiredTextBox.Text))
            //{
            //    ApplicationData.Current.LocalSettings.Values[PAGE_STATE_KEY] = DesiredTextBox.Text;
            //} 
            #endregion

            base.OnNavigatedFrom(e);
        }

        private void BackClick(object sender, RoutedEventArgs e)
        {
            //TODO: 2.2 - Navigate Back if possible
            
            #region Solution
            //if (Frame.CanGoBack)
            //{
            //    Frame.GoBack();
            //} 
            #endregion
        }

        private void NavigationSampleClick(object sender, RoutedEventArgs e)
        {
            //TODO: 2.3 - Navigate to TextPage2 passing DesiredTextBox.Text as the parameter
            
            #region Solution
            //Frame.Navigate(typeof (TextPage2), DesiredTextBox.Text); 
            #endregion
        }
    }
}
