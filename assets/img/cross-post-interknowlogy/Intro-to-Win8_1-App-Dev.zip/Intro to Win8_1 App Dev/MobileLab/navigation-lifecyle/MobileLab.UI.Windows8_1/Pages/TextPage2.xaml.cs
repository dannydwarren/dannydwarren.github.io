﻿using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238
using Windows.UI.Xaml.Navigation;

namespace MobileLab.UI.Windows8_1.Pages
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class TextPage2 : Page
    {
        public TextPage2()
        {
            this.InitializeComponent();
        }


        //TODO: 3.0 - Copy OnNavigatedTo from TextPage.xaml
        //  Change PAGE_STATE_KEY to match this page name
        //  Set NavigationParameter.Text to saved state or e.Parameter
        
        #region Solution
        //string PAGE_STATE_KEY = "TEXT_PAGE2_STATE_KEY";
        //protected override void OnNavigatedTo(NavigationEventArgs e)
        //{
        //    bool pageShouldRestoreState;
        //    switch (e.NavigationMode)
        //    {
        //        case NavigationMode.New:
        //        case NavigationMode.Refresh:
        //            pageShouldRestoreState = false;
        //            break;
        //        case NavigationMode.Back:
        //        case NavigationMode.Forward:
        //            pageShouldRestoreState = true;
        //            break;
        //        default:
        //            pageShouldRestoreState = false;
        //            break;
        //    }

        //    if (pageShouldRestoreState)
        //    {
        //        object stateValue;
        //        if (ApplicationData.Current.LocalSettings.Values.TryGetValue(PAGE_STATE_KEY, out stateValue)
        //            && stateValue != null)
        //        {
        //            NavigationParameter.Text = stateValue.ToString();
        //        }
        //    }
        //    else
        //    {
        //        if (e.Parameter != null)
        //        {
        //            NavigationParameter.Text = e.Parameter.ToString();
        //        }
        //    }

        //    base.OnNavigatedTo(e);
        //} 
        #endregion

        //TODO: 3.1 - Copy OnNavigatedTo from TextPage.xaml
        //  if NavigationParameter.Text exists persist it
        
        #region Solution
        //protected override void OnNavigatedFrom(NavigationEventArgs e)
        //{
        //    if (!string.IsNullOrEmpty(NavigationParameter.Text))
        //    {
        //        ApplicationData.Current.LocalSettings.Values[PAGE_STATE_KEY] = NavigationParameter.Text;
        //    }

        //    base.OnNavigatedFrom(e);
        //} 
        #endregion

        private void BackClick(object sender, RoutedEventArgs e)
        {
            //TODO: 3.2 - Navigate Back if possible
            
            #region Solution
            //if (Frame.CanGoBack)
            //{
            //    Frame.GoBack();
            //} 
            #endregion
        }
    }
}
