﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace BasicControls
{
	/// <summary>
	/// An empty page that can be used on its own or navigated to within a Frame.
	/// </summary>
	public sealed partial class SemanticZoomIntro : Page
	{
		public SemanticZoomIntro()
		{
			this.InitializeComponent();

			InitializeColoredDateTimes();
		}

		/// <summary>
		/// Invoked when this page is about to be displayed in a Frame.
		/// </summary>
		/// <param name="e">Event data that describes how this page was reached.  The Parameter
		/// property is typically used to configure the page.</param>
		protected override void OnNavigatedTo( NavigationEventArgs e )
		{
			//TODO: Create 2 Views in XAML
			//TODO: In Class Question: Does it matter if the view is shared? Does it matter if references are the same?
			//ZoomedOutView.ItemsSource = ColoredDateTimesGroupedByColor.View.CollectionGroups; 
			//ZoomedInView.ItemsSource = ColoredDateTimesGroupedByColor.View;
		}

		//TODO: Initialize Collection -> Create 10+ new with Random Colors and increase Date by a day for each
		private void InitializeColoredDateTimes()
		{
			//TODO: Create CVS -> GroupBy Color Then OrderBy Color
		}

	}

	public class ColoredDateTime
	{
		//TODO: DateTime, SortColor, ColorBrush
	}
}
