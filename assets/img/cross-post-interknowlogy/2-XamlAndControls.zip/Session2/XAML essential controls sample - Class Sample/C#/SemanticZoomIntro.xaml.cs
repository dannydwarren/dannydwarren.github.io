﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace BasicControls
{
	/// <summary>
	/// An empty page that can be used on its own or navigated to within a Frame.
	/// </summary>
	public sealed partial class SemanticZoomIntro : Page
	{
		private Random _rand = new Random();
		private List<ColoredDateTime> _coloredDateTimes = new List<ColoredDateTime>();

		public SemanticZoomIntro()
		{
			this.InitializeComponent();

			InitializeColoredDateTimes();
		}

		public CollectionViewSource ColoredDateTimesGroupedByColor { get; set; }

		/// <summary>
		/// Invoked when this page is about to be displayed in a Frame.
		/// </summary>
		/// <param name="e">Event data that describes how this page was reached.  The Parameter
		/// property is typically used to configure the page.</param>
		protected override void OnNavigatedTo( NavigationEventArgs e )
		{
			ZoomedOutView.ItemsSource = ColoredDateTimesGroupedByColor.View.CollectionGroups;
			ZoomedInView.ItemsSource = ColoredDateTimesGroupedByColor.View;
		}

		private void InitializeColoredDateTimes()
		{
			int minColorIndex = 0;
			int maxColorIndex = Enum.GetValues( typeof( SortColor ) ).Length;
			DateTime dateTime = DateTime.Now;
			for ( int i = 0; i < 30; i++ )
			{
				_coloredDateTimes.Add( new ColoredDateTime()
										 {
											 DateTime = dateTime.AddDays( i ),
											 SortColor = (SortColor)_rand.Next( minColorIndex, maxColorIndex ),
										 } );
			}

			IGrouping<SortColor, ColoredDateTime>[] sortedGroupedColoredDateTimes = _coloredDateTimes.GroupBy( c => c.SortColor )
									 .OrderBy( g => g.Key.ToString() ).ToArray();

			ColoredDateTimesGroupedByColor = new CollectionViewSource()
												 {
													 IsSourceGrouped = true,
													 Source = sortedGroupedColoredDateTimes,
												 };

			Debug.WriteLine( String.Format( "ItemCount {0}", sortedGroupedColoredDateTimes.SelectMany(g=>g).Count() ) ); 
		}
	}

	public class ColoredDateTime
	{
		public DateTime DateTime { get; set; }
		public SortColor SortColor { get; set; }

		public SolidColorBrush ColorBrush
		{
			get
			{
				Color color;
				switch ( SortColor )
				{
					case SortColor.Green:
						color = Colors.Green;
						break;
					case SortColor.Yellow:
						color = Colors.Yellow;
						break;
					case SortColor.Red:
						color = Colors.Red;
						break;
					case SortColor.Blue:
						color = Colors.Blue;
						break;
					case SortColor.Purple:
						color = Colors.Purple;
						break;
					case SortColor.Orange:
						color = Colors.Orange;
						break;
					default:
						color = Colors.Black;
						break;
				}

				return new SolidColorBrush( color );
			}
		}
	}

	public enum SortColor
	{
		Green,
		Yellow,
		Red,
		Blue,
		Purple,
		Orange,
	}
}
