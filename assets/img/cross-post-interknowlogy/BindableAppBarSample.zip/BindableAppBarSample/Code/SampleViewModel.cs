﻿using System;
using System.Diagnostics;

namespace BindableAppBarSample.Code
{
	public class SampleViewModel : Bindable
	{
		private Random _random = new Random();

		public SampleViewModel()
		{
			ChangeTextCommand = new DelegateCommand<object>(ChangeTextExecutedHandler, ChangeTextCanExecuteHandler);
			ChangeNumberCommand = new DelegateCommand<object>(ChangeNumberExecutedHandler, ChangeNumberCanExecuteHandler);
			ToggleCanChangeNumberCommand = new DelegateCommand<object>(ToggleCanChangeNumberExecutedHandler, ToggleCanChangeNumberCanExecuteHandler);
			HideToggleCommand = new DelegateCommand<object>(HideToggleExecutedHandler, HideToggleCanExecuteHandler);
			ShowToggleCommand = new DelegateCommand<object>(ShowToggleExecutedHandler, ShowToggleCanExecuteHandler);
			ChangeTextMenuCommand = new DelegateCommand<object>( ChangeTextMenuExecutedHandler, ChangeTextMenuCanExecuteHandler );

			RefreshCommands();
		}

		private string _textCommandHeader = "Text";
		public string TextCommandHeader
		{
			[DebuggerStepThrough]
			get { return _textCommandHeader; }
			set
			{
				if (value != _textCommandHeader)
				{
					_textCommandHeader = value;
					OnPropertyChanged("TextCommandHeader");
				}
			}
		}
		

		private string _text = "Hello World";
		public string Text
		{
			[DebuggerStepThrough]
			get { return _text; }
			set
			{
				if (value != _text)
				{
					_text = value;
					OnPropertyChanged("Text");
				}
			}
		}

		private int _number;
		public int Number
		{
			[DebuggerStepThrough]
			get { return _number; }
			set
			{
				if (value != _number)
				{
					_number = value;
					OnPropertyChanged("Number");
				}
			}
		}

		private bool _canChangeNumber = true;
		public bool CanChangeNumber
		{
			[DebuggerStepThrough]
			get { return _canChangeNumber; }
			set
			{
				if (value != _canChangeNumber)
				{
					_canChangeNumber = value;
					OnPropertyChanged("CanChangeNumber");
					RefreshCommands();
				}
			}
		}

		private bool _canToggleCanChangeNumber = true;
		public bool CanToggleCanChangeNumber
		{
			[DebuggerStepThrough]
			get { return _canToggleCanChangeNumber; }
			set
			{
				if (value != _canToggleCanChangeNumber)
				{
					_canToggleCanChangeNumber = value;

					OnPropertyChanged("CanToggleCanChangeNumber");

					// Set after this property notifies it is changed to perserve order in app bar (order is not handled in app bar yet)
					if (_canToggleCanChangeNumber)
					{
						// always hide first otherwise you risk getting an exception of too many items in the app bar (the phone app bar only allows 4 items)
						CanShow = false;
						CanHide = true;
					}
					else
					{
						// always hide first otherwise you risk getting an exception of too many items in the app bar (the phone app bar only allows 4 items)
						CanHide = false;
						CanShow = true;
					}
				}
			}
		}

		private bool _canHide = true;
		public bool CanHide
		{
			[DebuggerStepThrough]
			get { return _canHide; }
			set
			{
				if (value != _canHide)
				{
					_canHide = value;
					OnPropertyChanged("CanHide");
				}
			}
		}

		private bool _canShow;
		public bool CanShow
		{
			[DebuggerStepThrough]
			get { return _canShow; }
			set
			{
				if (value != _canShow)
				{
					_canShow = value;
					OnPropertyChanged("CanShow");
				}
			}
		}
		
		public DelegateCommand<object> ChangeTextCommand { get; private set; }
		private bool ChangeTextCanExecuteHandler(object arg)
		{
			return true;
		}
		private void ChangeTextExecutedHandler(object arg)
		{
			Text = DateTime.Now.ToString();
		}

		public DelegateCommand<object> ChangeNumberCommand { get; private set; }
		private bool ChangeNumberCanExecuteHandler(object arg)
		{
			return CanChangeNumber;
		}
		private void ChangeNumberExecutedHandler(object arg)
		{
			Number++;
		}

		public DelegateCommand<object> ToggleCanChangeNumberCommand { get; private set; }
		private bool ToggleCanChangeNumberCanExecuteHandler(object arg)
		{
			return CanToggleCanChangeNumber;
		}
		private void ToggleCanChangeNumberExecutedHandler(object arg)
		{
			CanChangeNumber = !CanChangeNumber;
			RefreshCommands();
		}

		public DelegateCommand<object> HideToggleCommand { get; private set; }
		private bool HideToggleCanExecuteHandler(object arg)
		{
			return CanHide;
		}
		private void HideToggleExecutedHandler(object arg)
		{
			CanToggleCanChangeNumber = false;
			RefreshCommands();
		}

		public DelegateCommand<object> ShowToggleCommand { get; private set; }
		private bool ShowToggleCanExecuteHandler(object arg)
		{
			return CanShow;
		}
		private void ShowToggleExecutedHandler(object arg)
		{
			CanToggleCanChangeNumber = true;
			RefreshCommands();
		}

		public DelegateCommand<object> ChangeTextMenuCommand { get; private set; }
		private bool ChangeTextMenuCanExecuteHandler(object arg)
		{
			return true;
		}
		private void ChangeTextMenuExecutedHandler(object arg)
		{
			Text = _random.Next().ToString();
		}

		private void RefreshCommands()
		{
			ChangeTextCommand.RaiseCanExecuteChanged();
			ChangeNumberCommand.RaiseCanExecuteChanged();
			ToggleCanChangeNumberCommand.RaiseCanExecuteChanged();
			HideToggleCommand.RaiseCanExecuteChanged();
			ShowToggleCommand.RaiseCanExecuteChanged();
		}
	}
}