﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace BindableAppBarSample.Code
{
	public class BindableApplicationBar : FrameworkElement
	{
		private readonly IApplicationBar _applicationBar;
		private static readonly double OPACITY_DEFAULT = .999;

		public BindableApplicationBar()
		{
			_applicationBar = new ApplicationBar { Opacity = OPACITY_DEFAULT };
			ButtonDelegates = new List<ApplicationBarIconButtonDelegate>();
			MenuItemDelegates = new List<ApplicationBarMenuItemDelegate>();
			BindingOperations.SetBinding(this, DataContextWatcherProperty, new Binding());
		}

		#region BindableApplicationBar (Attached Property)
		public static readonly DependencyProperty BindableApplicationBarProperty =
		  DependencyProperty.RegisterAttached("BindableApplicationBar", typeof(BindableApplicationBar), typeof(BindableApplicationBar),
											  new PropertyMetadata(null, BindableApplicationBarPropertyChanged));

		public static void SetBindableApplicationBar(DependencyObject d, BindableApplicationBar value)
		{
			d.SetValue(BindableApplicationBarProperty, value);
		}

		public static BindableApplicationBar GetBindableApplicationBar(DependencyObject d)
		{
			return (BindableApplicationBar)d.GetValue(BindableApplicationBarProperty);
		}

		private static void BindableApplicationBarPropertyChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			var page = sender as PhoneApplicationPage;
			if (page != null)
			{
				var bindableApplicationBar = e.NewValue as BindableApplicationBar;
				if (bindableApplicationBar != null)
				{
					bindableApplicationBar.Initialize(page.DataContext);
					page.ApplicationBar = bindableApplicationBar._applicationBar;
				}
			}
		}
		#endregion

		#region DataContextWatcher (Dependency Property)
		public static readonly DependencyProperty DataContextWatcherProperty =
		  DependencyProperty.Register("DataContextWatcher", typeof(object), typeof(BindableApplicationBar),
			new PropertyMetadata(null, OnDataContextWatcherChanged));

		private static void OnDataContextWatcherChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((BindableApplicationBar)d).OnDataContextWatcherChanged(e);
		}

		private void OnDataContextWatcherChanged(DependencyPropertyChangedEventArgs e)
		{
			Initialize(e.NewValue);
		}
		#endregion

		#region IsVisible (Dependency Property)
		public static readonly DependencyProperty IsVisibleProperty =
		  DependencyProperty.Register("IsVisible", typeof(bool), typeof(BindableApplicationBar),
			new PropertyMetadata(false, OnIsVisibleChanged));

		public bool IsVisible
		{
			get { return (bool)GetValue(IsVisibleProperty); }
			set { SetValue(IsVisibleProperty, value); }
		}

		private static void OnIsVisibleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((BindableApplicationBar)d).OnIsVisibleChanged(e);
		}

		private void OnIsVisibleChanged(DependencyPropertyChangedEventArgs e)
		{
			_applicationBar.IsVisible = (bool)e.NewValue;
		}
		#endregion

		#region Opacity (Dependency Property)
		public static readonly DependencyProperty OpacityProperty =
		  DependencyProperty.Register("Opacity", typeof(double), typeof(BindableApplicationBar),
			new PropertyMetadata(OPACITY_DEFAULT, OnOpacityChanged));

		public double Opacity
		{
			get { return (double)GetValue(OpacityProperty); }
			set { SetValue(OpacityProperty, value); }
		}

		private static void OnOpacityChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((BindableApplicationBar)d).OnOpacityChanged(e);
		}

		private void OnOpacityChanged(DependencyPropertyChangedEventArgs e)
		{
			_applicationBar.Opacity = (double)e.NewValue;
		}
		#endregion

		#region IsMenuEnabled (Dependency Property)
		public static readonly DependencyProperty IsMenuEnabledProperty =
		  DependencyProperty.Register("IsMenuEnabled", typeof(bool), typeof(BindableApplicationBar),
			new PropertyMetadata(true, OnIsMenuEnabledChanged));

		public bool IsMenuEnabled
		{
			get { return (bool)GetValue(IsMenuEnabledProperty); }
			set { SetValue(IsMenuEnabledProperty, value); }
		}

		private static void OnIsMenuEnabledChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((BindableApplicationBar)d).OnIsMenuEnabledChanged(e);
		}

		private void OnIsMenuEnabledChanged(DependencyPropertyChangedEventArgs e)
		{
			_applicationBar.IsMenuEnabled = (bool)e.NewValue;
		}
		#endregion

		#region BackgroundColor (Dependency Property)
		public static readonly DependencyProperty BackgroundColorProperty =
		  DependencyProperty.Register("BackgroundColor", typeof(Color), typeof(BindableApplicationBar),
			new PropertyMetadata(Colors.Black, OnBackgroundColorChanged));

		public Color BackgroundColor
		{
			get { return (Color)GetValue(BackgroundColorProperty); }
			set { SetValue(BackgroundColorProperty, value); }
		}

		private static void OnBackgroundColorChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((BindableApplicationBar)d).OnBackgroundColorChanged(e);
		}

		private void OnBackgroundColorChanged(DependencyPropertyChangedEventArgs e)
		{
			_applicationBar.BackgroundColor = (Color)e.NewValue;
		}
		#endregion

		#region ForegroundColor (Dependency Property)
		public static readonly DependencyProperty ForegroundColorProperty =
		  DependencyProperty.Register("ForegroundColor", typeof(Color), typeof(BindableApplicationBar),
			new PropertyMetadata(Colors.White, OnForegroundColorChanged));

		public Color ForegroundColor
		{
			get { return (Color)GetValue(ForegroundColorProperty); }
			set { SetValue(ForegroundColorProperty, value); }
		}

		private static void OnForegroundColorChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((BindableApplicationBar)d).OnForegroundColorChanged(e);
		}

		private void OnForegroundColorChanged(DependencyPropertyChangedEventArgs e)
		{
			_applicationBar.ForegroundColor = (Color)e.NewValue;
		}
		#endregion

		#region Mode (Dependency Property)
		public static readonly DependencyProperty ModeProperty =
		  DependencyProperty.Register("Mode", typeof(ApplicationBarMode), typeof(BindableApplicationBar),
			new PropertyMetadata(ApplicationBarMode.Default, OnModeChanged));

		public ApplicationBarMode Mode
		{
			get { return (ApplicationBarMode)GetValue(ModeProperty); }
			set { SetValue(ModeProperty, value); }
		}

		private static void OnModeChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((BindableApplicationBar)d).OnModeChanged(e);
		}

		private void OnModeChanged(DependencyPropertyChangedEventArgs e)
		{
			_applicationBar.Mode = (ApplicationBarMode)e.NewValue;
		}
		#endregion

		public List<ApplicationBarIconButtonDelegate> ButtonDelegates { get; set; }

		public List<ApplicationBarMenuItemDelegate> MenuItemDelegates { get; set; }

		private void Initialize(object dataContext)
		{
			if (DataContext == dataContext)
			{
				return;
			}

			DataContext = dataContext;

			foreach (var buttonDelegate in ButtonDelegates)
			{
				buttonDelegate.DataContext = DataContext;
				if (buttonDelegate.IsVisible)
				{
					AddAppBarButton(buttonDelegate.Button);
				}
				buttonDelegate.IsVisibleChanged += AppBarButtonIsVisibleChangedHandler;
			}

			foreach (var menuItemDelegate in MenuItemDelegates)
			{
				menuItemDelegate.DataContext = DataContext;
				if (menuItemDelegate.IsVisible)
				{
					AddAppBarMenuItem(menuItemDelegate.MenuItem);
				}
				menuItemDelegate.IsVisibleChanged += AppBarMenuItemIsVisibleChangedHandler;
			}

			UpdateAppBarVisibility();
		}

		private void AppBarButtonIsVisibleChangedHandler(object sender, EventArgs e)
		{
			var buttonDelegate = sender as ApplicationBarIconButtonDelegate;
			if (buttonDelegate != null)
			{
				if (buttonDelegate.IsVisible)
				{
					AddAppBarButton(buttonDelegate.Button);
				}
				else
				{
					RemoveAppBarButton(buttonDelegate.Button);
				}
				UpdateAppBarVisibility();
			}
		}

		private void AppBarMenuItemIsVisibleChangedHandler(object sender, EventArgs e)
		{
			var menuItemDelegate = sender as ApplicationBarMenuItemDelegate;
			if (menuItemDelegate != null)
			{
				if (menuItemDelegate.IsVisible)
				{
					AddAppBarMenuItem(menuItemDelegate.MenuItem);
				}
				else
				{
					RemoveAppBarMenuItem(menuItemDelegate.MenuItem);
				}
				UpdateAppBarVisibility();
			}
		}

		private void AddAppBarButton(ApplicationBarIconButton button)
		{
			bool isVisible = _applicationBar.Buttons.Contains(button);
			if (!isVisible)
			{
				_applicationBar.Buttons.Add(button);
			}
		}

		private void AddAppBarMenuItem(ApplicationBarMenuItem menuItem)
		{
			bool isVisible = _applicationBar.MenuItems.Contains(menuItem);
			if (!isVisible)
			{
				_applicationBar.MenuItems.Add(menuItem);
			}
		}

		private void RemoveAppBarButton(ApplicationBarIconButton button)
		{
			bool isVisible = _applicationBar.Buttons.Contains(button);
			if (isVisible)
			{
				_applicationBar.Buttons.Remove(button);
			}
		}
		
		private void RemoveAppBarMenuItem(ApplicationBarMenuItem menuItem)
		{
			bool isVisible = _applicationBar.MenuItems.Contains(menuItem);
			if (isVisible)
			{
				_applicationBar.MenuItems.Remove(menuItem);
			}
		}

		private void UpdateAppBarVisibility()
		{
			if (_applicationBar.Buttons.Count > 0 || _applicationBar.MenuItems.Count > 0)
			{
				IsVisible = true;
				Mode = _applicationBar.Buttons.Count == 0 ? ApplicationBarMode.Minimized : ApplicationBarMode.Default;
			}
			else
			{
				IsVisible = false;
			}
	}
	}
}