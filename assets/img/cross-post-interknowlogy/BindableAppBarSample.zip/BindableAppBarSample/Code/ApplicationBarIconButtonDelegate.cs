using System;
using System.Windows;
using System.Windows.Input;
using Microsoft.Phone.Shell;

namespace BindableAppBarSample.Code
{
	public class ApplicationBarIconButtonDelegate : FrameworkElement
	{
		#region Fields

		private static readonly Uri DEFAULT_ICON_URI = new Uri("", UriKind.RelativeOrAbsolute);

		#endregion

		#region Construction

		public ApplicationBarIconButtonDelegate()
		{
			Button = new ApplicationBarIconButton { IconUri = DEFAULT_ICON_URI };
			Button.Click += ClickHandler;
		}

		#endregion

		#region Events

		public event EventHandler IsVisibleChanged;
		private void OnIsVisibleChanged()
		{
			var handler = IsVisibleChanged;
			if (handler != null) handler(this, EventArgs.Empty);
		}

		public event EventHandler Click;
		private void OnClick(EventArgs e)
		{
			var handler = Click;
			if (handler != null) handler(this, e);
		}

		#endregion

		#region Properties

		#region IconUri (Dependency Property)
		public static readonly DependencyProperty IconUriProperty =
			DependencyProperty.Register("IconUri", typeof(Uri), typeof(ApplicationBarIconButtonDelegate),
										new PropertyMetadata(DEFAULT_ICON_URI, OnIconUriChanged));

		public Uri IconUri
		{
			get { return (Uri)GetValue(IconUriProperty); }
			set { SetValue(IconUriProperty, value); }
		}

		private static void OnIconUriChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((ApplicationBarIconButtonDelegate)d).OnIconUriChanged(e);
		}

		private void OnIconUriChanged(DependencyPropertyChangedEventArgs e)
		{
			Button.IconUri = IconUri;
		}
		#endregion

		#region Text (Dependency Property)
		public static readonly DependencyProperty TextProperty =
			DependencyProperty.Register("Text", typeof(string), typeof(ApplicationBarIconButtonDelegate),
										new PropertyMetadata("temp", OnTextChanged));

		public string Text
		{
			get { return (string)GetValue(TextProperty); }
			set { SetValue(TextProperty, value); }
		}

		private static void OnTextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((ApplicationBarIconButtonDelegate)d).OnTextChanged(e);
		}

		private void OnTextChanged(DependencyPropertyChangedEventArgs e)
		{
			Button.Text = Text;
		}
		#endregion

		#region IsVisible (Dependency Property)
		public static readonly DependencyProperty IsVisibleProperty =
			DependencyProperty.Register("IsVisible", typeof(bool), typeof(ApplicationBarIconButtonDelegate),
										new PropertyMetadata(true, OnIsVisibleChanged));

		public bool IsVisible
		{
			get { return (bool)GetValue(IsVisibleProperty); }
			set { SetValue(IsVisibleProperty, value); }
		}

		private static void OnIsVisibleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((ApplicationBarIconButtonDelegate)d).OnIsVisibleChanged(e);
		}

		private void OnIsVisibleChanged(DependencyPropertyChangedEventArgs e)
		{
			OnIsVisibleChanged();
		}
		#endregion

		#region IsEnabled (Dependency Property)
		public static readonly DependencyProperty IsEnabledProperty =
			DependencyProperty.Register("IsEnabled", typeof(bool), typeof(ApplicationBarIconButtonDelegate),
										new PropertyMetadata(true, OnIsEnabledChanged));

		public bool IsEnabled
		{
			get { return (bool)GetValue(IsEnabledProperty); }
			set { SetValue(IsEnabledProperty, value); }
		}

		private static void OnIsEnabledChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((ApplicationBarIconButtonDelegate)d).OnIsEnabledChanged(e);
		}

		private void OnIsEnabledChanged(DependencyPropertyChangedEventArgs e)
		{
			Button.IsEnabled = IsEnabled;
		}
		#endregion

		#region Command (Dependency Property)
		public static readonly DependencyProperty CommandProperty =
			DependencyProperty.Register("Command", typeof(ICommand), typeof(ApplicationBarIconButtonDelegate),
										new PropertyMetadata(null, OnCommandChanged));

		public ICommand Command
		{
			get { return (ICommand)GetValue(CommandProperty); }
			set { SetValue(CommandProperty, value); }
		}

		private static void OnCommandChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((ApplicationBarIconButtonDelegate)d).OnCommandChanged(e);
		}

		private void OnCommandChanged(DependencyPropertyChangedEventArgs e)
		{
			if (Command != null)
			{
				Command.CanExecuteChanged += CanExecuteChangedHandler;
			}

			var oldCommand = e.OldValue as ICommand;
			if (oldCommand != null)
			{
				oldCommand.CanExecuteChanged -= CanExecuteChangedHandler;
			}
		}

		#endregion

		#region CommandParameter (Dependency Property)
		public static readonly DependencyProperty CommandParameterProperty =
		  DependencyProperty.Register("CommandParameter", typeof(object), typeof(ApplicationBarIconButtonDelegate),
			new PropertyMetadata(null, OnCommandParameterChanged));

		public object CommandParameter
		{
			get { return (object)GetValue(CommandParameterProperty); }
			set { SetValue(CommandParameterProperty, value); }
		}

		private static void OnCommandParameterChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			((ApplicationBarIconButtonDelegate)d).OnCommandParameterChanged(e);
		}

		private void OnCommandParameterChanged(DependencyPropertyChangedEventArgs e)
		{
			if (Command != null)
			{
				IsEnabled = Command.CanExecute(CommandParameter);
			}
		}
		#endregion

		public ApplicationBarIconButton Button { get; private set; }

		#endregion

		#region Private Methods

		private void CanExecuteChangedHandler(object sender, EventArgs e)
		{
			IsEnabled = Command.CanExecute(CommandParameter);
		}

		private void ClickHandler(object sender, EventArgs e)
		{
			if (Command != null && Command.CanExecute(CommandParameter))
			{
				Command.Execute(CommandParameter);
			}
			OnClick(e);
		}

		#endregion
	}
}