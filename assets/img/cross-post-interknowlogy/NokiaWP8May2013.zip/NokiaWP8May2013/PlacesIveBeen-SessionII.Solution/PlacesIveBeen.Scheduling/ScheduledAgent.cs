﻿#define DEBUG_AGENT

using System;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using Microsoft.Phone.Scheduler;
using Microsoft.Phone.Shell;

namespace PlacesIveBeen.Scheduling
{
	public class ScheduledAgent : ScheduledTaskAgent
	{
		/// <remarks>
		/// ScheduledAgent constructor, initializes the UnhandledException handler
		/// </remarks>
		static ScheduledAgent()
		{
			// Subscribe to the managed exception handler
			Deployment.Current.Dispatcher.BeginInvoke( delegate
			{
				Application.Current.UnhandledException += UnhandledException;
			} );
		}

		/// Code to execute on Unhandled Exceptions
		private static void UnhandledException( object sender, ApplicationUnhandledExceptionEventArgs e )
		{
			if ( Debugger.IsAttached )
			{
				// An unhandled exception has occurred; break into the debugger
				Debugger.Break();
			}
		}

		/// <summary>
		/// Agent that runs a scheduled task
		/// </summary>
		/// <param name="task">
		/// The invoked task
		/// </param>
		/// <remarks>
		/// This method is called when a periodic or resource intensive task is invoked
		/// </remarks>
		protected override void OnInvoke( ScheduledTask task )
		{
			//TODO: 6.1 - ScheduledAgent.cs.OnInvoke Discuss illegal APIs including referenced libraries

			/*
			 * Illegal APIs reference:
			 *	http://msdn.microsoft.com/en-us/library/windowsphone/develop/hh202962(v=vs.105).aspx
			 * 
			 * Notes for this app
			 *	Can't create tiles
			 *	Can't reference libaries that perform illegal APIs (problematic)
			 * 
			 */
			

			//TODO: 6.2 - ScheduledAgent.cs update main tile
			/*
			 * Create the desired tile data (IconicTileData)
			 * Set values Title, Count, WideContent1 and 2 and 3, SmallIconImage, and IconImage
			 *	SmallIconImage:  "Assets/Tiles/IconicTileSmall.png", UriKind.Relative
			 *	IconImage: "Assets/Tiles/IconicTileMediumLarge.png", UriKind.Relative
			 *	
			 * Call UpdateOrCreateTile with the tile data.
			 * 
			 */

			IconicTileData iconicTileData = new IconicTileData()
			{
				Title = "Where I've Been",
				Count = new Random().Next( 100 ),
				WideContent1 = "Location Invitation",
				WideContent2 = "Joe Somebody",
				WideContent3 = "New York City, NY",
				SmallIconImage = new Uri( "Assets/Tiles/IconicTileSmall.png", UriKind.Relative ),
				IconImage = new Uri( "Assets/Tiles/IconicTileMediumLarge.png", UriKind.Relative ),
			};

			UpdateOrCreateTile( iconicTileData );

			//TODO: 6.3 - ScheduledAgent.cs create NotifyViaToast (method)
			/*
			 * In new method NotifyViaToast()
			 * 
			 * Create ShellToast
			 *	Title: Where I've Been
			 *	Content: New Location Invitation
			 *	NavigationUri: "/Pages/PlacesPage.xaml", UriKind.Relative
			 * 
			 * Call toast.Show()
			 */
			NotifyViaToast();

			//TODO: 6.4 - ScheduledAgent.cs enable easy debugging
			/*
			 * Add #define DEBUG_AGENT as first line of file
			 * Add #if DEBUG_AGENT block below this comment
			 * 
			 * Add code in #if block:
			 *	ScheduledActionService.LaunchForTest( task.Name, TimeSpan.FromSeconds( 60 ) );
			 *	NOTE: The TimeSpan cannot be less than 60 sec. If it is, then it is ignored
			 */
#if DEBUG_AGENT
			ScheduledActionService.LaunchForTest( task.Name, TimeSpan.FromSeconds( 60 ) );
#endif

			NotifyComplete();
		}

		private void NotifyViaToast()
		{
			ShellToast toast = new ShellToast
				                   {
					                   Title = "Where I've Been",
									   Content = "New Location Invitation",
									   NavigationUri = new Uri("/Pages/PlacesPage.xaml", UriKind.Relative)
				                   };

			toast.Show();
		}

		private void UpdateOrCreateTile(  ShellTileData tileData )
		{
			//TODO: 6.3 - ScheduledAgent.cs Implement UpdateOrCreateTile
			/*
			 * Get the main live tile for the app (which always exists) ShellTile.ActiveTiles.First()
			 * Call Update on that tile and pass in the tileData
			 * 
			 */

			ShellTile mainTile = ShellTile.ActiveTiles.First();
			mainTile.Update( tileData );
		}

	}
}