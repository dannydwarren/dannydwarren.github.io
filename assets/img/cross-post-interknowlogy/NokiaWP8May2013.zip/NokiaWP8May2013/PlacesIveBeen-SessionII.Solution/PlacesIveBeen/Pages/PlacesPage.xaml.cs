﻿using System;
using System.Linq;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using PlacesIveBeen.ViewModels;

namespace PlacesIveBeen.Pages
{
	public partial class PlacesPage : PhoneApplicationPage
	{
		public PlacesPage()
		{
			InitializeComponent();
			DataContext = new PlacesVM();
			PlacesVM.Initialize();
			PlacesVM.SelectedPlaceChanged += PlacesVM_SelectedPlaceChanged;
			this.ApplicationBar.Buttons.OfType<ApplicationBarIconButton>().First( b => b.Text == "edit" ).IsEnabled = PlacesVM.SelectedPlace != null;	//EditButton.IsEnabled = false;
		}

		void PlacesVM_SelectedPlaceChanged( object sender, EventArgs e )
		{
			//EditButton.IsEnabled = false;
			this.ApplicationBar.Buttons.OfType<ApplicationBarIconButton>().First( b => b.Text == "edit" ).IsEnabled = PlacesVM.SelectedPlace != null;
		}

		public PlacesVM PlacesVM { get { return (PlacesVM)DataContext; } }

		private void AddClickHandler( object sender, EventArgs e )
		{
			NavigationService.Navigate( new Uri( @"/Pages/PlaceManagementPage.xaml", UriKind.Relative ) );
		}

		private void EditClickHandler( object sender, EventArgs e )
		{
			if ( PlacesVM.SelectedPlace != null )
			{
				NavigationService.Navigate(
					new Uri( string.Format( @"/Pages/PlaceManagementPage.xaml?id={0}", PlacesVM.SelectedPlace.Id ), UriKind.Relative ) );
			}
		}
	}
}