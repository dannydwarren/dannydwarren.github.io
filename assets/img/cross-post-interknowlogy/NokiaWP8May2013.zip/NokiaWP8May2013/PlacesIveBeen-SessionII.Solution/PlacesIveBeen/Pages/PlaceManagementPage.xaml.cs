﻿using System;
using System.Linq;
using System.Windows;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using PlacesIveBeen.Models;
using PlacesIveBeen.ViewModels;

namespace PlacesIveBeen.Pages
{
	public partial class PlaceManagementPage : PhoneApplicationPage
	{
		public static readonly string PLACE_MANAGEMENT_PAGE_STATE_KEY = "PLACE_MANAGEMENT_PAGE_STATE_KEY";
		private bool _hasState;

		public PlaceManagementPage()
		{
			InitializeComponent();

			DataContext = new PlaceManagementVM();

		}

		public PlaceManagementVM ManagementVM { get { return (PlaceManagementVM)DataContext; } }

		protected override void OnNavigatedTo( System.Windows.Navigation.NavigationEventArgs e )
		{
			if (_hasState)
			{
				State.Remove(PLACE_MANAGEMENT_PAGE_STATE_KEY);
				base.OnNavigatedTo( e );
				return;
			}

			bool isNew = true;

			object state;
			if (State.TryGetValue(PLACE_MANAGEMENT_PAGE_STATE_KEY, out state))
			{
				State.Remove( PLACE_MANAGEMENT_PAGE_STATE_KEY );
				var placeManagementVMState = (PlaceManagementVMState)state;
				ManagementVM.Initialize( placeManagementVMState );
				isNew = placeManagementVMState.IsNew;
			}
			else
			{
				string placeIdString;
				Guid placeId = Guid.Empty;
				if (NavigationContext.QueryString.TryGetValue("id", out placeIdString))
				{
					placeId = Guid.Parse(placeIdString);
					isNew = false;
				}

				ManagementVM.Initialize(placeId);
			}
			
			_hasState = true;
			
			//TODO: 5.5 - PlaceManagementPage.xaml disable pin to start for new places
			this.ApplicationBar.MenuItems.OfType<ApplicationBarMenuItem>().First( b => b.Text == "pin to start" ).IsEnabled = !isNew;

			base.OnNavigatedTo( e );
		}

		protected override void OnNavigatedFrom( System.Windows.Navigation.NavigationEventArgs e )
		{
			State.Add( new System.Collections.Generic.KeyValuePair<string, object>( PLACE_MANAGEMENT_PAGE_STATE_KEY, ManagementVM.GetState() ) );

			base.OnNavigatedFrom( e );
		}

		private void SaveClickHandler( object sender, EventArgs e )
		{
			this.Focus();
			ManagementVM.PersistChanges();
			NavigationService.GoBack();
		}

		private void EnableSecondaryIconicTileClickHandler( object sender, EventArgs eventArgs )
		{
			//TODO: 5.3 - PlaceManagementPage.cs enable secondary tile
			/*
			 * Create the desired tile data (IconicTileData)
			 * Set values Title, WideContent1 and 2 (and opt 3), SmallIconImage, and IconImage
			 *	NOTE: Images are the same values from the main tile
			 * 
			 * Call UpdateOrCreateTile with a const secondary tile id and the tile data.
			 * 
			 */
			IconicTileData iconicTileData = new IconicTileData()
			{
				Title = "Where I've Been",
				WideContent1 = ManagementVM.PlaceToEdit.Name,
				WideContent2 = ManagementVM.PlaceToEdit.Coordinate,
				WideContent3 = "In this beautiful place you will find some amazing places and things to do.",
				SmallIconImage = new Uri( "Assets/Tiles/IconicTileSmall.png", UriKind.Relative ),
				IconImage = new Uri( "Assets/Tiles/IconicTileMediumLarge.png", UriKind.Relative ),
			};

			UpdateOrCreateTile( ManagementVM.PlaceToEdit.Id.ToString(), iconicTileData );
		}

		private void UpdateOrCreateTile( string placeId, ShellTileData tileData )
		{
			//TODO: 5.4 - PlaceManagementPage.cs Implement UpdateOrCreateTile
			/*
			 * Loop through all ShellTile.ActiveTiles to find the tile that matches the navigation path we want to update
			 * If the tile we want to update does not exist
			 *	Then create that tile via ShellTile.Create
			 *		navigationUri: string.Format( "/PlaceManagementPage.xaml?id={0}", placeId ), UriKind.Relative
			 *		initialData: tileData
			 *		supportsWideTile: true - without this we will get an exception because WideContent# is set.
			 * Else
			 *	Call .Update() on the found tile with the tileData passed in 
			 * 
			 */

			ShellTile tileToUpdate =
				ShellTile.ActiveTiles.FirstOrDefault( t => t.NavigationUri.OriginalString.Contains( placeId ) );

			if ( tileToUpdate == null )
			{
				ShellTile.Create( new Uri( string.Format( "/Pages/PlaceManagementPage.xaml?id={0}", placeId ), UriKind.Relative ),
								 tileData, true );
			}
			else
			{
				tileToUpdate.Update( tileData );
			}
		}

	}
}