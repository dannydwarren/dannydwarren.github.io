﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Serialization;
using System.Windows;
using PlacesIveBeen.Data;
using PlacesIveBeen.FeatureWrappers;
using PlacesIveBeen.Models;
using Windows.Devices.Geolocation;

namespace PlacesIveBeen.ViewModels
{
	public class PlaceManagementVM : Bindable
	{
		private bool _isNew;
		private Place _originalPlace;

		private Place _placeToEdit;
		public Place PlaceToEdit
		{
			[DebuggerStepThrough]
			get { return _placeToEdit; }
			private set
			{
				if ( value == _placeToEdit )
					return;

				_placeToEdit = value;
				OnPropertyChanged();
			}
		}

		//TODO: 2.0 - PlaceManagementVM add IsAcquiringLocation prop (bool)

		private bool _isAcquiringLocation;
		public bool IsAcquiringLocation
		{
			[DebuggerStepThrough]
			get { return _isAcquiringLocation; }
			set
			{
				if ( value == _isAcquiringLocation )
					return;

				_isAcquiringLocation = value;
				OnPropertyChanged();
			}
		}

		public void Initialize( Guid placeId )
		{
			Place originalPlace = DataProvider.Instance.Places.FirstOrDefault( p => p.Id == placeId );
			if ( originalPlace != null )
			{
				_originalPlace = originalPlace;
				PlaceToEdit = new Place( originalPlace.GetState() );
			}
			else
			{
				//TODO: 2.1 - PlaceManagementVM refactor editing new Place

				/*Old Code*/
				//_isNew = true;
				//PlaceToEdit = new Place();
				/*End Old Code*/

				PrepareNewPlaceForEdit();
			}
		}

		private async void PrepareNewPlaceForEdit()
		{
			/*Moved Code*/
			_isNew = true;
			PlaceToEdit = new Place();
			/*End Moved Code*/

			/*
			 * This method should use the async key word
			 * 
			 * Before using LocationWrapper set IsAcquiringLocation to true
			 * 
			 * Use the LocationWrapper.GetSingleShotLocationAsync() to get the users current geoposition (await the response)
			 * If the returned geoposition is not null then set PlaceToEdit.Coordinate using the geoposition.Coordinate data
			 * 
			 * After setting PlaceToEdit.Coordinate set IsAcquiringLocation to false
			 * 
			 */

			IsAcquiringLocation = true;
			Geoposition geoposition = await LocationWrapper.Instance.GetSingleShotLocationAsync();
			if (geoposition != null)
			{
				PlaceToEdit.Coordinate = string.Format("Lat: {0}, Long: {1}", geoposition.Coordinate.Latitude, geoposition.Coordinate.Longitude);
			}
			IsAcquiringLocation = false;
		}

		public void Initialize( PlaceManagementVMState state )
		{
			ApplyState( state );
		}

		public void PersistChanges()
		{
			if ( _isNew )
			{
				DataProvider.Instance.Places.Add( PlaceToEdit );
			}
			else
			{
				_originalPlace.ApplyState( PlaceToEdit.GetState() );
			}

			if ( !DataProvider.Instance.SaveChanges() )
			{
				MessageBox.Show( "Saving failed." );
			}
		}

		public PlaceManagementVMState GetState()
		{
			return new PlaceManagementVMState
					   {
						   PlaceState = PlaceToEdit.GetState(),
						   IsNew = _isNew
					   };
		}

		public void ApplyState( PlaceManagementVMState state )
		{
			if ( state.IsNew )
			{
				_isNew = true;
			}
			else
			{
				_originalPlace = DataProvider.Instance.Places.First( p => p.Id == state.PlaceState.Id );
			}

			PlaceToEdit = new Place( state.PlaceState );
		}
	}

	[DataContract]
	public class PlaceManagementVMState
	{
		[DataMember]
		public PlaceState PlaceState { get; set; }

		[DataMember]
		public bool IsNew { get; set; }
	}
}