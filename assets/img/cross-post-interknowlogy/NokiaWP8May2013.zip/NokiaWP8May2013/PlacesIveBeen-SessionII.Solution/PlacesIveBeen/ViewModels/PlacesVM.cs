﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using PlacesIveBeen.Data;
using PlacesIveBeen.Models;

namespace PlacesIveBeen.ViewModels
{
	public class PlacesVM : Bindable
	{
		public event EventHandler SelectedPlaceChanged = delegate { };
		private void OnSelectedPlaceChanged()
		{
			SelectedPlaceChanged( this, EventArgs.Empty );
		}

		private ObservableCollection<Place> _places;
		public ObservableCollection<Place> Places
		{
			[DebuggerStepThrough]
			get { return _places; }
			set
			{
				if ( value == _places )
					return;

				_places = value;
				OnPropertyChanged();
			}
		}

		private Place _selectedPlace;
		public Place SelectedPlace
		{
			[DebuggerStepThrough]
			get { return _selectedPlace; }
			set
			{
				if ( value == _selectedPlace )
					return;

				_selectedPlace = value;
				OnPropertyChanged();
				OnSelectedPlaceChanged();
			}
		}

		public void Initialize()
		{
			Places = DataProvider.Instance.Places;
		}
	}
}