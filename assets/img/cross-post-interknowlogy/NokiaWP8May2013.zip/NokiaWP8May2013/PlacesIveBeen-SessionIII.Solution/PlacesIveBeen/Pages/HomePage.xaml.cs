﻿#define DEBUG_AGENT

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Scheduler;
using Microsoft.Phone.Shell;

namespace PlacesIveBeen.Pages
{
	public partial class HomePage : PhoneApplicationPage
	{
		public HomePage()
		{
			InitializeComponent();
		}

		private void AllClickHandler( object sender, RoutedEventArgs e )
		{
			NavigationService.Navigate( new System.Uri( @"/Pages/PlacesPage.xaml", System.UriKind.Relative ) );
		}

		private void AddClickHandler( object sender, RoutedEventArgs e )
		{
			NavigationService.Navigate( new System.Uri( @"/Pages/PlaceManagementPage.xaml", System.UriKind.Relative ) );
		}

		private void EnableIconicTileClickHandler( object sender, RoutedEventArgs e )
		{
			IconicTileData iconicTileData = new IconicTileData()
			{
				Title = "Where I've Been",
				Count = new Random().Next( 10 ),
				WideContent1 = "Location Invitation",
				WideContent2 = "Danny Warren",
				WideContent3 = "Nokia in San Diego, CA",
				SmallIconImage = new Uri( "Assets/Tiles/IconicTileSmall.png", UriKind.Relative ),
				IconImage = new Uri( "Assets/Tiles/IconicTileMediumLarge.png", UriKind.Relative ),
			};

			UpdateOrCreateTile( "/", iconicTileData );

			StartTileUpdaterTask();
		}

		private void UpdateOrCreateTile( string tileId, ShellTileData tileData )
		{
			ShellTile tileToUpdate =
				ShellTile.ActiveTiles.FirstOrDefault( t => t.NavigationUri.OriginalString.Contains( tileId ) );

			if ( tileToUpdate == null )
			{
				//NOTE: The main tile always exists, even if it's not pinned, so we don't need to worry about reaching this code for the main tile.
				ShellTile.Create( new Uri( string.Format( "/HomePage.xaml?id={0}", tileId ), UriKind.Relative ),
								 tileData, true );
			}
			else
			{
				tileToUpdate.Update( tileData );
			}
		}

		private static readonly string TILE_UPDATER_TASK_NAME = "TILE_UPDATER_TASK_NAME";
		private void StartTileUpdaterTask()
		{
			PeriodicTask existingTileUpdaterTask = ScheduledActionService.Find( TILE_UPDATER_TASK_NAME ) as PeriodicTask;
			if ( existingTileUpdaterTask != null )
			{
				try
				{
					ScheduledActionService.Remove( TILE_UPDATER_TASK_NAME );
				}
				catch ( Exception ex )
				{
					//NOTE: Exceptions during removal are unimportant
				}
			}

			PeriodicTask newTileUpdaterTask = new PeriodicTask( TILE_UPDATER_TASK_NAME )
												  {
													  Description = "Updates main tile.",
													  ExpirationTime = DateTime.Now.AddDays( 14 ),
												  };

			try
			{
				ScheduledActionService.Add( newTileUpdaterTask );

#if(DEBUG_AGENT)
				ScheduledActionService.LaunchForTest( TILE_UPDATER_TASK_NAME, TimeSpan.FromSeconds( 60 ) );
#endif
			}
			catch ( InvalidOperationException exception )
			{
				if ( exception.Message.Contains( "BNS Error: The action is disabled" ) )
				{
					MessageBox.Show( "Background agents for this application have been disabled by the user." );
				}

				if ( exception.Message.Contains( "BNS Error: The maximum number of ScheduledActions of this type have already been added." ) )
				{
					// No user action required. The system prompts the user when the hard limit of periodic tasks has been reached.
				}
			}
			catch ( SchedulerServiceException )
			{
				// No user action required.
			}
		}

	}
}