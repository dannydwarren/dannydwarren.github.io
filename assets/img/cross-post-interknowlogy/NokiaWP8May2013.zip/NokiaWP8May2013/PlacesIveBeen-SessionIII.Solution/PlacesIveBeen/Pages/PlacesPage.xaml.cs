﻿using System;
using System.Linq;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using PlacesIveBeen.ViewModels;

namespace PlacesIveBeen.Pages
{
	public partial class PlacesPage : PhoneApplicationPage
	{
		public PlacesPage()
		{
			InitializeComponent();
			DataContext = new PlacesVM();
			PlacesVM.Initialize();
			PlacesVM.SelectedPlaceChanged += PlacesVM_SelectedPlaceChanged;
			this.ApplicationBar.Buttons.OfType<ApplicationBarIconButton>().First( b => b.Text == "edit" ).IsEnabled = PlacesVM.SelectedPlace != null;	//EditButton.IsEnabled = false;
			//TODO: 4.3 - PlacesPage.xaml.cs disabled share menu button if SelectedPlace is null
			this.ApplicationBar.MenuItems.OfType<ApplicationBarMenuItem>().First( b => b.Text == "Share" ).IsEnabled = PlacesVM.SelectedPlace != null;	//EditButton.IsEnabled = false;
		}

		void PlacesVM_SelectedPlaceChanged( object sender, EventArgs e )
		{
			this.ApplicationBar.Buttons.OfType<ApplicationBarIconButton>().First( b => b.Text == "edit" ).IsEnabled = PlacesVM.SelectedPlace != null;
			//TODO: 4.4 - PlacesPage.xaml.cs disabled share menu button if SelectedPlace is null
			this.ApplicationBar.MenuItems.OfType<ApplicationBarMenuItem>().First( b => b.Text == "Share" ).IsEnabled = PlacesVM.SelectedPlace != null;
		}

		public PlacesVM PlacesVM { get { return (PlacesVM)DataContext; } }

		private void AddClickHandler( object sender, EventArgs e )
		{
			NavigationService.Navigate( new Uri( @"/Pages/PlaceManagementPage.xaml", UriKind.Relative ) );
		}

		private void EditClickHandler( object sender, EventArgs e )
		{
			if ( PlacesVM.SelectedPlace != null )
			{
				NavigationService.Navigate(
					new Uri( string.Format( @"/Pages/PlaceManagementPage.xaml?id={0}", PlacesVM.SelectedPlace.Id ), UriKind.Relative ) );
			}
		}

		private void ToggleShareClickHandler(object sender, EventArgs e)
		{
			//TODO: 4.1 - PlacesPage.xaml.cs Implement ToggleShareClickHandler
			/*
			 * If PlacesVM.SelectedPlace is null return
			 * 
			 * -Treat the shareButton as a toggle-
			 * Cast sender as an ApplicationBarMenuItem named shareButton
			 * if shareButton.Text == Share
			 *	set shareButton.Text to Stop Sharing
			 *	call PlacesVM.ShareSelectedPlace()
			 * else
			 *	set shareButton.Text back to Share
			 *	call PlacesVM.StopSharingSelectedPlace()
			 * 
			 */

			if (PlacesVM.SelectedPlace == null)
			{
				return;
			}

			var shareButton = (ApplicationBarMenuItem)sender;
			if ( shareButton.Text == "Share" )
			{
				shareButton.Text = "Stop Sharing";
				PlacesVM.ShareSelectedPlace();
			}
			else
			{
				shareButton.Text = "Share";
				PlacesVM.StopSharingSelectedPlace();
			}
		}

		private void ToggleReceiveClickHandler(object sender, EventArgs e)
		{
			//TODO: 4.2 - PlacesPage.xaml.cs Implement ToggleReceiveClickHandler
			/*
			 * -Treat the recieveButton as a toggle-
			 * Cast sender as an ApplicationBarMenuItem named receiveButton
			 * if receiveButton.Text == Receive
			 *	set receiveButton.Text to Stop Receiving
			 *	call PlacesVM.SubscribeForSharedPlace()
			 * else
			 *	set receiveButton.Text back to Recieve
			 *	call PlacesVM.StopSubscribingForSharedPlace()
			 * 
			 */

			var receiveButton = (ApplicationBarMenuItem)sender;
			if ( receiveButton.Text == "Receive")
			{
				receiveButton.Text = "Stop Receiving";
				PlacesVM.SubscribeForSharedPlace();
			}
			else
			{
				receiveButton.Text = "Receive";
				PlacesVM.StopSubscribingForSharedPlace();
			}

		}
	}
}