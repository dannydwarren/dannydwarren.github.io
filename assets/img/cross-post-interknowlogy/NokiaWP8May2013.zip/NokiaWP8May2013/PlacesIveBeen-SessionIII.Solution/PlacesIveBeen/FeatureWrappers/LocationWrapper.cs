﻿using System;
using System.IO.IsolatedStorage;
using System.Threading.Tasks;
using System.Windows;
using Windows.Devices.Geolocation;
using Windows.Foundation;

namespace PlacesIveBeen.FeatureWrappers
{
	public class LocationWrapper
	{
		private static readonly string USER_ALLOWS_LOCATION_KEY = "USER_ALLOWS_LOCATION_KEY";

		private LocationWrapper()
		{

		}

		private static LocationWrapper _instance;
		public static LocationWrapper Instance
		{
			get
			{
				if ( _instance == null )
					_instance = new LocationWrapper();
				return _instance;
			}
		}

		/// <summary>
		/// NOTE: Return value will be null if the user does not allow location or if location services are disabled.
		/// </summary>
		/// <returns>Geoposition</returns>
		public async Task<Geoposition> GetSingleShotLocationAsync()
		{
			if ( !CheckIfUserAllowsLocation() )
			{
				if ( !RequestPermissionToUseLocation() )
				{
					return null;
				}
			}

			Geolocator geolocator = new Geolocator
							  {
								  DesiredAccuracyInMeters = 50
							  };


			Geoposition geoposition = null;

			try
			{
				geoposition = await geolocator.GetGeopositionAsync( maximumAge: TimeSpan.FromSeconds( 1 ),
																	timeout: TimeSpan.FromSeconds( 10 ) );
			}
			catch ( Exception ex )
			{
				if ( (uint)ex.HResult == 0x80004004 )
				{
					MessageBox.Show( "Location is disabled in phone settings." );
				}
			}

			return geoposition;
		}

		public bool RequestPermissionToUseLocation()
		{
			/*
			 * A simple MessageBox prompt will suffice
			 * Save the result in IsolatedStorageSettings.ApplicationSettings
			 */

			MessageBoxResult result = MessageBox.Show( "This app accesses your phone's location. Is that OK?", "Location",
													  MessageBoxButton.OKCancel );

			bool userAllowsLocation = result == MessageBoxResult.OK;

			IsolatedStorageSettings.ApplicationSettings[USER_ALLOWS_LOCATION_KEY] = userAllowsLocation;
			IsolatedStorageSettings.ApplicationSettings.Save();

			return userAllowsLocation;
		}

		public bool CheckIfUserAllowsLocation()
		{
			/*
			 * Try to get the value out of IsolatedStorageSettings.ApplicationSettings
			 * By using TryGetValue the boolean stored will either be retrieved or will return false
			 *	NOTE: We'll need to prompt the user for permission if false
			 */

			bool userAllowsLocation;
			IsolatedStorageSettings.ApplicationSettings.TryGetValue( USER_ALLOWS_LOCATION_KEY, out userAllowsLocation );

			return userAllowsLocation;
		}

		public string ConvertGeocoordinateToAddress()
		{
			//http://dev.virtualearth.net/REST/v1/Locations/47.64054,-122.12934?o=xml&key=BingMapsKey
			throw new NotImplementedException();
		}
	}
}
