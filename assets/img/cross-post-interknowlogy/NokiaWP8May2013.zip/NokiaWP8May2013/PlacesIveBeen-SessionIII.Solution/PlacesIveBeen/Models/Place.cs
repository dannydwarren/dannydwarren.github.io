﻿using System;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace PlacesIveBeen.Models
{
	public class Place : Bindable
	{
		public Place()
		{
			Id = Guid.NewGuid();
		}

		public Place( PlaceState state )
		{
			Id = state.Id;
			ApplyState( state );
		}

		public Guid Id { get; private set; }

		private string _name;
		public string Name
		{
			[DebuggerStepThrough]
			get { return _name; }
			set
			{
				if ( value == _name )
					return;

				_name = value;
				OnPropertyChanged();
			}
		}

		private string _notes;
		public string Notes
		{
			[DebuggerStepThrough]
			get { return _notes; }
			set
			{
				if ( value == _notes )
					return;

				_notes = value;
				OnPropertyChanged();
			}
		}

		private string _coordinate;
		public string Coordinate
		{
			[DebuggerStepThrough]
			get { return _coordinate; }
			set
			{
				if ( value == _coordinate )
					return;

				_coordinate = value;
				OnPropertyChanged();
			}
		}

		public PlaceState GetState()
		{
			return new PlaceState
					   {
						   Id = Id,
						   Name = Name,
						   Notes = Notes,
						   Coordinate = Coordinate,
					   };
		}

		public void ApplyState( PlaceState state )
		{
			Name = state.Name;
			Notes = state.Notes;
			Coordinate = state.Coordinate;
		}
	}

	[DataContract]
	public class PlaceState
	{
		[DataMember]
		public Guid Id { get; set; }
		[DataMember]
		public string Name { get; set; }
		[DataMember]
		public string Notes { get; set; }
		[DataMember]
		public string Coordinate { get; set; }
	}
}
