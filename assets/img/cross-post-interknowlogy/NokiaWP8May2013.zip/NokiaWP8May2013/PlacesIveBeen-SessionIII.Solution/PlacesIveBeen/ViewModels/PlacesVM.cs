﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using PlacesIveBeen.Data;
using PlacesIveBeen.FeatureWrappers;
using PlacesIveBeen.Models;
using Windows.UI.Core;

namespace PlacesIveBeen.ViewModels
{
	public class PlacesVM : Bindable
	{
		public event EventHandler SelectedPlaceChanged = delegate { };
		private void OnSelectedPlaceChanged()
		{
			SelectedPlaceChanged( this, EventArgs.Empty );
		}

		private ObservableCollection<Place> _places;
		public ObservableCollection<Place> Places
		{
			[DebuggerStepThrough]
			get { return _places; }
			set
			{
				if ( value == _places )
					return;

				_places = value;
				OnPropertyChanged();
			}
		}

		private Place _selectedPlace;
		public Place SelectedPlace
		{
			[DebuggerStepThrough]
			get { return _selectedPlace; }
			set
			{
				if ( value == _selectedPlace )
					return;

				_selectedPlace = value;
				OnPropertyChanged();
				OnSelectedPlaceChanged();
			}
		}

		public void Initialize()
		{
			Places = DataProvider.Instance.Places;
		}

		public void ShareSelectedPlace()
		{
			//TODO: 3.0 - PlacesVM.cs Share SelectedPlace
			//TODO: P.6 - PlacesVM.cs Share SelectedPlace - How to share (MessageType example)
			/*
			 * if SelectedPlace is null or ProximityWrapper.Instance.ProximityStatus not Idle 
 			 *	Show a message box and state that the app failed to share
			 *	return
			 * 
			 * Using the Instance of ProximityWrapper call StartPublishing
			 *	messageType: string.Concat( ProximityWrapper.MESSAGE_TYPE_PREFIX, "PlacesIveBeen.", typeof( PlaceState ).Name )
			 *		ProximityWrapper.MESSAGE_TYPE_PREFIX is required
			 *		PlacesIveBeen is the name of the app and it is suggested it is used for publishing
			 *		typeof(PlaceState).Name because we are sending a serialized obj across the wire it is 
			 *			suggested the obj type name is used in the messageType to help clarify what data is coming across the wire
			 *	value: SelectedPlace.GetState() 
			 *		use PlaceState because that is what is serializable Place is not serializable
			 *		
			 * if ProximityWrapper.Instance.ProximityStatus is Publishing
			 *	Show a message box and state that the app is sharing
			 * else
			 *	Show a message box and state that the app failed to share
			 */

			if ( SelectedPlace == null
				|| ProximityWrapper.Instance.ProximityStatus != ProximityStatus.Idle )
			{
				MessageBox.Show( "Failed to share." );
				return;
			}

			ProximityWrapper.Instance.StartPublishing(
				string.Concat( ProximityWrapper.MESSAGE_TYPE_PREFIX, "PlacesIveBeen.", typeof( PlaceState ).Name ),
				SelectedPlace.GetState() );

			if ( ProximityWrapper.Instance.ProximityStatus == ProximityStatus.Publishing )
			{
				MessageBox.Show( string.Format( "Tap to share location {0}.", SelectedPlace.Name ) );
			}
			else
			{
				MessageBox.Show( "Failed to share." );
			}
		}

		public void StopSharingSelectedPlace()
		{
			//TODO: 3.1 - PlacesVM.cs Stop Sharing SelectedPlace
			/*
			 * Using the Instance of ProximityWrapper call StopPublishing
			 * 
			 */

			ProximityWrapper.Instance.StopPublishing();
		}

		public void SubscribeForSharedPlace()
		{
			//TODO: 3.2 - PlacesVM.cs Subscribe for Shared Place
			/*
			 * if ProximityWrapper.Instance.ProximityStatus is Idle
			 *	Using the Instance of ProximityWrapper call SubscribeForMessage<PlaceState>()
			 *		messageType: Use the same messageType from ShareSelectedPlace() above
			 *		messageReceivedCallback: ReceivedSharedPlace()
			 * 
			 * if ProximityWrapper.Instance.ProximityStatus is Subscribed
			 *	Show a message box and state that the user should tap to receive
			 * else
			 *	Show a message box and state that the app failed to start receiving
			 *	
			 */

			if ( ProximityWrapper.Instance.ProximityStatus == ProximityStatus.Idle )
			{
				ProximityWrapper.Instance.SubscribeForMessage<PlaceState>(
					string.Concat( ProximityWrapper.MESSAGE_TYPE_PREFIX, "PlacesIveBeen.", typeof( PlaceState ).Name ),
					ReceivedSharedPlace );
				if (ProximityWrapper.Instance.ProximityStatus == ProximityStatus.Subscribed)
				{
					MessageBox.Show("Tap to receive place.");
				}
				else
				{
					MessageBox.Show("Failed to start receiving.");
				}
			}
		}

		private void ReceivedSharedPlace( PlaceState placeState )
		{
			//TODO: 3.3 - PlacesVM.cs Process Received Place
			/*
			 * Need to ensure execution of the add occurs on the UI thread
			 * if Deployment.Current.Dispatcher.CheckAccess() returns false
			 *	Use Dispatcher.BeginInvoke can call this method (ReceivedSharedPlace) then return
			 * 
			 * Create a new Place using the ctor that takes a PlaceState obj
			 * Add the new place to the Places collection of the DataProvider
			 * 
			 * Check DataProvider.Instance.Places to see if any of the Places Id match the received placeState.Id
			 *	If there are matches
			 *		don't add a new place and notify the user they already received this place
			 *	Else
			 *		Create a new Place using the ctor that takes a PlaceState obj
			 *		Add the new place to the Places collection of the DataProvider
			 *		Notify the user via MessageBox they received a new place
			 */

			if ( !Deployment.Current.Dispatcher.CheckAccess() )
			{
				Deployment.Current.Dispatcher.BeginInvoke( (Action<PlaceState>)ReceivedSharedPlace, placeState );
				return;
			}

			if ( DataProvider.Instance.Places.Any( p => p.Id == placeState.Id ) )
			{
				MessageBox.Show( "You've already received this place." );
				return;
			}
			var newPlace = new Place( placeState );
			DataProvider.Instance.Places.Add( newPlace );
			MessageBox.Show( string.Format( "You've received {0}!", newPlace.Name ) );
		}

		public void StopSubscribingForSharedPlace()
		{
			//TODO: 3.3 - PlacesVM.cs Stop Subscribing for Shared Place
			/*
			 * Using the Instance of ProximityWrapper call StopSubscribingForMessage
			 * 
			 */

			ProximityWrapper.Instance.StopSubscribingForMessage();
		}
	}
}