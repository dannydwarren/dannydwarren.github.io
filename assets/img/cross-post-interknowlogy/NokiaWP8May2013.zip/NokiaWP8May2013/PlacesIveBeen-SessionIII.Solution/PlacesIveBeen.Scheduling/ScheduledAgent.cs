﻿//#define DEBUG_AGENT

using System;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using Microsoft.Phone.Scheduler;
using Microsoft.Phone.Shell;

namespace PlacesIveBeen.Scheduling
{
	public class ScheduledAgent : ScheduledTaskAgent
	{
		/// <remarks>
		/// ScheduledAgent constructor, initializes the UnhandledException handler
		/// </remarks>
		static ScheduledAgent()
		{
			// Subscribe to the managed exception handler
			Deployment.Current.Dispatcher.BeginInvoke( delegate
			{
				Application.Current.UnhandledException += UnhandledException;
			} );
		}

		/// Code to execute on Unhandled Exceptions
		private static void UnhandledException( object sender, ApplicationUnhandledExceptionEventArgs e )
		{
			if ( Debugger.IsAttached )
			{
				// An unhandled exception has occurred; break into the debugger
				Debugger.Break();
			}
		}

		/// <summary>
		/// Agent that runs a scheduled task
		/// </summary>
		/// <param name="task">
		/// The invoked task
		/// </param>
		/// <remarks>
		/// This method is called when a periodic or resource intensive task is invoked
		/// </remarks>
		protected override void OnInvoke( ScheduledTask task )
		{
			IconicTileData iconicTileData = new IconicTileData()
			{
				Title = "Where I've Been",
				Count = new Random().Next( 10 ),
				WideContent1 = "Location Invitation",
				WideContent2 = "Danny Warren",
				WideContent3 = "Nokia in San Diego, CA",
				SmallIconImage = new Uri( "Assets/Tiles/IconicTileSmall.png", UriKind.Relative ),
				IconImage = new Uri( "Assets/Tiles/IconicTileMediumLarge.png", UriKind.Relative ),
			};

			UpdateOrCreateTile( "/", iconicTileData );

			NotifyViaToast();

#if DEBUG_AGENT
			ScheduledActionService.LaunchForTest( task.Name, TimeSpan.FromSeconds( 60 ) );
#endif

			NotifyComplete();
		}

		private void NotifyViaToast()
		{
			ShellToast toast = new ShellToast
				                   {
					                   Title = "Where I've Been",
									   Content = "New Location Invitation",
									   NavigationUri = new Uri("/Pages/PlacesPage.xaml", UriKind.Relative)
				                   };

			toast.Show();
		}

		private void UpdateOrCreateTile( string tileId, ShellTileData tileData )
		{
			ShellTile tileToUpdate =
				ShellTile.ActiveTiles.FirstOrDefault( t => t.NavigationUri.OriginalString.Contains( tileId ) );

			if ( tileToUpdate != null )
			{
				tileToUpdate.Update( tileData );
			}
		}

	}
}