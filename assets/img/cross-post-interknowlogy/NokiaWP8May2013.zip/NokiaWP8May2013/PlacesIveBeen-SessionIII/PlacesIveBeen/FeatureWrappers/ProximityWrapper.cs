﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Windows.Networking.Proximity;
using Windows.Storage.Streams;

namespace PlacesIveBeen.FeatureWrappers
{
	public class ProximityWrapper
	{
		public static readonly string MESSAGE_TYPE_PREFIX = "Windows."; //NOTE: This is a mandatory messageType prefix

		private ProximityDevice _proximityDevice;
		private long _activeMessageId = -1;

		private ProximityWrapper()
		{
			//TODO: 0 - ProximityWrapper.cs Implement Ctor and Initialize Proximity Device	
			// For more information: http://msdn.microsoft.com/en-us/library/windowsphone/develop/jj207060(v=vs.105).aspx

			/*
			 * Update the WMAppManifest file
			 *	Capabilities
			 *		Enable ID_CAP_NETWORKING and ID_CAP_PROXIMITY
			 * 
			 * Get an instance of ProximityDevice via the Static Method GetDefault() 
			 *	and store the value in a field
			 * 
			 * Set ProximityStatus
			 *	If value == null 
			 *		ProximityStatus.NotSupported
			 *	else
			 *		ProximityStatus.Idle
			 * 
			 */

			#region Solution 0
			//_proximityDevice = ProximityDevice.GetDefault();

			//ProximityStatus = _proximityDevice != null ? ProximityStatus.Idle : ProximityStatus.NotSupported; 
			#endregion
		}

		public event EventHandler ConnectionStatusChanged = delegate { };
		private void OnConnectionStatusChanged()
		{
			ConnectionStatusChanged( this, EventArgs.Empty );
		}

		private static ProximityWrapper _instance;
		public static ProximityWrapper Instance
		{
			get
			{
				if ( _instance == null )
					_instance = new ProximityWrapper();
				return _instance;
			}
		}

		private ProximityStatus _proximityStatus;
		public ProximityStatus ProximityStatus
		{
			get { return _proximityStatus; }
			set
			{
				if ( value == _proximityStatus )
					return;

				_proximityStatus = value;
				OnConnectionStatusChanged();
			}
		}

		public void SubscribeForMessage( string messageType, Action<string> messageReceivedCallback )
		{
			//TODO: 1.0 - ProximityWrapper.cs Implement SubscribeForMessage
			/*
			 * if _activeMessageId field == -1 (if a message is not currently being processed) and ProximityStatus is Idle
			 *	Use the _proximityDevice to SubscribeForMessage and set _activeMessageId to the returned value
			 *		use a lambda to call the callback ex: (s, m) => messageReceivedCallback(m.DataAsString)
			 *	Set ProximityStatus to Subscribed
			 * 
			 */

			#region Solution 1.0
			//if ( _activeMessageId == -1 && ProximityStatus == ProximityStatus.Idle )
			//{
			//	_activeMessageId = _proximityDevice.SubscribeForMessage( messageType,
			//															( s, m ) => messageReceivedCallback( m.DataAsString ) );
			//	ProximityStatus = ProximityStatus.Subscribed;
			//} 
			#endregion
		}

		public void SubscribeForMessage<T>( string messageType, Action<T> messageReceivedCallback )
		{
			SubscribeForMessage( messageType, s => messageReceivedCallback( Deserialize<T>( s ) ) );
		}

		public void StopSubscribingForMessage()
		{
			//TODO: 1.1 - ProximityWrapper.cs Implement StopSubscribingForMessage
			/*
			 * if _activeMessageId != -1 and ProximityStatus is Subscribed
			 *	use _proximityDevice to StopSubscribingForMessage _activeMessageId
			 *	set _activeMessageId to -1
			 *	set ProximityStatus to Idle
			 * 
			 */

			#region Solution 1.1
			//if ( _activeMessageId != -1 && ProximityStatus == ProximityStatus.Subscribed )
			//{
			//	_proximityDevice.StopSubscribingForMessage( _activeMessageId );
			//	_activeMessageId = -1;
			//	ProximityStatus = ProximityStatus.Idle;
			//} 
			#endregion
		}

		public void StartPublishing( string messageType, string message )
		{
			//TODO: 2.0 - ProximityWrapper.cs Implement StartPublishing
			/*
			 * if _activeMessageId field == -1 (if a message is not currently being processed) and ProximityStatus is Idle
			 *	use _proximityDevice to PublishMessage with available parameters 
			 *		and store the returned messageId in the _activeMessageId field
			 *	Set ProximityStatus to Publishing
			 * 
			 */

			#region Solution 2.0
			//if ( _activeMessageId == -1 && ProximityStatus == ProximityStatus.Idle )
			//{
			//	_activeMessageId = _proximityDevice.PublishMessage( messageType, message );
			//	ProximityStatus = ProximityStatus.Publishing;
			//} 
			#endregion
		}

		/// <summary>
		/// SUGGESTION: The messageType parameter should include the type name you are sending to help ensure the data is recognized and processed correctly.
		/// </summary>
		public void StartPublishing( string messageType, object value )
		{
			StartPublishing( messageType, Serialize( value ) );
		}

		public void StopPublishing()
		{
			//TODO: 2.1 - ProximityWrapper.cs Implement StopPublishing
			/*
			 * if _activeMessageId != -1 and ProximityStatus is Publishing
			 *	call _proximityDevice.StopPublishing with the _activeMessageId
			 *	set _activeMessageId to -1
			 *	set ProximityStatus to Idle
			 */

			#region Solution 2.1
			//if ( _activeMessageId != -1 && ProximityStatus == ProximityStatus.Publishing )
			//{
			//	_proximityDevice.StopPublishingMessage( _activeMessageId );
			//	_activeMessageId = -1;
			//	ProximityStatus = ProximityStatus.Idle;
			//} 
			#endregion
		}

		private static string Serialize( object objectToSerialize )
		{
			using ( MemoryStream ms = new MemoryStream() )
			{
				DataContractSerializer serializer = new DataContractSerializer( objectToSerialize.GetType() );
				serializer.WriteObject( ms, objectToSerialize );
				ms.Position = 0;

				using ( StreamReader reader = new StreamReader( ms ) )
				{
					return reader.ReadToEnd();
				}
			}
		}

		private static T Deserialize<T>( string jsonString )
		{
			using ( MemoryStream ms = new MemoryStream( Encoding.Unicode.GetBytes( jsonString ) ) )
			{
				DataContractSerializer serializer = new DataContractSerializer( typeof( T ) );
				return (T)serializer.ReadObject( ms );
			}
		}
	}

	public enum ProximityStatus
	{
		NotSupported,
		Idle,
		Publishing,
		Subscribed
	}
}
