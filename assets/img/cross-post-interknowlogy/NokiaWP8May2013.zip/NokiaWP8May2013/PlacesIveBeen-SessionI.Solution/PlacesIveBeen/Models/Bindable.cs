﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace PlacesIveBeen.Models
{
	public class Bindable : INotifyPropertyChanged
	{
		//TODO: 1.1 - Bindable.cs Implement INotifyPropertyChanged with [CallerMemberName]
		/*
		 * Bindable must Implement INotifyPropertyChanged
		 * 
		 * Initialize the PropertyChanged event with a delegate:
		 *	public event PropertyChangedEventHandler PropertyChanged = delegate { }
		 * 
		 * Create a method named OnPropertyChanged with parameter:
		 *	[CallerMemeberName] string propertyName = null
		 *		Call the event PropertyChanged with PropertyChangedEventArgs passing in propertyName to the args
		 * 
		 */
		
		public event PropertyChangedEventHandler PropertyChanged = delegate { };

		protected virtual void OnPropertyChanged( [CallerMemberName] string propertyName = null )
		{
			PropertyChanged( this, new PropertyChangedEventArgs( propertyName ) );
		}
	}
}