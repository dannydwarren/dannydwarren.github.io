﻿using System;
using System.Linq;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using PlacesIveBeen.ViewModels;

namespace PlacesIveBeen.Pages
{
	public partial class PlacesPage : PhoneApplicationPage
	{
		public PlacesPage()
		{
			//TODO: 2.4.0 - PlacesPage.cs
			/*
			 * Set DataContext
			 * Create Prop getter for PlacesVM using DC
			 * Subscribe to PlacesVM.SelectedPlaceChanged - We will use binding to set SelectedPlace in the VM then in codebehind react to the selection
			 * Initilialize PlacesVM
			 * Disable Edit AppBar Button if PlacesVM.SelectedPlace is null
			 * 
			 * Implement PlacesVM_SelectedPlaceChanged
			 * Implement AddClickHandler
			 * Implement EditClickHandler
			 * 
			 */
			
			InitializeComponent();
			DataContext = new PlacesVM();
			PlacesVM.Initialize();
			PlacesVM.SelectedPlaceChanged += PlacesVM_SelectedPlaceChanged;
			this.ApplicationBar.Buttons.OfType<ApplicationBarIconButton>().First( b => b.Text == "edit" ).IsEnabled = PlacesVM.SelectedPlace != null;	//EditButton.IsEnabled = false;
		}

		void PlacesVM_SelectedPlaceChanged( object sender, EventArgs e )
		{
			//TODO: 2.4.2 - PlacesPage.cs
			/*
			 * Disable Edit AppBar Button if PlacesVM.SelectedPlace is null
			 */
			
			//EditButton.IsEnabled = false;
			this.ApplicationBar.Buttons.OfType<ApplicationBarIconButton>().First( b => b.Text == "edit" ).IsEnabled = PlacesVM.SelectedPlace != null;
		}

		//TODO: 2.4.1 - PlacesPage.cs
		/*
		 * Uncomment PlacesVM property below
		 * 
		 */
		public PlacesVM PlacesVM { get { return (PlacesVM)DataContext; } }

		private void AddClickHandler( object sender, EventArgs e )
		{
			//TODO: 2.4.3 - PlacesPage.cs
			/*
			 * Navigate to PlaceManagementPage
			 */
			
			NavigationService.Navigate( new Uri( @"/Pages/PlaceManagementPage.xaml", UriKind.Relative ) );
		}

		private void EditClickHandler( object sender, EventArgs e )
		{
			//TODO: 2.4.4 - PlacesPage.cs
			/*
			 * Navigate to PlaceManagementPage with PlacesVM.SelectedPlace.Id parameter in query string
			 */
			
			if ( PlacesVM.SelectedPlace != null )
			{
				NavigationService.Navigate(
					new Uri( string.Format( @"/Pages/PlaceManagementPage.xaml?id={0}", PlacesVM.SelectedPlace.Id ), UriKind.Relative ) );
			}
		}
	}
}