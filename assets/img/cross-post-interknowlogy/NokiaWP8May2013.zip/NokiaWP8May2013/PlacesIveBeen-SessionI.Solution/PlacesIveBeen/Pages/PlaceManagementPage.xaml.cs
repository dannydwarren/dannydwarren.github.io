﻿using System;
using Microsoft.Phone.Controls;
using PlacesIveBeen.Models;
using PlacesIveBeen.ViewModels;

namespace PlacesIveBeen.Pages
{
	public partial class PlaceManagementPage : PhoneApplicationPage
	{
		public PlaceManagementPage()
		{
			InitializeComponent();

			//NOTE: We did have this same pattern in the PlacesPage.
			//	We set the DataContext to the desried VM
			//	Then we created a getter property to cast the DataContext as the VM we desire.
			DataContext = new PlaceManagementVM();
		}

		public PlaceManagementVM ManagementVM { get { return (PlaceManagementVM)DataContext; } }

		protected override void OnNavigatedTo( System.Windows.Navigation.NavigationEventArgs e )
		{
			//TODO: 4.3 - PlaceManagementPage.cs handle OnNavigatedTo
			/*
			 * Review ctor
			 * 
			 * Try get the id value from the NavigationContext.QueryString
			 *	If successful then parse the string value to a Guid
			 *	Else use Guid.Empty
			 *	
			 * Call ManagementVM.Initialize with the Guid
			 * 
			 */

			//TODO: 5.3 - PlaceManagmentPage.xaml.cs
			/*
			 * Uncomment the below code in Solution 5.3
			 * Cut the Normal Navigation code above from refTODO: 4.3 then paste below where specified
			 * 
			 */

			if ( _hasState )
			{
				State.Remove(PLACE_MANAGEMENT_PAGE_STATE_KEY);
				base.OnNavigatedTo( e );
				return;
			}

			object state;
			if (State.TryGetValue(PLACE_MANAGEMENT_PAGE_STATE_KEY, out state))
			{
				State.Remove( PLACE_MANAGEMENT_PAGE_STATE_KEY );
				ManagementVM.Initialize( (PlaceManagementVMState)state );
			}
			else
			{
				////****************************Insert Normal Navigation Handling Here****************
				string placeIdString;
				Guid placeId = Guid.Empty;
				if (NavigationContext.QueryString.TryGetValue("id", out placeIdString))
				{
					placeId = Guid.Parse(placeIdString);
				}

				ManagementVM.Initialize(placeId);
			}
			
			_hasState = true;
			
			base.OnNavigatedTo( e );
		}

		public static readonly string PLACE_MANAGEMENT_PAGE_STATE_KEY = "PLACE_MANAGEMENT_PAGE_STATE_KEY";
		private bool _hasState;
		protected override void OnNavigatedFrom( System.Windows.Navigation.NavigationEventArgs e )
		{
			//TODO: 5.2 - PlaceManagementPage.cs Save State for Tombstoning
			/*
			 * Uncomment to two fields above _hasState and PLACE_MANAGEMENT_PAGE_STATE_KEY
			 * In OnNavigatedFrom
			 *	Use State to save the state of ManagementVM
			 * 
			 */
			
			State.Add( new System.Collections.Generic.KeyValuePair<string, object>( PLACE_MANAGEMENT_PAGE_STATE_KEY, ManagementVM.GetState() ) );

			base.OnNavigatedFrom( e );
		}

		private void SaveClickHandler( object sender, EventArgs e )
		{
			//TODO: 4.4 - PlaceManagementPage.cs handle Save
			/*
			 * Call ManagementVM.PersistChanges
			 * Use the NavigationService to go back
			 * 
			 */

			ManagementVM.PersistChanges();
			NavigationService.GoBack();
		}
	}
}