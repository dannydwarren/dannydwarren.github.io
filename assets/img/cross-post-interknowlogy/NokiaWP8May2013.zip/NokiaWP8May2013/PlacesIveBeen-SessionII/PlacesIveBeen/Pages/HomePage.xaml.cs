﻿#define DEBUG_AGENT

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Scheduler;
using Microsoft.Phone.Shell;

namespace PlacesIveBeen.Pages
{
	public partial class HomePage : PhoneApplicationPage
	{
		public HomePage()
		{
			InitializeComponent();
		}

		private void AllClickHandler( object sender, RoutedEventArgs e )
		{
			NavigationService.Navigate( new System.Uri( @"/Pages/PlacesPage.xaml", System.UriKind.Relative ) );
		}

		private void AddClickHandler( object sender, RoutedEventArgs e )
		{
			NavigationService.Navigate( new System.Uri( @"/Pages/PlaceManagementPage.xaml", System.UriKind.Relative ) );
		}

		private void EnableIconicTileClickHandler( object sender, RoutedEventArgs e )
		{
			//TODO: 5.1 - HomePage.cs enable main tile
			/*
			 * Create the desired tile data (IconicTileData)
			 * Set values Title, Count, WideContent1 and 2 and 3, SmallIconImage, and IconImage
			 *	SmallIconImage:  "Assets/Tiles/IconicTileSmall.png", UriKind.Relative
			 *	IconImage: "Assets/Tiles/IconicTileMediumLarge.png", UriKind.Relative
			 *	
			 * Call UpdateOrCreateTile with the tile data.
			 * 
			 * NOTE: If the main tile is not pinned calling this code will not pin it. It must be done manually from the app list.
			 */

			#region Solution 5.1
			//IconicTileData iconicTileData = new IconicTileData()
			//{
			//	Title = "Where I've Been",
			//	Count = new Random().Next( 10 ),
			//	WideContent1 = "Location Invitation",
			//	WideContent2 = "Danny Warren",
			//	WideContent3 = "Nokia in San Diego, CA",
			//	SmallIconImage = new Uri( "Assets/Tiles/IconicTileSmall.png", UriKind.Relative ),
			//	IconImage = new Uri( "Assets/Tiles/IconicTileMediumLarge.png", UriKind.Relative ),
			//};

			//UpdateOrCreateTile( iconicTileData );

			//StartTileUpdaterTask(); 
			#endregion
		}

		private void UpdateOrCreateTile( ShellTileData tileData )
		{
			//TODO: 5.4 - HomePage.cs Implement UpdateOrCreateTile
			/*
			 * Get the main live tile for the app (which always exists) ShellTile.ActiveTiles.First()
			 * Call Update on that tile and pass in the tileData
			 * 
			 */

			#region Solution 5.4
			//ShellTile mainTile = ShellTile.ActiveTiles.First();
			//mainTile.Update( tileData );
			#endregion
		}

		private static readonly string TILE_UPDATER_TASK_NAME = "TILE_UPDATER_TASK_NAME";
		private void StartTileUpdaterTask()
		{
			//TODO: 7 - HomePage.cs start tile updater task
			/*
			 * Create tile updater task name as static readonly string field
			 * 
			 * Find the tile updater task and remove it from ScheduledActionService - this is because we always restart the tasks to renew them
			 *	When removing use a try catch and ignore all excpetions
			 * 
			 * Create new tile updater task (PeriodicTask)
			 *	Description: Updates main tile.
			 *	ExpirationTime: DateTime.Now.AddDays( 14 ) - this is the max amount of time we can request that will be respected
			 * 
			 * try
			 *	Add new tile updater task to ScheduledActionService
			 *	Add #define DEBUG_AGENT as first line of file
			 *	Add #if DEBUG_AGENT block below this comment
			 *	Add code in #if block:
			 *		ScheduledActionService.LaunchForTest( task.Name, TimeSpan.FromSeconds( 10 ) );
			 *		NOTE: The TimeSpan cannot be less than 60 sec. If it is, then it is ignored
			 *		
			 * catch code:
			 * 
				catch ( InvalidOperationException exception )
				{
					if ( exception.Message.Contains( "BNS Error: The action is disabled" ) )
					{
						MessageBox.Show( "Background agents for this application have been disabled by the user." );
					}

					if ( exception.Message.Contains( "BNS Error: The maximum number of ScheduledActions of this type have already been added." ) )
					{
						// No user action required. The system prompts the user when the hard limit of periodic tasks has been reached.
					}
				}
				catch ( SchedulerServiceException )
				{
					// No user action required.
				}
			 * 
			 * 
			 */

#region Solution 7
		//			PeriodicTask existingTileUpdaterTask = ScheduledActionService.Find( TILE_UPDATER_TASK_NAME ) as PeriodicTask;
//			if ( existingTileUpdaterTask != null )
//			{
//				try
//				{
//					ScheduledActionService.Remove( TILE_UPDATER_TASK_NAME );
//				}
//				catch ( Exception ex )
//				{
//					//NOTE: Exceptions during removal are unimportant
//				}
//			}

//			PeriodicTask newTileUpdaterTask = new PeriodicTask( TILE_UPDATER_TASK_NAME )
//												  {
//													  Description = "Updates main tile.",
//													  ExpirationTime = DateTime.Now.AddDays( 14 ),
//												  };

//			try
//			{
//				ScheduledActionService.Add( newTileUpdaterTask );

//#if(DEBUG_AGENT)
//				ScheduledActionService.LaunchForTest( TILE_UPDATER_TASK_NAME, TimeSpan.FromSeconds( 60 ) );
//#endif
//			}
//			catch ( InvalidOperationException exception )
//			{
//				if ( exception.Message.Contains( "BNS Error: The action is disabled" ) )
//				{
//					MessageBox.Show( "Background agents for this application have been disabled by the user." );
//				}

//				if ( exception.Message.Contains( "BNS Error: The maximum number of ScheduledActions of this type have already been added." ) )
//				{
//					// No user action required. The system prompts the user when the hard limit of periodic tasks has been reached.
//				}
//			}
//			catch ( SchedulerServiceException )
//			{
//				// No user action required.
//			}
	#endregion
		}

	}
}