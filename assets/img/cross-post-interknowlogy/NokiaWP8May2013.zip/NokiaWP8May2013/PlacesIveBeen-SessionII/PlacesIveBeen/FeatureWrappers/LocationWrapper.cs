﻿using System;
using System.IO.IsolatedStorage;
using System.Threading.Tasks;
using System.Windows;
using Windows.Devices.Geolocation;

namespace PlacesIveBeen.FeatureWrappers
{
	//TODO: 0.0 - LocationWrapper.cs enable single shot location services
	/*
	* TODO: IMPORTANT: Enable ID_CAP_LOCATION capability in WMAppManifest.xml
	* 
	* LocationWrapper should be a singleton
	* 
	* Always check to see if the user allows the use of location services
	*	Use CheckIfUserAllowsLocation() and RequestPermissionToUseLocation()
	* Use a static readonly string for the Key for use with IsolatedStorageSettings
	* 
	*/
	public class LocationWrapper
	{
		private static readonly string USER_ALLOWS_LOCATION_KEY = "USER_ALLOWS_LOCATION_KEY";

		private LocationWrapper()
		{

		}

		private static LocationWrapper _instance;
		public static LocationWrapper Instance
		{
			get
			{
				if ( _instance == null )
					_instance = new LocationWrapper();
				return _instance;
			}
		}

		/// <summary>
		/// NOTE: Return value will be null if the user does not allow location or if location services are disabled.
		/// </summary>
		/// <returns>Geoposition</returns>
		public async Task<Geoposition> GetSingleShotLocationAsync()
		{
			//TODO: 0.1 - LocationWrapper.cs Implement GetSingleShotLocationAsync
			/*
			 * If the user does not allow location [use CheckIfUserAllowsLocation()]
			 *	Then request permission to use location. [use RequestPermissionToUseLocation()]
			 *	If the user denies permission
			 *		Then return null
			 *		
			 * Instantiate a Geolocator object
			 * Set the DesiredAccuracyInMeters to 5
			 * 
			 * Create a Geoposition variable named geoposition and set it to null
			 * 
			 * In a try catch call Geolocator.GetGeopositionAsync using the await key word and set the return value to the geoposition variable
			 *	Set the maximumAge parameter to 1 sec (use TimeSpan.FromSeconds) - Means we never have a location that was cached more than 1 second ago
			 *	Set the timeout parameter to 10 sec (use TimeSpan.FromSeconds) - We will wait for up to 10 seconds to recieve a response then bail
			 * 
			 * if there is an exception check exception.HResult if it equals 0x80004004
			 *	then show a message box with the message "Location is disabled in phone settings."
			 *	
			 * return geoposition (null is ok - read this method's summary comment above)
			 */

			return null; //delete

			#region Solution 0.1
			//if ( !CheckIfUserAllowsLocation() )
			//{
			//	if ( !RequestPermissionToUseLocation() )
			//	{
			//		return null;
			//	}
			//}

			//Geolocator geolocator = new Geolocator
			//{
			//	DesiredAccuracyInMeters = 50
			//};


			//Geoposition geoposition = null;

			//try
			//{
			//	geoposition =
			//		await geolocator.GetGeopositionAsync( maximumAge: TimeSpan.FromSeconds( 1 ),
			//											 timeout: TimeSpan.FromSeconds( 10 ) );
			//}
			//catch ( Exception ex )
			//{
			//	if ( (uint)ex.HResult == 0x80004004 )
			//	{
			//		MessageBox.Show( "Location is disabled in phone settings." );
			//	}
			//}

			//return geoposition; 
			#endregion
		}

		public bool RequestPermissionToUseLocation()
		{
			//TODO: 0.2 - LocationWrapper.cs Prompt user for permission to use location
			/*
			 * A simple MessageBox prompt will suffice
			 * Save the result in IsolatedStorageSettings.ApplicationSettings
			 */

			return false; //delete

			#region Solution 0.2

			//MessageBoxResult result = MessageBox.Show( "This app accesses your phone's location. Is that OK?", "Location",
			//										  MessageBoxButton.OKCancel );

			//bool userAllowsLocation = result == MessageBoxResult.OK;

			//IsolatedStorageSettings.ApplicationSettings[USER_ALLOWS_LOCATION_KEY] = userAllowsLocation;
			//IsolatedStorageSettings.ApplicationSettings.Save();

			//return userAllowsLocation; 

			#endregion
		}

		public bool CheckIfUserAllowsLocation()
		{
			//TODO: 0.3 - LocationWrapper.cs Implement CheckIfUserAllowsLocation
			/*
			 * Try to get the value out of IsolatedStorageSettings.ApplicationSettings
			 * By using TryGetValue the boolean stored will either be retrieved or will return false
			 *	NOTE: We'll need to prompt the user for permission if false
			 */

			return false; //delete

			#region Solution 0.3

			//bool userAllowsLocation;
			//IsolatedStorageSettings.ApplicationSettings.TryGetValue( USER_ALLOWS_LOCATION_KEY, out userAllowsLocation );

			//return userAllowsLocation; 

			#endregion
		}

		public string ConvertGeocoordinateToAddress()
		{
			//NOTE: Converting a GeocoordinateToAddress is not supported natively in WP8

			//http://dev.virtualearth.net/REST/v1/Locations/47.64054,-122.12934?o=xml&key=BingMapsKey
			throw new NotImplementedException();
		}
	}
}
