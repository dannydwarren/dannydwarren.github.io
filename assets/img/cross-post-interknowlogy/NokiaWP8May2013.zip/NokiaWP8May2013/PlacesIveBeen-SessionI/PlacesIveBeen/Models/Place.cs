﻿using System;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace PlacesIveBeen.Models
{
	public class Place
	{
		//TODO: 1.0 - Place.cs Basic Implementation
		/*
		 * Id - Guid - private setter
		 * Name - string - prop notify
		 * Notes - string - prop notify
		 *	
		 * Set Id to Guid.NewGuid() in ctor
		 * 
		 * Make Bindable - refTODO: 1.1
		*/

		#region Solution 1.0
		//public Place()
		//{
		//	Id = Guid.NewGuid();
		//}

		//public Guid Id { get; private set; }

		//private string _name;
		//public string Name
		//{
		//	[DebuggerStepThrough]
		//	get { return _name; }
		//	set
		//	{
		//		if ( value == _name )
		//			return;

		//		_name = value;
		//		OnPropertyChanged();
		//	}
		//}

		//private string _notes;
		//public string Notes
		//{
		//	[DebuggerStepThrough]
		//	get { return _notes; }
		//	set
		//	{
		//		if ( value == _notes )
		//			return;

		//		_notes = value;
		//		OnPropertyChanged();
		//	}
		//}
		#endregion

		//TODO: 3.3 - Place.cs Enable Serialization by Getting and Applying State from Serialization Class
		/*
		 * Uncomment code in this region: Solution 3.3
		 * 
		 * Added a new ctor which accepts a PlaceState obj which is used to initilize this obj
		 * Added GetState and ApplyState methods to assist with converting this class' data into a serializable obj
		 * 
		 */

		#region Solution 3.3
		//public Place( PlaceState state )
		//{
		//	Id = state.Id;
		//	ApplyState( state );
		//}

		//public PlaceState GetState()
		//{
		//	return new PlaceState
		//			   {
		//				   Id = Id,
		//				   Name = Name,
		//				   Notes = Notes,
		//			   };
		//}

		//public void ApplyState(PlaceState state)
		//{
		//	Name = state.Name;
		//	Notes = state.Notes;
		//} 
		#endregion
	}

	//TODO: 3.2 - Place.cs Create Serialization Class
	/*
	 * Uncomment code in this region: Solution 3.2
	 * 
	 * The PlaceState class is decorated with the DataContract attribute to mark it serializable
	 *	then each property is decorated with the DataMember attribute to mark it included for serialization
	 * 
	 */

	#region Solution 3.2
	//[DataContract]
	//public class PlaceState
	//{
	//	[DataMember]
	//	public Guid Id { get; set; }
	//	[DataMember]
	//	public string Name { get; set; }
	//	[DataMember]
	//	public string Notes { get; set; }
	//} 
	#endregion

}
