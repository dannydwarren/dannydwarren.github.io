﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Runtime.Serialization;
using PlacesIveBeen.Models;

namespace PlacesIveBeen.Data
{
	public class DataProvider
	{
		//TODO: 3.1 - DataProvider.cs Review what is going on in here. 
		/*
		 * Uncomment this class: DataProvider
		 *	Select all commented code below then hit Ctrl+K+U (Uncomment command)
		 */

		//private static readonly string PLACES_KEY = "PLACES_KEY";
		//private static readonly object SAVE_SYNC = new object();

		//private DataProvider()
		//{
		//	Places = new ObservableCollection<Place>();

		//	RetrievePlaces();
		//}

		//private static DataProvider _instance;
		//public static DataProvider Instance
		//{
		//	get
		//	{
		//		if ( _instance == null )
		//			_instance = new DataProvider();
		//		return _instance;
		//	}
		//}

		//public ObservableCollection<Place> Places { get; private set; }
		
		//public bool SaveChanges()
		//{
		//	SaveValue( PLACES_KEY, Places.Select( p => p.GetState() ).ToArray() );

		//	bool saveSuccessful = false;
		//	lock ( SAVE_SYNC )
		//	{
		//		try
		//		{
		//			// documentation claims this is not thread safe: http://msdn.microsoft.com/en-us/library/system.io.isolatedstorage.isolatedstoragesettings(v=VS.95).aspx
		//			IsolatedStorageSettings.ApplicationSettings.Save();
		//			saveSuccessful = true;
		//		}
		//		catch ( SerializationException e )
		//		{
		//			Debug.Assert( false );
		//		}
		//		catch ( IsolatedStorageException e )
		//		{
		//			// if we reach this one of two problems have occured:
		//			// 1. we are out of memory: http://msdn.microsoft.com/en-us/library/system.io.isolatedstorage.isolatedstoragesettings.save(v=vs.95).aspx
		//			//		however, this should not happen unless the the phone has absolutly no free memory because we have access to all available free memory
		//			// 2. there was a thread access issue (claims to be possible by documentation: http://msdn.microsoft.com/en-us/library/system.io.isolatedstorage.isolatedstoragesettings(v=VS.95).aspx)

		//			Debug.Assert( false ); // just trying to get the developer's attention :)
		//		}
		//		catch ( Exception e )
		//		{
		//			// this happens a LOT! But doesn't seem to matter...
		//			Debug.Assert( false ); // can we protect against the cause of this?
		//			saveSuccessful = true;
		//		}
		//	}
		//	return saveSuccessful;
		//}
		
		//private void SaveValue<T>( string key, T value )
		//{
		//	IsolatedStorageSettings.ApplicationSettings[key] = value;
		//}

		//private bool RetrieveValue<T>( string key, out T value )
		//{
		//	return IsolatedStorageSettings.ApplicationSettings.TryGetValue( key, out value );
		//}
		
		//private void RetrievePlaces()
		//{
		//	PlaceState[] placesRetrieved;
		//	if ( RetrieveValue( PLACES_KEY, out placesRetrieved ) )
		//	{
		//		foreach ( PlaceState placeState in placesRetrieved )
		//		{
		//			Places.Add( new Place( placeState ) );
		//		}
		//	}
		//}
	}
}