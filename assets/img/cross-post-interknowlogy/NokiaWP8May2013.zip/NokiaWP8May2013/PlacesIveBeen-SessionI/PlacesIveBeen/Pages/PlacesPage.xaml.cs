﻿using System;
using System.Linq;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using PlacesIveBeen.ViewModels;

namespace PlacesIveBeen.Pages
{
	public partial class PlacesPage : PhoneApplicationPage
	{
		public PlacesPage()
		{
			InitializeComponent();
			//TODO: 2.4.0 - PlacesPage.cs
		
			/*
			 * Set DataContext
			 * Create Prop getter for PlacesVM using DC
			 * Subscribe to PlacesVM.SelectedPlaceChanged - We will use binding to set SelectedPlace in the VM then in codebehind react to the selection
			 * Initilialize PlacesVM
			 * Disable Edit AppBar Button if PlacesVM.SelectedPlace is null
			 * 
			 * Implement PlacesVM_SelectedPlaceChanged
			 * Implement AddClickHandler
			 * Implement EditClickHandler
			 * 
			 */
			
			#region Solution 2.4.0
			//DataContext = new PlacesVM();
			//PlacesVM.SelectedPlaceChanged += PlacesVM_SelectedPlaceChanged;
			//PlacesVM.Initialize();
			////EditButton.IsEnabled = PlacesVM.SelectedPlace != null; //does not work
			//ApplicationBar.Buttons.OfType<ApplicationBarIconButton>().First( b => b.Text == "edit" ).IsEnabled = PlacesVM.SelectedPlace != null;	//works 
			#endregion
		}

		//TODO: 2.4.1 - PlacesPage.cs
		/*
		 * Uncomment PlacesVM property below
		 * 
		 */
		//public PlacesVM PlacesVM { get { return (PlacesVM)DataContext; } }

		private void PlacesVM_SelectedPlaceChanged( object sender, EventArgs e )
		{
			//TODO: 2.4.2 - PlacesPage.cs
			/*
			 * Disable Edit AppBar Button if PlacesVM.SelectedPlace is null
			 */

			#region Solution 2.4.2
			////EditButton.IsEnabled = PlacesVM.SelectedPlace != null; //does not work
			//ApplicationBar.Buttons.OfType<ApplicationBarIconButton>().First( b => b.Text == "edit" ).IsEnabled = PlacesVM.SelectedPlace != null;	//works 
			#endregion
		}

		private void AddClickHandler( object sender, EventArgs e )
		{
			//TODO: 2.4.3 - PlacesPage.cs
			/*
			 * Navigate to PlaceManagementPage
			 */

			#region Solution 2.4.3
			//NavigationService.Navigate( new Uri( @"/Pages/PlaceManagementPage.xaml", UriKind.Relative ) ); 
			#endregion
		}

		private void EditClickHandler( object sender, EventArgs e )
		{
			//TODO: 2.4.4 - PlacesPage.cs
			/*
			 * If PlacesVM.SelectedPlace is not null
			 *	Navigate to PlaceManagementPage with PlacesVM.SelectedPlace.Id parameter in query string
			 */

			#region Solution 2.4.4
			//if ( PlacesVM.SelectedPlace != null )
			//{
			//	NavigationService.Navigate(
			//		new Uri( string.Format( @"/Pages/PlaceManagementPage.xaml?id={0}", PlacesVM.SelectedPlace.Id ), UriKind.Relative ) );
			//}
			#endregion
		}
	}
}