﻿using System.Windows;
using Microsoft.Phone.Controls;

namespace PlacesIveBeen.Pages
{
	public partial class HomePage : PhoneApplicationPage
	{
		public HomePage()
		{
			InitializeComponent();
		}

		//TODO: 0.1 - HomePage.cs Implement Click handlers
		private void AllClickHandler( object sender, RoutedEventArgs e )
		{
			// Use NavigationService to navigate to PlacesPage

			#region Solution 0.1 Part - AllClickHandler
			//NavigationService.Navigate( new System.Uri( @"/Pages/PlacesPage.xaml", System.UriKind.Relative ) ); 
			#endregion
		}

		private void AddClickHandler( object sender, RoutedEventArgs e )
		{
			// Use NavigationService to navigate to PlaceManagementPage

			#region Solution 0.1 Part - AddClickHandler
			//NavigationService.Navigate( new System.Uri( @"/Pages/PlaceManagementPage.xaml", System.UriKind.Relative ) ); 
			#endregion
		}
	}
}