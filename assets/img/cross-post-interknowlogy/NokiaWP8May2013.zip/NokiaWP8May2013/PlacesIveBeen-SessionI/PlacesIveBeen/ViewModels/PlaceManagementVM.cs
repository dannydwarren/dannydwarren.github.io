﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Serialization;
using System.Windows;
using PlacesIveBeen.Data;
using PlacesIveBeen.Models;

namespace PlacesIveBeen.ViewModels
{
	public class PlaceManagementVM : Bindable
	{
		//TODO: 4.1 - PlaceManagementVM.cs Implmement VM
		/*
		 * Uncomment this region: Solution 4.1
		 * 
		 * PlaceToEdit prop is what we will bind to in the UI
		 * PersistChanges saves all changes via the DataProvider to IsolatedStorageSettings
		 * 
		 */

		#region Solution 4.1

		//private bool _isNew;
		//private Place _originalPlace;

		//private Place _placeToEdit;
		//public Place PlaceToEdit
		//{
		//	[DebuggerStepThrough]
		//	get { return _placeToEdit; }
		//	private set
		//	{
		//		if ( value == _placeToEdit )
		//			return;

		//		_placeToEdit = value;
		//		OnPropertyChanged();
		//	}
		//}

		//public void PersistChanges()
		//{
		//	if ( _isNew )
		//	{
		//		DataProvider.Instance.Places.Add( PlaceToEdit );
		//	}
		//	else
		//	{
		//		_originalPlace.ApplyState( PlaceToEdit.GetState() );
		//	}

		//	if ( !DataProvider.Instance.SaveChanges() )
		//	{
		//		MessageBox.Show( "Saving failed." );
		//	}
		//}


		#endregion

		public void Initialize( Guid placeId )
		{
			//TODO: 4.2 - PlaceManagementVM.cs Implement Initialize
			/*
			 * Get the place that matches the placeID from the DataProvider
			 *	If the place exits
			 *		Set the originalPlace as the _originalPlace
			 *		Create a new place from the State of the _originalPlace and set it as the PlaceToEdit
			 *	Else
			 *		Set _isNew to True
			 *		Set PlaceToEdit as a new Place
			 * 
			 */


			#region Solution 4.2
			/*
			 * Uncomment this region: Solution 4.2
			 * 
			 */

			//Place originalPlace = DataProvider.Instance.Places.FirstOrDefault( p => p.Id == placeId );
			//if ( originalPlace != null )
			//{
			//	_originalPlace = originalPlace;
			//	PlaceToEdit = new Place( originalPlace.GetState() );
			//}
			//else
			//{
			//	_isNew = true;
			//	PlaceToEdit = new Place();
			//} 
			#endregion
		}

		//TODO: 5.1 - PlaceManagementVM.cs Enable Transient State Support
		/*
		 * Uncomment this region: Solution 5.1
		 * 
		 * Added new Initialize method overload that accepts PlaceManagementVMState which helps with restoring from being Tombstoned
		 * Added GetState and ApplyState to help convert this VM into a serializable obj
		 * 
		 */
		#region Solution 5.1

		//public void Initialize( PlaceManagementVMState state )
		//{
		//	ApplyState( state );
		//}

		//public PlaceManagementVMState GetState()
		//{
		//	return new PlaceManagementVMState
		//			   {
		//				   PlaceState = PlaceToEdit.GetState(),
		//				   IsNew = _isNew
		//			   };
		//}

		//public void ApplyState( PlaceManagementVMState state )
		//{
		//	if ( state.IsNew )
		//	{
		//		_isNew = true;
		//	}
		//	else
		//	{
		//		_originalPlace = DataProvider.Instance.Places.First( p => p.Id == state.PlaceState.Id );
		//	}

		//	PlaceToEdit = new Place( state.PlaceState );
		//} 
		#endregion
	}

	//TODO: 5.0 - PlaceManagementVM.cs Enable Transient State Support
	/*
	 * Uncomment this region: Solution 5.0
	 * 
	 * PlaceManagementVMState is represents the serializable state for PlaceManagmentVM and will be used for Tombstoning
	 * 
	 */
	#region Solution 5.0
	
	//[DataContract]
	//public class PlaceManagementVMState
	//{
	//	[DataMember]
	//	public PlaceState PlaceState { get; set; }

	//	[DataMember]
	//	public bool IsNew { get; set; }
	//}

	#endregion
}